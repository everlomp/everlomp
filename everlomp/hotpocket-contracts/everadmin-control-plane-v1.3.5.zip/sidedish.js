// EverAdmin Control Plane rebuild. Modified 2026-08-30 from the supplied V6 HotPocket package; distributed with COPYING (GPL v2).
'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const APP_VERSION = '1.3.5';
const APP_NAME = 'EverAdmin Control Plane';
const STATE_ROOT = process.cwd();
const PUBLIC_ROOT = path.resolve(STATE_ROOT, 'public');
const AUTH_FILE = path.resolve(STATE_ROOT, 'admin-auth.json');
const UPLOAD_SESSIONS_FILE = path.resolve(STATE_ROOT, '.upload-sessions.json');
const UNL_METADATA_FILE = path.resolve(STATE_ROOT, 'unl-metadata.json');
const UNL_PRUNE_FILE = path.resolve(STATE_ROOT, 'unl-prune-state.json');
const REMOVED_UNLS_FILE = path.resolve(STATE_ROOT, 'removed-unls.json');
const CUSTOM_FIELDS_FILE = path.resolve(STATE_ROOT, 'custom-fields.json');
const LOCAL_CUSTOM_FILE = path.resolve(STATE_ROOT, '..', 'custom.json');
const LOCAL_HEALTH_FILE = path.resolve(STATE_ROOT, '..', 'unl-health.json');
const CONTRACT_VERSIONS_ROOT = path.resolve(STATE_ROOT, 'contract-versions');
const CONTRACT_UPLOADS_ROOT = path.resolve(STATE_ROOT, '.contract-version-uploads');
const CONTRACT_VERSIONS_INDEX_FILE = path.resolve(CONTRACT_VERSIONS_ROOT, 'versions.json');
const ACTIVE_VERSION_FILE = path.resolve(CONTRACT_VERSIONS_ROOT, 'active-version.json');
const PREVIOUS_VERSION_FILE = path.resolve(CONTRACT_VERSIONS_ROOT, 'previous-active-version.json');
const PUBLIC_UPLOADS_ROOT = path.resolve(STATE_ROOT, '.public-uploads');
const HP_CFG_CANDIDATES = [...new Set([
  process.env.EVERADMIN_HP_CFG_PATH ? path.resolve(process.env.EVERADMIN_HP_CFG_PATH) : null,
  path.resolve('/contract/cfg/hp.cfg'),
  // Current Evernode/Sashimono execution layout: /contract/contract_fs/mnt/{rw|ro}/state.
  path.resolve(STATE_ROOT, '../../../../cfg/hp.cfg'),
  // Older/direct seed layout: /contract/contract_fs/seed/state.
  path.resolve(STATE_ROOT, '../../../cfg/hp.cfg')
].filter(Boolean))];

const ROLE_HEAD_ADMIN = 'head-admin';
const ROLE_ADMIN = 'admin';
const VALID_ROLES = new Set([ROLE_HEAD_ADMIN, ROLE_ADMIN]);
const PASSWORD_KEY_BYTES = 32;
const DEFAULT_AUTH_TTL_SECONDS = 30 * 24 * 60 * 60;
const MAX_AUTH_TTL_SECONDS = 365 * 24 * 60 * 60;
const PASSWORD_KDF_ITERATIONS = 310000;
const TOTP_DIGITS = 6;
const TOTP_STEP_SECONDS = 30;
const HEALTH_NPL_TYPE = 'everadmin-unl-health:v1';
const MAX_PUBLIC_FILE_BYTES = 8 * 1024 * 1024;
const MAX_CONTRACT_FILE_BYTES = 25 * 1024 * 1024;
const MAX_CONTRACT_TOTAL_BYTES = 80 * 1024 * 1024;
const MAX_CODE_EDITOR_BYTES = 2 * 1024 * 1024;
const EDITABLE_TEXT_EXTENSIONS = new Set(['.js','.mjs','.cjs','.html','.htm','.css','.json','.txt','.md','.svg','.xml','.webmanifest']);

const ADMIN_ALLOWED_ACTIONS = new Set([
  'get-diagnostics',
  'list-custom-fields',
  'get-local-custom',
  'set-custom-value',
  'append-custom-value',
  'remove-custom-item',
  'clear-custom-value',
  'auth-status',
  'load-dashboard',
  'logout-device'
]);

let runtime = null;

function nowMs(ctx) {
  const raw = Number(ctx && ctx.timestamp);
  if (Number.isFinite(raw) && raw > 0) return raw < 100000000000 ? Math.floor(raw * 1000) : Math.floor(raw);
  return Date.now();
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readJson(file, fallback) {
  if (!fs.existsSync(file)) return fallback;
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function writeJson(file, value) {
  ensureDir(path.dirname(file));
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}

function safeString(value, max = 4096) {
  return String(value === undefined || value === null ? '' : value).trim().slice(0, max);
}

function unique(values) {
  return [...new Set((values || []).map(v => String(v || '').trim()).filter(Boolean))];
}


function readNodeRuntimeConfig() {
  const errors = [];
  let parsedFallback = null;

  for (const candidate of HP_CFG_CANDIDATES) {
    try {
      if (!fs.existsSync(candidate)) {
        errors.push(`${candidate}: not found`);
        continue;
      }
      if (!fs.statSync(candidate).isFile()) {
        errors.push(`${candidate}: not a file`);
        continue;
      }

      const cfg = JSON.parse(fs.readFileSync(candidate, 'utf8'));
      const userPort = Number(cfg && cfg.user && cfg.user.port);
      const meshPort = Number(cfg && cfg.mesh && cfg.mesh.port);
      const result = {
        detected: true,
        configPath: candidate,
        cwd: STATE_ROOT,
        hpVersion: safeString(cfg && (cfg.hp_version || cfg.version), 64) || null,
        userPort: Number.isInteger(userPort) && userPort > 0 && userPort <= 65535 ? userPort : null,
        meshPort: Number.isInteger(meshPort) && meshPort > 0 && meshPort <= 65535 ? meshPort : null,
        nodeRole: safeString(cfg && cfg.node && cfg.node.role, 32) || null
      };

      // Prefer the first readable config that contains a valid user.port.
      if (result.userPort) return result;
      parsedFallback ||= result;
      errors.push(`${candidate}: user.port missing or invalid`);
    } catch (err) {
      errors.push(`${candidate}: ${safeString(err && err.message, 160)}`);
      // Do not stop here. Another layout candidate may be the real hp.cfg.
    }
  }

  if (parsedFallback) {
    return { ...parsedFallback, errors: errors.slice(0, 8) };
  }

  const envPort = Number(process.env.EVERADMIN_USER_PORT || process.env.EVERADMIN_HP_USER_PORT || 0);
  if (Number.isInteger(envPort) && envPort > 0 && envPort <= 65535) {
    return {
      detected: true,
      configPath: 'environment',
      cwd: STATE_ROOT,
      hpVersion: null,
      userPort: envPort,
      meshPort: null,
      nodeRole: null,
      errors: errors.slice(0, 8)
    };
  }

  return {
    detected: false,
    configPath: null,
    cwd: STATE_ROOT,
    userPort: null,
    meshPort: null,
    hpVersion: null,
    nodeRole: null,
    errors: errors.slice(0, 8)
  };
}

function assertEditableTextFile(file, rel) {
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) throw new Error('Code file not found.');
  const size = fs.statSync(file).size;
  if (size > MAX_CODE_EDITOR_BYTES) throw new Error(`File is too large for the in-browser editor (${size} bytes). Upload it as a file instead.`);
  const ext = path.extname(rel).toLowerCase();
  if (!EDITABLE_TEXT_EXTENSIONS.has(ext)) throw new Error('This file type is not available in the text editor. Upload it as a binary asset instead.');
  const buf = fs.readFileSync(file);
  if (buf.includes(0)) throw new Error('Binary files cannot be opened in the text editor.');
  return { content: buf.toString('utf8'), size, sha256: sha256Hex(buf) };
}

function sha256Hex(input) {
  return crypto.createHash('sha256').update(input).digest('hex');
}

function randomHex(bytes = 16) {
  return crypto.randomBytes(bytes).toString('hex');
}

function normalizeEdHex(value, kind = 'public key') {
  let hex = String(value || '').trim().toLowerCase();
  if (!/^[0-9a-f]+$/.test(hex)) throw new Error(`Invalid ${kind}.`);
  if (kind === 'public key') {
    if (hex.startsWith('ed') && hex.length >= 64 && hex.length <= 66) hex = hex.slice(2).padStart(64, '0');
    else if (hex.length >= 62 && hex.length <= 64) hex = hex.padStart(64, '0');
    else throw new Error('Invalid public key length. Expected ed + 64 hex chars.');
  } else if (kind === 'private key') {
    if (hex.length === 130 && hex.startsWith('ed')) hex = hex.slice(2);
    else if (hex.length !== 128) throw new Error('Invalid private key length. Expected ed + 128 hex chars.');
  }
  return `ed${hex}`;
}

function normalizePublicKey(value) {
  const key = normalizeEdHex(value, 'public key');
  if (!/^ed[0-9a-f]{64}$/.test(key)) throw new Error('Invalid public key.');
  return key;
}

function normalizePrivateKey(value) {
  const key = normalizeEdHex(value, 'private key');
  if (!/^ed[0-9a-f]{128}$/.test(key)) throw new Error('Invalid private key.');
  return key;
}

function normalizePublicKeyMaybe(value) {
  if (!value) return null;
  try {
    if (typeof value === 'string') return normalizePublicKey(value);
    if (Buffer.isBuffer(value) || value instanceof Uint8Array || Array.isArray(value)) return normalizePublicKey(Buffer.from(value).toString('hex'));
    if (value && value.data && Array.isArray(value.data)) return normalizePublicKey(Buffer.from(value.data).toString('hex'));
    if (typeof value === 'object') return normalizePublicKey(value.publicKey || value.public_key || value.pubkey || value.key || value.id || '');
  } catch { return null; }
  return null;
}

function getUserPublicKey(user) {
  const key = normalizePublicKeyMaybe(user && (user.publicKey || user.pubkey || user.key || user.id));
  if (!key) throw new Error('Could not read connected HotPocket user public key.');
  return key;
}

function normalizeRole(role) {
  const clean = safeString(role, 32).toLowerCase();
  if (!VALID_ROLES.has(clean)) throw new Error('Role must be head-admin or admin.');
  return clean;
}

function normalizeUsername(value) {
  const username = safeString(value, 64).toLowerCase();
  if (!/^[a-z0-9][a-z0-9._-]{1,63}$/.test(username)) throw new Error('Username must be 2-64 chars using letters, numbers, dot, underscore or hyphen.');
  return username;
}

function normalizeTtlSeconds(value) {
  const n = Number(value || DEFAULT_AUTH_TTL_SECONDS);
  if (!Number.isInteger(n) || n < 60 || n > MAX_AUTH_TTL_SECONDS) throw new Error('ttlSeconds must be between 60 seconds and 365 days.');
  return n;
}

function normalizePasswordCredential(input = {}) {
  const salt = safeString(input.passwordSalt || input.salt, 256);
  const key = safeString(input.passwordKey || input.key, 256).toLowerCase();
  if (!/^[a-zA-Z0-9+/=_-]{16,256}$/.test(salt)) throw new Error('Invalid password salt.');
  if (!/^[0-9a-f]{64}$/.test(key)) throw new Error('Invalid password-derived key. Expected 32-byte hex.');
  return { salt, key, iterations: PASSWORD_KDF_ITERATIONS, hash: 'SHA-256' };
}

function normalizeBase32Secret(secret, min = 16) {
  const clean = safeString(secret, 256).replace(/=+$/g, '').replace(/\s+/g, '').toUpperCase();
  if (!new RegExp(`^[A-Z2-7]{${min},}$`).test(clean)) throw new Error('Invalid base32 secret.');
  return clean;
}

function base32ToBuffer(base32) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const clean = normalizeBase32Secret(base32);
  let bits = '';
  for (const ch of clean) bits += alphabet.indexOf(ch).toString(2).padStart(5, '0');
  const out = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(out);
}

function totpCode(secret, timeMs, digits = TOTP_DIGITS, stepSeconds = TOTP_STEP_SECONDS, algorithm = 'sha1') {
  const counter = Math.floor(Number(timeMs) / 1000 / stepSeconds);
  const counterBuffer = Buffer.alloc(8);
  counterBuffer.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac(algorithm, base32ToBuffer(secret)).update(counterBuffer).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = (hmac.readUInt32BE(offset) & 0x7fffffff) % (10 ** digits);
  return String(code).padStart(digits, '0');
}

function verifyTotp(secret, code, timestampMs, windowSteps = 1) {
  const clean = safeString(code, 32);
  if (!new RegExp(`^[0-9]{${TOTP_DIGITS}}$`).test(clean)) return false;
  for (let i = -windowSteps; i <= windowSteps; i++) {
    if (totpCode(secret, Number(timestampMs) + i * TOTP_STEP_SECONDS * 1000) === clean) return true;
  }
  return false;
}


function defaultAuthState() {
  return { schemaVersion: 2, bootstrapComplete: false, users: {}, authorizedDevices: {}, usedNonces: {} };
}

function loadAuthState() {
  const state = readJson(AUTH_FILE, defaultAuthState());
  state.schemaVersion = 2;
  state.bootstrapComplete = !!state.bootstrapComplete;
  state.users = state.users && typeof state.users === 'object' ? state.users : {};
  state.authorizedDevices = state.authorizedDevices && typeof state.authorizedDevices === 'object' ? state.authorizedDevices : {};
  state.usedNonces = state.usedNonces && typeof state.usedNonces === 'object' ? state.usedNonces : {};
  return state;
}

function saveAuthState(state) { writeJson(AUTH_FILE, state); }

function countActiveHeadAdmins(state) {
  return Object.values(state.users || {}).filter(u => u && u.active !== false && u.role === ROLE_HEAD_ADMIN).length;
}

function normalizeUserRecord(id, record = {}) {
  return {
    id,
    method: record.method === 'everstoring' ? 'everstoring' : 'password',
    username: record.username || null,
    publicKey: record.publicKey || null,
    role: normalizeRole(record.role || ROLE_ADMIN),
    active: record.active !== false,
    password: record.password || null,
    totpSecret: record.totpSecret || null,
    createdAt: record.createdAt || null,
    createdBy: record.createdBy || null,
    updatedAt: record.updatedAt || null,
    updatedBy: record.updatedBy || null
  };
}

function publicUserRecord(record) {
  return {
    id: record.id,
    method: record.method,
    username: record.username || null,
    publicKey: record.publicKey || null,
    role: record.role,
    active: record.active !== false,
    twoFactorEnabled: !!record.totpSecret,
    createdAt: record.createdAt || null,
    createdBy: record.createdBy || null,
    updatedAt: record.updatedAt || null,
    updatedBy: record.updatedBy || null
  };
}

function getUserRecord(state, userId) {
  const raw = state.users && state.users[userId];
  if (!raw) return null;
  try { return normalizeUserRecord(userId, raw); } catch { return null; }
}

function findPasswordUser(state, username) {
  const id = `pwd:${normalizeUsername(username)}`;
  return getUserRecord(state, id);
}

function findEverstoringUserByPublicKey(state, publicKey) {
  const key = normalizePublicKey(publicKey);
  return getUserRecord(state, `ev:${key}`);
}

function cleanupAuthState(state, timestampMs) {
  let changed = false;
  for (const [key, auth] of Object.entries(state.authorizedDevices || {})) {
    const user = auth && getUserRecord(state, auth.userId);
    if (!auth || !user || user.active === false || Number(auth.expiresAt || 0) <= timestampMs) {
      delete state.authorizedDevices[key];
      changed = true;
      continue;
    }
    if (auth.role !== user.role) { auth.role = user.role; changed = true; }
  }
  const cutoff = timestampMs - (7 * 24 * 60 * 60 * 1000);
  for (const [nonce, rec] of Object.entries(state.usedNonces || {})) {
    if (Number(rec && rec.usedAt || 0) < cutoff) { delete state.usedNonces[nonce]; changed = true; }
  }
  return changed;
}

function getDeviceAuth(state, publicKey, timestampMs) {
  const key = normalizePublicKey(publicKey);
  const auth = state.authorizedDevices[key];
  if (!auth || Number(auth.expiresAt || 0) <= timestampMs) return null;
  const user = getUserRecord(state, auth.userId);
  if (!user || user.active === false) return null;
  return { ...auth, role: user.role, user };
}

function revokeUserSessions(state, userId) {
  for (const [key, auth] of Object.entries(state.authorizedDevices || {})) {
    if (auth && auth.userId === userId) delete state.authorizedDevices[key];
  }
}

function passwordProofMessage(username, devicePublicKey, nonce, ttlSeconds) {
  return `everadmin-password-login-v1|${normalizeUsername(username)}|${normalizePublicKey(devicePublicKey)}|${nonce}|${ttlSeconds}`;
}

function verifyPasswordProof(user, message = {}) {
  if (!user.password || !user.password.key) throw new Error('Password login is not configured for this user.');
  const nonce = safeString(message.nonce, 128);
  if (!/^[a-fA-F0-9]{32,128}$/.test(nonce)) throw new Error('Invalid login nonce.');
  const ttlSeconds = normalizeTtlSeconds(message.ttlSeconds);
  const devicePublicKey = normalizePublicKey(message.devicePublicKey);
  const expected = crypto.createHmac('sha256', Buffer.from(user.password.key, 'hex'))
    .update(passwordProofMessage(user.username, devicePublicKey, nonce, ttlSeconds), 'utf8')
    .digest('hex');
  const supplied = safeString(message.proof, 128).toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(supplied)) return false;
  return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(supplied, 'hex'));
}

function derivePublicKeyFromHotPocketPrivateKey(privateKey) {
  const clean = normalizePrivateKey(privateKey).slice(2);
  const raw = Buffer.from(clean, 'hex');
  if (raw.length !== 64) throw new Error('Invalid HotPocket private key.');
  const seed = raw.subarray(0, 32);
  const embeddedPublic = raw.subarray(32, 64);
  const pkcs8Prefix = Buffer.from('302e020100300506032b657004220420', 'hex');
  const keyObj = crypto.createPrivateKey({ key: Buffer.concat([pkcs8Prefix, seed]), format: 'der', type: 'pkcs8' });
  const spki = crypto.createPublicKey(keyObj).export({ format: 'der', type: 'spki' });
  const derived = spki.subarray(spki.length - 32);
  if (!derived.equals(embeddedPublic)) throw new Error('Private key seed/public key mismatch.');
  return normalizePublicKey(derived.toString('hex'));
}

async function sendOutput(user, payload) {
  if (!runtime || !runtime.bson) throw new Error('BSON runtime is unavailable.');
  await user.send(runtime.bson.serialize(payload));
}

async function authStatus(user, message, ctx) {
  const state = loadAuthState();
  const timestampMs = nowMs(ctx);
  const changed = cleanupAuthState(state, timestampMs);
  const devicePublicKey = getUserPublicKey(user);
  const auth = getDeviceAuth(state, devicePublicKey, timestampMs);
  if (!ctx.readonly && changed) saveAuthState(state);
  const methods = unique(Object.values(state.users || {}).filter(u => u && u.active !== false).map(u => u.method));
  await sendOutput(user, {
    type: 'auth-status', actionId: message.actionId || null,
    appName: APP_NAME, appVersion: APP_VERSION,
    bootstrapComplete: state.bootstrapComplete,
    configuredMethods: methods,
    devicePublicKey,
    authorized: !!auth,
    role: auth ? auth.role : null,
    userId: auth ? auth.userId : null,
    username: auth && auth.user ? auth.user.username : null,
    authMethod: auth && auth.user ? auth.user.method : null,
    expiresAt: auth ? auth.expiresAt : null,
    canManageUsers: !!auth && auth.role === ROLE_HEAD_ADMIN,
    now: timestampMs
  });
}

async function bootstrapHeadAdmin(user, message, ctx) {
  if (ctx.readonly) throw new Error('Bootstrap requires consensus input.');
  const state = loadAuthState();
  if (state.bootstrapComplete) throw new Error('Head admin is already bootstrapped.');
  const timestampMs = nowMs(ctx);
  const method = safeString(message.method, 32).toLowerCase();
  let record;
  let id;
  if (method === 'password') {
    const username = normalizeUsername(message.username || 'admin');
    id = `pwd:${username}`;
    record = {
      id, method: 'password', username, publicKey: null,
      role: ROLE_HEAD_ADMIN, active: true,
      password: normalizePasswordCredential(message),
      totpSecret: message.totpSecret ? normalizeBase32Secret(message.totpSecret) : null,
      createdAt: timestampMs, createdBy: id, updatedAt: timestampMs, updatedBy: id
    };
  } else if (method === 'everstoring') {
    const publicKey = normalizePublicKey(message.publicKey || message.headAdminPublicKey);
    id = `ev:${publicKey}`;
    record = {
      id, method: 'everstoring', username: null, publicKey,
      role: ROLE_HEAD_ADMIN, active: true,
      password: null, totpSecret: message.totpSecret ? normalizeBase32Secret(message.totpSecret) : null,
      createdAt: timestampMs, createdBy: id, updatedAt: timestampMs, updatedBy: id
    };
  } else throw new Error('Bootstrap method must be password or everstoring.');
  state.bootstrapComplete = true;
  state.users = { [id]: record };
  state.authorizedDevices = {};
  state.usedNonces = {};
  saveAuthState(state);
  await sendOutput(user, { type: 'bootstrap-success', actionId: message.actionId || null, method, user: publicUserRecord(record), message: 'Head admin created. Sign in with the selected method.' });
}

async function passwordLoginInfo(user, message, ctx) {
  const state = loadAuthState();
  let account = null;
  try { account = findPasswordUser(state, message.username); } catch {}
  await sendOutput(user, {
    type: 'password-login-info', actionId: message.actionId || null,
    found: !!account && account.active !== false,
    username: account && account.active !== false ? account.username : normalizeUsername(message.username),
    salt: account && account.active !== false && account.password ? account.password.salt : null,
    iterations: account && account.active !== false && account.password ? account.password.iterations : PASSWORD_KDF_ITERATIONS,
    twoFactorEnabled: !!(account && account.active !== false && account.totpSecret)
  });
}

async function passwordLogin(user, message, ctx) {
  if (ctx.readonly) throw new Error('Password login requires consensus input.');
  const state = loadAuthState();
  if (!state.bootstrapComplete) throw new Error('Head admin is not bootstrapped.');
  const timestampMs = nowMs(ctx);
  cleanupAuthState(state, timestampMs);
  const account = findPasswordUser(state, message.username);
  if (!account || account.active === false) throw new Error('Invalid username or password.');
  const nonce = safeString(message.nonce, 128);
  if (!/^[a-fA-F0-9]{32,128}$/.test(nonce) || state.usedNonces[nonce]) throw new Error('Invalid or already-used login nonce.');
  if (!verifyPasswordProof(account, message)) throw new Error('Invalid username or password.');
  if (account.totpSecret && !verifyTotp(account.totpSecret, message.totpCode, timestampMs)) throw new Error('Invalid 2FA code.');
  const devicePublicKey = normalizePublicKey(message.devicePublicKey);
  const ttlSeconds = normalizeTtlSeconds(message.ttlSeconds);
  const submitter = getUserPublicKey(user);
  const expiresAt = timestampMs + ttlSeconds * 1000;
  state.authorizedDevices[devicePublicKey] = { userId: account.id, role: account.role, approvedBy: account.id, submittedBy: submitter, method: 'password', approvedAt: timestampMs, expiresAt, nonce };
  state.usedNonces[nonce] = { usedAt: timestampMs, devicePublicKey, userId: account.id };
  saveAuthState(state);
  await sendOutput(user, { type: 'auth-success', actionId: message.actionId || null, devicePublicKey, userId: account.id, username: account.username, role: account.role, authMethod: 'password', expiresAt });
}

function everstoringProofMessage(signerPublicKey, devicePublicKey, nonce, ttlSeconds) {
  return `everadmin-everstoring-login-v1|${normalizePublicKey(signerPublicKey)}|${normalizePublicKey(devicePublicKey)}|${nonce}|${ttlSeconds}`;
}

function verifyEd25519Signature(publicKey, text, signatureHex) {
  const key = normalizePublicKey(publicKey);
  const raw = Buffer.from(key.slice(2), 'hex');
  const spkiPrefix = Buffer.from('302a300506032b6570032100', 'hex');
  const keyObject = crypto.createPublicKey({ key: Buffer.concat([spkiPrefix, raw]), format: 'der', type: 'spki' });
  const sig = safeString(signatureHex, 256).toLowerCase();
  if (!/^[0-9a-f]{128}$/.test(sig)) return false;
  return crypto.verify(null, Buffer.from(text, 'utf8'), keyObject, Buffer.from(sig, 'hex'));
}

async function everstoringLoginInfo(user, message, ctx) {
  const state = loadAuthState();
  let account = null;
  try { account = findEverstoringUserByPublicKey(state, message.signerPublicKey || message.publicKey); } catch {}
  await sendOutput(user, {
    type: 'everstoring-login-info', actionId: message.actionId || null,
    found: !!account && account.active !== false,
    signerPublicKey: account && account.active !== false ? account.publicKey : null,
    twoFactorEnabled: !!(account && account.active !== false && account.totpSecret)
  });
}

async function everstoringLogin(user, message, ctx) {
  if (ctx.readonly) throw new Error('Everstoring login requires consensus input.');
  const state = loadAuthState();
  if (!state.bootstrapComplete) throw new Error('Head admin is not bootstrapped.');
  const timestampMs = nowMs(ctx);
  cleanupAuthState(state, timestampMs);
  const signerPublicKey = normalizePublicKey(message.signerPublicKey || message.publicKey);
  const account = findEverstoringUserByPublicKey(state, signerPublicKey);
  if (!account || account.active === false) throw new Error('Unknown or inactive signer.');
  const devicePublicKey = normalizePublicKey(message.devicePublicKey);
  const nonce = safeString(message.nonce, 128);
  if (!/^[a-fA-F0-9]{32,128}$/.test(nonce) || state.usedNonces[nonce]) throw new Error('Invalid or already-used login nonce.');
  const ttlSeconds = normalizeTtlSeconds(message.ttlSeconds);
  const proofText = everstoringProofMessage(signerPublicKey, devicePublicKey, nonce, ttlSeconds);
  if (!verifyEd25519Signature(signerPublicKey, proofText, message.signature)) throw new Error('Invalid Everstoring/signer signature.');
  if (account.totpSecret && !verifyTotp(account.totpSecret, message.totpCode, timestampMs)) throw new Error('Invalid 2FA code.');
  const submitter = getUserPublicKey(user);
  const expiresAt = timestampMs + ttlSeconds * 1000;
  state.authorizedDevices[devicePublicKey] = { userId: account.id, role: account.role, approvedBy: signerPublicKey, submittedBy: submitter, method: 'everstoring', approvedAt: timestampMs, expiresAt, nonce };
  state.usedNonces[nonce] = { usedAt: timestampMs, devicePublicKey, userId: account.id };
  saveAuthState(state);
  await sendOutput(user, { type: 'auth-success', actionId: message.actionId || null, devicePublicKey, userId: account.id, signerPublicKey, role: account.role, authMethod: 'everstoring', expiresAt });
}

async function requireRole(user, message, ctx, roles = [ROLE_HEAD_ADMIN, ROLE_ADMIN]) {
  const state = loadAuthState();
  if (!state.bootstrapComplete) { await sendOutput(user, { type: 'error', action: message.type, actionId: message.actionId || null, error: 'Head admin is not bootstrapped.' }); return null; }
  const timestampMs = nowMs(ctx);
  const changed = cleanupAuthState(state, timestampMs);
  const publicKey = getUserPublicKey(user);
  const auth = getDeviceAuth(state, publicKey, timestampMs);
  if (!ctx.readonly && changed) saveAuthState(state);
  if (!auth) { await sendOutput(user, { type: 'error', action: message.type, actionId: message.actionId || null, error: 'Unauthorized or session expired.' }); return null; }
  if (!roles.includes(auth.role)) { await sendOutput(user, { type: 'error', action: message.type, actionId: message.actionId || null, error: 'Permission denied.' }); return null; }
  if (auth.role === ROLE_ADMIN && !ADMIN_ALLOWED_ACTIONS.has(message.type)) { await sendOutput(user, { type: 'error', action: message.type, actionId: message.actionId || null, error: 'This action requires head-admin.' }); return null; }
  return { state, auth, publicKey, timestampMs, user: auth.user };
}

async function logoutDevice(user, message, ctx) {
  if (ctx.readonly) throw new Error('Logout requires consensus input.');
  const authz = await requireRole(user, message, ctx);
  if (!authz) return;
  delete authz.state.authorizedDevices[authz.publicKey];
  saveAuthState(authz.state);
  await sendOutput(user, { type: 'logout-success', actionId: message.actionId || null });
}

async function listUsers(user, message, ctx) {
  const authz = await requireRole(user, message, ctx, [ROLE_HEAD_ADMIN]); if (!authz) return;
  const users = Object.entries(authz.state.users || {}).map(([id, r]) => publicUserRecord(normalizeUserRecord(id, r))).sort((a,b) => String(a.id).localeCompare(String(b.id)));
  await sendOutput(user, { type: 'users', actionId: message.actionId || null, users, activeHeadAdmins: countActiveHeadAdmins(authz.state) });
}

async function addUser(user, message, ctx) {
  if (ctx.readonly) throw new Error('User changes require consensus input.');
  const authz = await requireRole(user, message, ctx, [ROLE_HEAD_ADMIN]); if (!authz) return;
  const method = safeString(message.method, 32).toLowerCase();
  const role = normalizeRole(message.role || ROLE_ADMIN);
  let id, record;
  if (method === 'password') {
    const username = normalizeUsername(message.username);
    id = `pwd:${username}`;
    if (authz.state.users[id]) throw new Error('User already exists.');
    record = { id, method, username, publicKey: null, role, active: true, password: normalizePasswordCredential(message), totpSecret: message.totpSecret ? normalizeBase32Secret(message.totpSecret) : null };
  } else if (method === 'everstoring') {
    const publicKey = normalizePublicKey(message.publicKey);
    id = `ev:${publicKey}`;
    if (authz.state.users[id]) throw new Error('User already exists.');
    record = { id, method, username: null, publicKey, role, active: true, password: null, totpSecret: message.totpSecret ? normalizeBase32Secret(message.totpSecret) : null };
  } else throw new Error('User method must be password or everstoring.');
  record.createdAt = authz.timestampMs; record.createdBy = authz.auth.userId; record.updatedAt = authz.timestampMs; record.updatedBy = authz.auth.userId;
  authz.state.users[id] = record;
  saveAuthState(authz.state);
  await sendOutput(user, { type: 'user-added', actionId: message.actionId || null, user: publicUserRecord(record) });
}

async function setUserRole(user, message, ctx) {
  if (ctx.readonly) throw new Error('User changes require consensus input.');
  const authz = await requireRole(user, message, ctx, [ROLE_HEAD_ADMIN]); if (!authz) return;
  const id = safeString(message.userId, 256);
  const record = getUserRecord(authz.state, id); if (!record) throw new Error('User not found.');
  const nextRole = normalizeRole(message.role);
  if (record.role === ROLE_HEAD_ADMIN && nextRole !== ROLE_HEAD_ADMIN && countActiveHeadAdmins(authz.state) <= 1) throw new Error('Cannot demote the last active head-admin.');
  record.role = nextRole; record.updatedAt = authz.timestampMs; record.updatedBy = authz.auth.userId;
  authz.state.users[id] = record; revokeUserSessions(authz.state, id); saveAuthState(authz.state);
  await sendOutput(user, { type: 'user-role-set', actionId: message.actionId || null, user: publicUserRecord(record), sessionsRevoked: true });
}

async function removeUser(user, message, ctx) {
  if (ctx.readonly) throw new Error('User changes require consensus input.');
  const authz = await requireRole(user, message, ctx, [ROLE_HEAD_ADMIN]); if (!authz) return;
  const id = safeString(message.userId, 256);
  const record = getUserRecord(authz.state, id); if (!record) throw new Error('User not found.');
  if (record.role === ROLE_HEAD_ADMIN && record.active !== false && countActiveHeadAdmins(authz.state) <= 1) throw new Error('Cannot remove the last active head-admin.');
  record.active = false; record.updatedAt = authz.timestampMs; record.updatedBy = authz.auth.userId;
  authz.state.users[id] = record; revokeUserSessions(authz.state, id); saveAuthState(authz.state);
  await sendOutput(user, { type: 'user-removed', actionId: message.actionId || null, user: publicUserRecord(record) });
}

async function changePassword(user, message, ctx) {
  if (ctx.readonly) throw new Error('Password changes require consensus input.');
  const authz = await requireRole(user, message, ctx); if (!authz) return;
  const id = safeString(message.userId || authz.auth.userId, 256);
  if (authz.auth.role !== ROLE_HEAD_ADMIN && id !== authz.auth.userId) throw new Error('Admins can only change their own password.');
  const record = getUserRecord(authz.state, id); if (!record || record.method !== 'password') throw new Error('Password user not found.');
  record.password = normalizePasswordCredential(message); record.updatedAt = authz.timestampMs; record.updatedBy = authz.auth.userId;
  authz.state.users[id] = record; revokeUserSessions(authz.state, id); saveAuthState(authz.state);
  await sendOutput(user, { type: 'password-changed', actionId: message.actionId || null, userId: id, sessionsRevoked: true });
}

async function setUserTwoFactor(user, message, ctx) {
  if (ctx.readonly) throw new Error('2FA changes require consensus input.');
  const authz = await requireRole(user, message, ctx); if (!authz) return;
  const id = safeString(message.userId || authz.auth.userId, 256);
  if (authz.auth.role !== ROLE_HEAD_ADMIN && id !== authz.auth.userId) throw new Error('Admins can only change their own 2FA.');
  const record = getUserRecord(authz.state, id); if (!record || record.method !== 'password') throw new Error('Password user not found.');
  const enabled = message.enabled !== false;
  record.totpSecret = enabled ? normalizeBase32Secret(message.totpSecret) : null;
  record.updatedAt = authz.timestampMs; record.updatedBy = authz.auth.userId;
  authz.state.users[id] = record; revokeUserSessions(authz.state, id); saveAuthState(authz.state);
  await sendOutput(user, { type: 'user-2fa-set', actionId: message.actionId || null, userId: id, enabled, sessionsRevoked: true });
}

function getContractConfigSection(cfg = {}) { return cfg.contract && typeof cfg.contract === 'object' ? cfg.contract : cfg; }
function getOrCreate(parent, key) { if (!parent[key] || typeof parent[key] !== 'object' || Array.isArray(parent[key])) parent[key] = {}; return parent[key]; }
function getConfigUnl(cfg = {}) { return unique(getContractConfigSection(cfg).unl || []).map(normalizePublicKey).sort(); }
function getLocalNodePublicKey(ctx, cfg = {}) { const nodeCfg = cfg.node && typeof cfg.node === 'object' ? cfg.node : cfg; return normalizePublicKeyMaybe(ctx.publicKey) || normalizePublicKeyMaybe(ctx.public_key) || normalizePublicKeyMaybe(nodeCfg.public_key) || normalizePublicKeyMaybe(nodeCfg.publicKey) || null; }
function normalizeVisibility(value) { const mode = safeString(value, 16).toLowerCase(); if (!['public','private'].includes(mode)) throw new Error('Mode must be public or private.'); return mode; }
function readVisibility(cfg = {}) { const c = getContractConfigSection(cfg); const consensus = c.consensus || {}; const npl = c.npl || {}; return { consensus: normalizeVisibility(consensus.mode || 'public'), npl: normalizeVisibility(npl.mode || consensus.mode || 'public') }; }
function readRoundtime(cfg = {}) { const c = getContractConfigSection(cfg); const n = Number(c.consensus && c.consensus.roundtime); return Number.isInteger(n) ? n : null; }
function readThreshold(cfg = {}) { const c = getContractConfigSection(cfg); const totalNodes = getConfigUnl(cfg).length; const threshold = Number(c.consensus && c.consensus.threshold); const percent = Number.isInteger(threshold) && threshold >= 1 && threshold <= 100 ? threshold : 80; return { threshold: percent, totalNodes, requiredVotes: totalNodes ? Math.max(1, Math.ceil(totalNodes * percent / 100)) : 0 }; }
function thresholdForVotes(requiredVotes, totalNodes) { const r = Number(requiredVotes), t = Number(totalNodes); if (!Number.isInteger(r) || !Number.isInteger(t) || t < 1 || r < 1 || r > t) throw new Error('Invalid requiredVotes/totalNodes.'); return Math.max(1, Math.min(100, Math.floor(r * 100 / t))); }

function normalizeDomain(value) {
  let domain = safeString(value, 512).replace(/^https?:\/\//i, '').split('/')[0].trim();
  domain = domain.replace(/:(gptcp1|\d+)$/i, '');
  if (domain && (/\s/.test(domain) || domain.includes('/'))) throw new Error('Invalid domain.');
  return domain;
}
function loadUnlMetadata() { const d = readJson(UNL_METADATA_FILE, {}); return d && typeof d === 'object' && !Array.isArray(d) ? d : {}; }
function saveUnlMetadata(d) { writeJson(UNL_METADATA_FILE, d); }
function loadRemovedUnls() { const d = readJson(REMOVED_UNLS_FILE, []); return Array.isArray(d) ? d : []; }
function saveRemovedUnls(d) { writeJson(REMOVED_UNLS_FILE, d); }
function updateUnlMeta(publicKey, message, authz) { const key = normalizePublicKey(publicKey); const all = loadUnlMetadata(); const old = all[key] || {}; const domain = normalizeDomain(message.domain || old.domain || ''); all[key] = { publicKey:key, domain, url: domain ? `https://${domain}:gptcp1` : '', updatedAt:authz.timestampMs, updatedBy:authz.auth.userId }; saveUnlMetadata(all); return all[key]; }

function defaultPruneState() {
  return {
    settings: {
      enabled: false, healthAutoEnabled: true, healthEveryLedgers: 10, healthTimeoutMs: 2500,
      minDeadMinutes: 15, minInstancesAgreeing: 1, maxDisagreePercent: 50, maxPurgePerRun: 2,
      autoReaddEnabled: false, readdEveryLedgers: 60, readdMaxPerRun: 2
    },
    nodes: {}, lastHealthLedger: 0, lastPruneLedger: 0, lastReaddLedger: 0, lastHealthAt: null, lastPruneAt: null, lastReaddAt: null
  };
}
function loadPruneState() { const s = readJson(UNL_PRUNE_FILE, defaultPruneState()); s.settings = { ...defaultPruneState().settings, ...(s.settings || {}) }; s.settings.healthAutoEnabled = false; s.nodes = s.nodes && typeof s.nodes === 'object' ? s.nodes : {}; return s; }
function savePruneState(s) { writeJson(UNL_PRUNE_FILE, s); }
function ledgerNo(ctx) { const n = Number(ctx && ctx.lclSeqNo); return Number.isInteger(n) && n > 0 ? n : 0; }
function boundInt(v, fallback, min, max) { const n = Number(v); return Number.isInteger(n) && n >= min && n <= max ? n : fallback; }
function pruneStatus(state, cfg, timestampMs) {
  const unl = getConfigUnl(cfg); const threshold = readThreshold(cfg); const settings = state.settings;
  const nodes = unl.map(publicKey => { const r = state.nodes[publicKey] || {}; const silentForMs = r.deadSince ? Math.max(0, timestampMs - Number(r.deadSince)) : 0; return { publicKey, status:r.status || 'unknown', lastAliveAt:r.lastAliveAt || null, deadSince:r.deadSince || null, lastReportAt:r.lastReportAt || null, silentForMs, eligibleForPurge:r.status === 'silent' && silentForMs >= settings.minDeadMinutes * 60000 }; });
  return { settings, totalNodes:unl.length, threshold:threshold.threshold, requiredVotes:threshold.requiredVotes, liveNodes:nodes.filter(n=>n.status==='alive').length, silentNodes:nodes.filter(n=>n.status==='silent').length, eligibleNodes:nodes.filter(n=>n.eligibleForPurge).length, nodes, removedUnls:loadRemovedUnls(), lastHealthAt:state.lastHealthAt || null, lastPruneAt:state.lastPruneAt || null, lastReaddAt:state.lastReaddAt || null };
}
function nplToString(msg) { if (Buffer.isBuffer(msg)) return msg.toString('utf8'); if (msg instanceof Uint8Array) return Buffer.from(msg).toString('utf8'); return String(msg || ''); }
function nplSender(node) { return normalizePublicKeyMaybe(node && (node.publicKey || node.public_key || node)); }

function validRuntimePort(value){const n=Number(value);return Number.isInteger(n)&&n>0&&n<=65535?n:null;}
function publicRuntimeRecord(runtimeInfo={}){return{userPort:validRuntimePort(runtimeInfo.userPort),meshPort:validRuntimePort(runtimeInfo.meshPort),hpVersion:safeString(runtimeInfo.hpVersion,64)||null,updatedAt:Date.now()};}

async function refreshLocalHealthRuntime(ctx) {
  if (ctx.readonly) return readLocalHealth();
  let cfg={}; try{cfg=await ctx.getConfig();}catch{}
  const local=getLocalNodePublicKey(ctx,cfg);
  const runtimeInfo=readNodeRuntimeConfig();
  const runtimeRecord=publicRuntimeRecord(runtimeInfo);
  const ts=nowMs(ctx);
  const snapshot=readLocalHealth()||{};
  snapshot.schemaVersion=2;
  snapshot.reporterPublicKey=local||normalizePublicKeyMaybe(snapshot.reporterPublicKey)||null;
  snapshot.ledgerNo=ledgerNo(ctx)||Number(snapshot.ledgerNo)||0;
  snapshot.ledgerHash=safeString(ctx.lclHash||snapshot.ledgerHash||'',256);
  snapshot.observedAt=Number(snapshot.observedAt)||ts;
  snapshot.runtimeUpdatedAt=ts;
  snapshot.localRuntime={nodePublicKey:local||null,...runtimeRecord,updatedAt:ts};
  snapshot.observations=snapshot.observations&&typeof snapshot.observations==='object'&&!Array.isArray(snapshot.observations)?snapshot.observations:{};
  if(local){const old=snapshot.observations[local]||{};snapshot.observations[local]={...old,status:'alive',observedAt:ts,userPort:runtimeRecord.userPort,meshPort:runtimeRecord.meshPort};}
  writeLocalCustomHealth(snapshot);
  return snapshot;
}

async function probeLocalHealth(ctx) {
  if (ctx.readonly || !ctx.unl || typeof ctx.unl.send !== 'function' || typeof ctx.unl.onMessage !== 'function') return null;
  const cfg = await ctx.getConfig(); const unl = getConfigUnl(cfg); if (!unl.length) return null;
  const settings = loadPruneState().settings; const timeout = boundInt(settings.healthTimeoutMs, 2500, 500, 15000);
  const expected = new Set(unl); const alive = new Set(); const runtimes = {};
  const local = getLocalNodePublicKey(ctx, cfg);
  const localRuntime = publicRuntimeRecord(readNodeRuntimeConfig());
  if (local && expected.has(local)) { alive.add(local); runtimes[local]=localRuntime; }
  const roundId = `health:${ledgerNo(ctx)}:${safeString(ctx.lclHash || '', 128) || 'nohash'}`;
  let done = false, resolveWait; let timer;
  const finish = () => { if (done) return; done = true; if (timer) clearTimeout(timer); if (resolveWait) resolveWait(); };
  ctx.unl.onMessage((node, msg) => { try { const sender = nplSender(node); if (!sender || !expected.has(sender)) return; const p = JSON.parse(nplToString(msg)); if (p.type !== HEALTH_NPL_TYPE || p.roundId !== roundId || normalizePublicKey(p.publicKey) !== sender) return; alive.add(sender); runtimes[sender]={userPort:validRuntimePort(p.userPort),meshPort:validRuntimePort(p.meshPort),hpVersion:null,updatedAt:nowMs(ctx)}; if (alive.size >= expected.size) finish(); } catch {} });
  const wait = new Promise(resolve => { resolveWait = resolve; timer = setTimeout(finish, timeout); });
  if (local && expected.has(local)) await ctx.unl.send(JSON.stringify({ type:HEALTH_NPL_TYPE, roundId, publicKey:local, userPort:localRuntime.userPort, meshPort:localRuntime.meshPort }));
  if (alive.size >= expected.size) finish();
  await wait;
  const ts = nowMs(ctx); const observations = {};
  for (const key of unl) { const r=runtimes[key]||{}; observations[key] = { status: alive.has(key) ? 'alive' : 'silent', observedAt: ts, userPort:validRuntimePort(r.userPort), meshPort:validRuntimePort(r.meshPort) }; }
  const snapshot = { schemaVersion:2, reporterPublicKey:local, ledgerNo:ledgerNo(ctx), ledgerHash:safeString(ctx.lclHash || '',256), observedAt:ts, runtimeUpdatedAt:ts, localRuntime:{nodePublicKey:local||null,...localRuntime,updatedAt:ts}, observations };
  writeLocalCustomHealth(snapshot);
  return snapshot;
}
function writeLocalCustomHealth(snapshot){try{ensureDir(path.dirname(LOCAL_HEALTH_FILE));fs.writeFileSync(LOCAL_HEALTH_FILE,JSON.stringify(snapshot,null,2));return true;}catch(err){console.log(`Local unl-health.json write failed: ${err.message}`);return false;}}
function readLocalHealth(){const d=readJson(LOCAL_HEALTH_FILE,null);return d&&typeof d==='object'&&!Array.isArray(d)?d:null;}
function runtimeFromLocalHealth(){const snapshot=readLocalHealth();const local=snapshot&&snapshot.localRuntime&&typeof snapshot.localRuntime==='object'?snapshot.localRuntime:null;const userPort=validRuntimePort(local&&local.userPort);if(userPort)return{detected:true,source:'../unl-health.json',configPath:null,cwd:STATE_ROOT,hpVersion:safeString(local.hpVersion,64)||null,userPort,meshPort:validRuntimePort(local.meshPort),nodeRole:null,nodePublicKey:normalizePublicKeyMaybe(local.nodePublicKey)||normalizePublicKeyMaybe(snapshot.reporterPublicKey)||null,updatedAt:Number(local.updatedAt)||Number(snapshot.runtimeUpdatedAt)||null};const fallback=readNodeRuntimeConfig();return{...fallback,source:'hp.cfg-fallback'};}

function calculateManagedThreshold(cfg, state) {
  const total = getConfigUnl(cfg).length; if (!total) return null;
  const minAgree = Math.max(1, Math.min(total, boundInt(state.settings.minInstancesAgreeing, 1, 1, 100000)));
  const maxDisagree = Math.max(0, Math.min(99, Number(state.settings.maxDisagreePercent || 50)));
  const percentageVotes = Math.max(1, Math.ceil(total * (100 - maxDisagree) / 100));
  const requiredVotes = Math.max(minAgree, percentageVotes);
  return { requiredVotes, totalNodes:total, threshold:thresholdForVotes(requiredVotes, total) };
}
function applyManagedThreshold(cfg, state) { if (!state.settings.enabled) return null; const info = calculateManagedThreshold(cfg,state); if (!info) return null; const c = getContractConfigSection(cfg); getOrCreate(c,'consensus').threshold = info.threshold; return info; }

async function evaluatePrune(ctx, actor='automatic', trigger='manual') {
  const cfg = await ctx.getConfig(); const c = getContractConfigSection(cfg); const unl = getConfigUnl(cfg); const state = loadPruneState(); const ts = nowMs(ctx);
  if (!state.settings.enabled) return { changed:false, reason:'disabled', status:pruneStatus(state,cfg,ts) };
  const eligible = unl.filter(k => { const r=state.nodes[k]||{}; return r.status==='silent' && r.deadSince && ts-Number(r.deadSince) >= Number(state.settings.minDeadMinutes)*60000; });
  const max = boundInt(state.settings.maxPurgePerRun,2,1,100); const remove = eligible.slice(0,max);
  const minAgree = boundInt(state.settings.minInstancesAgreeing,1,1,100000);
  while (remove.length && unl.length - remove.length < minAgree) remove.pop();
  if (!remove.length) { state.lastPruneAt=ts; state.lastPruneLedger=ledgerNo(ctx); savePruneState(state); return {changed:false,reason:'nothing-safe-to-remove',status:pruneStatus(state,cfg,ts)}; }
  c.unl = unl.filter(k => !remove.includes(k));
  const meta = loadUnlMetadata(); const removed = loadRemovedUnls();
  for (const key of remove) { const m=meta[key]||{}; removed.unshift({ publicKey:key, domain:m.domain||'', url:m.url||'', removedAt:ts, removedBy:actor, reason:`silent:${trigger}` }); }
  saveRemovedUnls(removed.slice(0,10000)); state.lastPruneAt=ts; state.lastPruneLedger=ledgerNo(ctx); applyManagedThreshold(cfg,state); await ctx.updateConfig(cfg); savePruneState(state);
  return {changed:true,removed:remove,status:pruneStatus(state,cfg,ts)};
}

async function evaluateReadd(ctx, actor='automatic', trigger='manual') {
  const cfg = await ctx.getConfig(); const c=getContractConfigSection(cfg); const current=getConfigUnl(cfg); const state=loadPruneState(); const removed=loadRemovedUnls(); const ts=nowMs(ctx);
  const candidates = removed.filter(r => r && r.healthStatus === 'alive').slice(0,boundInt(state.settings.readdMaxPerRun,2,1,100));
  if (!candidates.length) { state.lastReaddAt=ts; state.lastReaddLedger=ledgerNo(ctx); savePruneState(state); return {changed:false,reason:'no-alive-removed-nodes'}; }
  const add = candidates.map(r=>normalizePublicKey(r.publicKey)).filter(k=>!current.includes(k)); c.unl = unique([...current,...add]).map(normalizePublicKey).sort();
  saveRemovedUnls(removed.filter(r=>!add.includes(normalizePublicKeyMaybe(r.publicKey)))); state.lastReaddAt=ts; state.lastReaddLedger=ledgerNo(ctx); applyManagedThreshold(cfg,state); await ctx.updateConfig(cfg); savePruneState(state); return {changed:add.length>0,added:add};
}

async function listUnls(user, message, ctx) {
  const authz=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]); if(!authz)return;
  const cfg=await ctx.getConfig(); const meta=loadUnlMetadata(); const state=loadPruneState(); const status=pruneStatus(state,cfg,authz.timestampMs);
  const unls=getConfigUnl(cfg).map((publicKey,index)=>({ index, publicKey, ...(meta[publicKey]||{}), ...(state.nodes[publicKey]||{}) }));
  await sendOutput(user,{type:'unls',actionId:message.actionId||null,unls,removedUnls:loadRemovedUnls(),visibilityMode:readVisibility(cfg),consensusThreshold:readThreshold(cfg),consensusRoundtime:readRoundtime(cfg),prune:status});
}
async function addUnl(user,message,ctx){ if(ctx.readonly)throw new Error('UNL changes require consensus input.'); const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const key=normalizePublicKey(message.publicKey);const cfg=await ctx.getConfig();const c=getContractConfigSection(cfg);const unl=getConfigUnl(cfg);if(!unl.includes(key))c.unl=unique([...unl,key]).map(normalizePublicKey).sort();const m=updateUnlMeta(key,message,a);saveRemovedUnls(loadRemovedUnls().filter(r=>normalizePublicKeyMaybe(r.publicKey)!==key));const s=loadPruneState();applyManagedThreshold(cfg,s);await ctx.updateConfig(cfg);await sendOutput(user,{type:'unl-added',actionId:message.actionId||null,publicKey:key,metadata:m,consensusThreshold:readThreshold(cfg)});}
async function removeUnl(user,message,ctx){ if(ctx.readonly)throw new Error('UNL changes require consensus input.'); const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const key=normalizePublicKey(message.publicKey);const cfg=await ctx.getConfig();const c=getContractConfigSection(cfg);const unl=getConfigUnl(cfg);if(!unl.includes(key))throw new Error('Public key is not in UNL.');if(unl.length<=1)throw new Error('Cannot remove the final UNL node.');c.unl=unl.filter(k=>k!==key);const meta=loadUnlMetadata()[key]||{};const removed=loadRemovedUnls();removed.unshift({publicKey:key,domain:meta.domain||'',url:meta.url||'',removedAt:a.timestampMs,removedBy:a.auth.userId,reason:'manual'});saveRemovedUnls(removed);const s=loadPruneState();applyManagedThreshold(cfg,s);await ctx.updateConfig(cfg);await sendOutput(user,{type:'unl-removed',actionId:message.actionId||null,publicKey:key,consensusThreshold:readThreshold(cfg)});}
async function setVisibility(user,message,ctx){ if(ctx.readonly)throw new Error('Config changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const mode=normalizeVisibility(message.mode);const cfg=await ctx.getConfig();const c=getContractConfigSection(cfg);getOrCreate(c,'consensus').mode=mode;getOrCreate(c,'npl').mode=mode;await ctx.updateConfig(cfg);await sendOutput(user,{type:'cluster-visibility-mode-set',actionId:message.actionId||null,mode,visibilityMode:readVisibility(cfg)});}
async function setThreshold(user,message,ctx){ if(ctx.readonly)throw new Error('Config changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const s=loadPruneState();if(s.settings.enabled)throw new Error('Manual threshold is locked while auto purge is enabled.');const cfg=await ctx.getConfig();const total=getConfigUnl(cfg).length;let threshold=Number(message.threshold);if(message.requiredVotes!==undefined)threshold=thresholdForVotes(Number(message.requiredVotes),total);if(!Number.isInteger(threshold)||threshold<1||threshold>100)throw new Error('Threshold must be 1-100.');getOrCreate(getContractConfigSection(cfg),'consensus').threshold=threshold;await ctx.updateConfig(cfg);await sendOutput(user,{type:'consensus-threshold-set',actionId:message.actionId||null,consensusThreshold:readThreshold(cfg)});}
async function setRoundtime(user,message,ctx){ if(ctx.readonly)throw new Error('Config changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const n=Number(message.roundtimeMs||message.roundtime);if(!Number.isInteger(n)||n<1||n>3600000)throw new Error('Roundtime must be 1-3600000 ms.');const cfg=await ctx.getConfig();getOrCreate(getContractConfigSection(cfg),'consensus').roundtime=n;await ctx.updateConfig(cfg);await sendOutput(user,{type:'consensus-roundtime-set',actionId:message.actionId||null,roundtime:n});}
async function getPruneSettings(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const cfg=await ctx.getConfig();const s=loadPruneState();await sendOutput(user,{type:'unl-prune-settings',actionId:message.actionId||null,...pruneStatus(s,cfg,a.timestampMs)});}
async function setPruneSettings(user,message,ctx){if(ctx.readonly)throw new Error('Prune settings require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const s=loadPruneState();const i=message.settings||message;s.settings={...s.settings,enabled:i.enabled===undefined?s.settings.enabled:!!i.enabled,healthAutoEnabled:false,healthEveryLedgers:boundInt(i.healthEveryLedgers,s.settings.healthEveryLedgers,1,100000),healthTimeoutMs:boundInt(i.healthTimeoutMs,s.settings.healthTimeoutMs,500,15000),minDeadMinutes:boundInt(i.minDeadMinutes,s.settings.minDeadMinutes,1,100000),minInstancesAgreeing:boundInt(i.minInstancesAgreeing,s.settings.minInstancesAgreeing,1,100000),maxDisagreePercent:boundInt(i.maxDisagreePercent,s.settings.maxDisagreePercent,0,99),maxPurgePerRun:boundInt(i.maxPurgePerRun,s.settings.maxPurgePerRun,1,100),autoReaddEnabled:i.autoReaddEnabled===undefined?s.settings.autoReaddEnabled:!!i.autoReaddEnabled,readdEveryLedgers:boundInt(i.readdEveryLedgers,s.settings.readdEveryLedgers,1,100000),readdMaxPerRun:boundInt(i.readdMaxPerRun,s.settings.readdMaxPerRun,1,100)};const cfg=await ctx.getConfig();applyManagedThreshold(cfg,s);await ctx.updateConfig(cfg);savePruneState(s);await sendOutput(user,{type:'unl-prune-settings-set',actionId:message.actionId||null,...pruneStatus(s,cfg,a.timestampMs)});}
async function manualHealth(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;await probeLocalHealth(ctx);await sendOutput(user,{type:'unl-health-probed',actionId:message.actionId||null,message:'NPL probe completed locally on each executing validator. Results stay outside consensus in ../unl-health.json.'});}
async function getLocalHealth(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const cfg=await ctx.getConfig();await sendOutput(user,{type:'local-unl-health',actionId:message.actionId||null,nodePublicKey:getLocalNodePublicKey(ctx,cfg),path:'../unl-health.json',snapshot:readLocalHealth()});}
async function reportUnlHealth(user,message,ctx){if(ctx.readonly)throw new Error('Health reports require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const key=normalizePublicKey(message.publicKey);const status=safeString(message.status,16).toLowerCase();if(!['alive','silent','unknown'].includes(status))throw new Error('Status must be alive, silent or unknown.');const cfg=await ctx.getConfig();if(!getConfigUnl(cfg).includes(key))throw new Error('Public key is not in the current UNL.');const state=loadPruneState();const old=state.nodes[key]||{};if(status==='alive')state.nodes[key]={...old,status,lastAliveAt:a.timestampMs,deadSince:null,lastReportAt:a.timestampMs,reportedBy:a.auth.userId};else if(status==='silent')state.nodes[key]={...old,status,deadSince:old.deadSince||a.timestampMs,lastReportAt:a.timestampMs,reportedBy:a.auth.userId};else state.nodes[key]={...old,status,lastReportAt:a.timestampMs,reportedBy:a.auth.userId};savePruneState(state);await sendOutput(user,{type:'unl-health-reported',actionId:message.actionId||null,publicKey:key,status});}
async function manualPrune(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const result=await evaluatePrune(ctx,a.auth.userId,'manual');await sendOutput(user,{type:'unl-prune-result',actionId:message.actionId||null,...result});}
async function reportRemovedHealth(user,message,ctx){if(ctx.readonly)throw new Error('Health reports require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const key=normalizePublicKey(message.publicKey);const status=safeString(message.status,16).toLowerCase();if(!['alive','silent','unknown'].includes(status))throw new Error('Status must be alive, silent or unknown.');const list=loadRemovedUnls();const r=list.find(x=>normalizePublicKeyMaybe(x.publicKey)===key);if(!r)throw new Error('Removed UNL not found.');r.healthStatus=status;r.healthReportedAt=a.timestampMs;r.healthReportedBy=a.auth.userId;saveRemovedUnls(list);await sendOutput(user,{type:'removed-unl-health-set',actionId:message.actionId||null,publicKey:key,status});}
async function readdRemoved(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const result=await evaluateReadd(ctx,a.auth.userId,'manual');await sendOutput(user,{type:'unl-readd-result',actionId:message.actionId||null,...result});}
async function deleteRemoved(user,message,ctx){if(ctx.readonly)throw new Error('Changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const key=normalizePublicKey(message.publicKey);saveRemovedUnls(loadRemovedUnls().filter(r=>normalizePublicKeyMaybe(r.publicKey)!==key));await sendOutput(user,{type:'removed-unl-deleted',actionId:message.actionId||null,publicKey:key});}

function loadCustomFields() { const d=readJson(CUSTOM_FIELDS_FILE,{fields:[]}); d.fields=Array.isArray(d.fields)?d.fields:[]; return d; }
function saveCustomFields(d) { writeJson(CUSTOM_FIELDS_FILE,d); }
function normalizeFieldId(value) { const id=safeString(value,64).toLowerCase(); if(!/^[a-z][a-z0-9_-]{0,63}$/.test(id))throw new Error('Field id must start with a letter and use letters, numbers, underscore or hyphen.'); return id; }
function normalizeFieldType(value) { const t=safeString(value,16).toLowerCase(); if(!['string','number','boolean','json','secret'].includes(t))throw new Error('Field type must be string, number, boolean, json or secret.'); return t; }
function normalizeFieldMode(value) { const m=safeString(value||'single',16).toLowerCase(); if(!['single','repeater'].includes(m))throw new Error('Field mode must be single or repeater.'); return m; }
function fieldMode(field){return normalizeFieldMode(field&&field.mode||'single');}
function normalizeCustomValue(field,value){ if(field.type==='number'){const n=Number(value);if(!Number.isFinite(n))throw new Error('Value must be a number.');return n;} if(field.type==='boolean'){if(typeof value==='boolean')return value;const s=String(value).toLowerCase();if(s==='true'||s==='1')return true;if(s==='false'||s==='0')return false;throw new Error('Value must be true or false.');} if(field.type==='json'){if(typeof value==='object'&&value!==null)return value;try{return JSON.parse(String(value));}catch{throw new Error('Value must be valid JSON.');}} return String(value===undefined||value===null?'':value); }
function normalizeCustomTarget(message){const scope=safeString(message.targetScope||message.scope||'node',16).toLowerCase();if(scope==='all')return{scope:'all',targetPublicKey:null};if(scope!=='node'&&scope!=='selected')throw new Error('Target scope must be node or all.');return{scope:'node',targetPublicKey:normalizePublicKey(message.targetPublicKey)};}
function customTargetApplies(target,local){return target.scope==='all'||target.targetPublicKey===local;}
function customTargetOutput(target){return target.scope==='all'?{targetScope:'all',targetPublicKey:null}:{targetScope:'node',targetPublicKey:target.targetPublicKey};}
function canonicalCustomValue(value){if(Array.isArray(value))return`[${value.map(canonicalCustomValue).join(',')}]`;if(value&&typeof value==='object'){return`{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonicalCustomValue(value[k])}`).join(',')}}`;}return JSON.stringify(value);}
function readLocalCustom(){const d=readJson(LOCAL_CUSTOM_FILE,{});return d&&typeof d==='object'&&!Array.isArray(d)?d:{};}
function writeLocalCustomQuiet(data){try{ensureDir(path.dirname(LOCAL_CUSTOM_FILE));fs.writeFileSync(LOCAL_CUSTOM_FILE,JSON.stringify(data,null,2));return true;}catch(err){console.log(`Local custom.json write failed: ${err.message}`);return false;}}
async function listCustomFields(user,message,ctx){const a=await requireRole(user,message,ctx);if(!a)return;const d=loadCustomFields();d.fields=d.fields.map(f=>({...f,mode:fieldMode(f)}));await sendOutput(user,{type:'custom-fields',actionId:message.actionId||null,...d});}
async function addCustomField(user,message,ctx){if(ctx.readonly)throw new Error('Field changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const d=loadCustomFields();const id=normalizeFieldId(message.id||message.fieldId);if(d.fields.some(f=>f.id===id))throw new Error('Custom field already exists.');const f={id,label:safeString(message.label||id,128),type:normalizeFieldType(message.fieldType||message.dataType||'string'),mode:normalizeFieldMode(message.fieldMode||(message.repeatable?'repeater':'single')),description:safeString(message.description,512),required:!!message.required,sensitive:!!message.sensitive,createdAt:a.timestampMs,createdBy:a.auth.userId};d.fields.push(f);d.fields.sort((x,y)=>x.id.localeCompare(y.id));saveCustomFields(d);await sendOutput(user,{type:'custom-field-added',actionId:message.actionId||null,field:f});}
async function updateCustomField(user,message,ctx){if(ctx.readonly)throw new Error('Field changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const d=loadCustomFields();const id=normalizeFieldId(message.id||message.fieldId);const f=d.fields.find(x=>x.id===id);if(!f)throw new Error('Custom field not found.');if(message.label!==undefined)f.label=safeString(message.label,128);if(message.description!==undefined)f.description=safeString(message.description,512);if(message.fieldType!==undefined||message.dataType!==undefined)f.type=normalizeFieldType(message.fieldType||message.dataType);if(message.fieldMode!==undefined||message.repeatable!==undefined)f.mode=normalizeFieldMode(message.fieldMode||(message.repeatable?'repeater':'single'));if(message.required!==undefined)f.required=!!message.required;if(message.sensitive!==undefined)f.sensitive=!!message.sensitive;f.updatedAt=a.timestampMs;f.updatedBy=a.auth.userId;saveCustomFields(d);await sendOutput(user,{type:'custom-field-updated',actionId:message.actionId||null,field:{...f,mode:fieldMode(f)}});}
async function removeCustomField(user,message,ctx){if(ctx.readonly)throw new Error('Field changes require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const d=loadCustomFields();const id=normalizeFieldId(message.id||message.fieldId);const before=d.fields.length;d.fields=d.fields.filter(f=>f.id!==id);if(d.fields.length===before)throw new Error('Custom field not found.');saveCustomFields(d);await sendOutput(user,{type:'custom-field-removed',actionId:message.actionId||null,fieldId:id});}
async function setCustomValue(user,message,ctx){if(ctx.readonly)throw new Error('Custom writes require consensus input.');const a=await requireRole(user,message,ctx);if(!a)return;const fieldId=normalizeFieldId(message.fieldId);const field=loadCustomFields().fields.find(f=>f.id===fieldId);if(!field)throw new Error('Unknown custom field.');if(fieldMode(field)==='repeater')throw new Error('Repeater fields use append-custom-value so existing items are preserved.');const target=normalizeCustomTarget(message);const value=normalizeCustomValue(field,message.value);const cfg=await ctx.getConfig();const local=getLocalNodePublicKey(ctx,cfg);if(customTargetApplies(target,local)){const data=readLocalCustom();data[fieldId]=value;writeLocalCustomQuiet(data);}await sendOutput(user,{type:'custom-value-dispatched',actionId:message.actionId||null,...customTargetOutput(target),fieldId,storage:{path:'../custom.json',scope:'node-local-seed',consensusState:false},message:target.scope==='all'?'Value dispatched to ../custom.json on all currently executing validators.':'Value dispatched to ../custom.json on the selected validator.'});}
async function appendCustomValue(user,message,ctx){if(ctx.readonly)throw new Error('Custom writes require consensus input.');const a=await requireRole(user,message,ctx);if(!a)return;const fieldId=normalizeFieldId(message.fieldId);const field=loadCustomFields().fields.find(f=>f.id===fieldId);if(!field)throw new Error('Unknown custom field.');if(fieldMode(field)!=='repeater')throw new Error('This field is not a repeater. Use set-custom-value for regular fields.');const target=normalizeCustomTarget(message);const value=normalizeCustomValue(field,message.value);const cfg=await ctx.getConfig();const local=getLocalNodePublicKey(ctx,cfg);if(customTargetApplies(target,local)){const data=readLocalCustom();let list=data[fieldId];if(!Array.isArray(list))list=list===undefined?[]:[list];list.push(value);data[fieldId]=list;writeLocalCustomQuiet(data);}await sendOutput(user,{type:'custom-value-appended',actionId:message.actionId||null,...customTargetOutput(target),fieldId,storage:{path:'../custom.json',scope:'node-local-seed',consensusState:false},message:target.scope==='all'?'Item appended on all currently executing validators.':'Item appended on the selected validator.'});}
async function removeCustomItem(user,message,ctx){if(ctx.readonly)throw new Error('Custom writes require consensus input.');const a=await requireRole(user,message,ctx);if(!a)return;const fieldId=normalizeFieldId(message.fieldId);const field=loadCustomFields().fields.find(f=>f.id===fieldId);if(!field)throw new Error('Unknown custom field.');if(fieldMode(field)!=='repeater')throw new Error('This field is not a repeater.');const target=normalizeCustomTarget(message);const value=normalizeCustomValue(field,message.value);const cfg=await ctx.getConfig();const local=getLocalNodePublicKey(ctx,cfg);if(customTargetApplies(target,local)){const data=readLocalCustom();const list=Array.isArray(data[fieldId])?data[fieldId]:[];const wanted=canonicalCustomValue(value);const idx=list.findIndex(v=>canonicalCustomValue(v)===wanted);if(idx>=0)list.splice(idx,1);data[fieldId]=list;writeLocalCustomQuiet(data);}await sendOutput(user,{type:'custom-item-removed',actionId:message.actionId||null,...customTargetOutput(target),fieldId,storage:{path:'../custom.json',scope:'node-local-seed',consensusState:false},message:'Removed one matching repeater item where present.'});}
async function clearCustomValue(user,message,ctx){if(ctx.readonly)throw new Error('Custom writes require consensus input.');const a=await requireRole(user,message,ctx);if(!a)return;const fieldId=normalizeFieldId(message.fieldId);const target=normalizeCustomTarget(message);const cfg=await ctx.getConfig();const local=getLocalNodePublicKey(ctx,cfg);if(customTargetApplies(target,local)){const data=readLocalCustom();delete data[fieldId];writeLocalCustomQuiet(data);}await sendOutput(user,{type:'custom-value-cleared',actionId:message.actionId||null,...customTargetOutput(target),fieldId,storage:{path:'../custom.json',scope:'node-local-seed',consensusState:false}});}
async function getLocalCustom(user,message,ctx){const a=await requireRole(user,message,ctx);if(!a)return;const cfg=await ctx.getConfig();const fields=loadCustomFields().fields;const data=readLocalCustom();const reveal=message.revealSensitive===true;const safe={};for(const f of fields){if(Object.prototype.hasOwnProperty.call(data,f.id))safe[f.id]=(f.sensitive&&!reveal)?'••••••••':data[f.id];}for(const [k,v] of Object.entries(data)){if(!fields.some(f=>f.id===k))safe[k]=v;}await sendOutput(user,{type:'local-custom',actionId:message.actionId||null,nodePublicKey:getLocalNodePublicKey(ctx,cfg),path:'../custom.json',storageScope:'node-local-seed',consensusState:false,values:safe});}

function normalizePublicPath(value){let rel=safeString(value,512).replace(/\\/g,'/').replace(/^\/+/, '');if(!rel||rel.includes('..')||!rel.startsWith('public/'))throw new Error('Public asset path must start with public/ and cannot contain ..');return rel;}
function safeUploadId(value){const id=safeString(value||randomHex(16),128);if(!/^[a-zA-Z0-9._-]{8,128}$/.test(id))throw new Error('Invalid upload id.');return id;}
function loadUploadSessions(){return readJson(UPLOAD_SESSIONS_FILE,{});} function saveUploadSessions(s){writeJson(UPLOAD_SESSIONS_FILE,s);}
async function uploadPublicAsset(user,message,ctx){if(ctx.readonly)throw new Error('Uploads require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const rel=normalizePublicPath(message.path||message.filename);const target=path.resolve(STATE_ROOT,rel);if(!target.startsWith(PUBLIC_ROOT+path.sep))throw new Error('Asset path escaped public root.');const uploadId=safeUploadId(message.uploadId);const chunkNo=Number(message.chunkNo),totalChunks=Number(message.totalChunks);if(!Number.isInteger(chunkNo)||!Number.isInteger(totalChunks)||chunkNo<1||totalChunks<1||chunkNo>totalChunks)throw new Error('Invalid chunk numbers.');const hex=String(message.chunk||'');if(!/^[0-9a-fA-F]*$/.test(hex))throw new Error('Chunk must be hex.');const sessions=loadUploadSessions();const key=`public:${uploadId}`;ensureDir(PUBLIC_UPLOADS_ROOT);ensureDir(path.dirname(target));const staged=path.resolve(PUBLIC_UPLOADS_ROOT,`${uploadId}.part`);if(!staged.startsWith(PUBLIC_UPLOADS_ROOT+path.sep))throw new Error('Invalid public upload staging path.');if(chunkNo===1){fs.rmSync(staged,{force:true});sessions[key]={rel,totalChunks,nextChunk:1,staged:path.basename(staged)};}const sess=sessions[key];if(!sess||sess.rel!==rel||sess.totalChunks!==totalChunks||sess.nextChunk!==chunkNo)throw new Error('Upload session mismatch.');fs.appendFileSync(staged,Buffer.from(hex,'hex'));if(fs.statSync(staged).size>MAX_PUBLIC_FILE_BYTES){fs.rmSync(staged,{force:true});delete sessions[key];saveUploadSessions(sessions);throw new Error('Public asset too large.');}if(chunkNo===totalChunks){const size=fs.statSync(staged).size,hash=sha256Hex(fs.readFileSync(staged));fs.renameSync(staged,target);delete sessions[key];saveUploadSessions(sessions);await sendOutput(user,{type:'public-asset-uploaded',actionId:message.actionId||null,path:rel,size,sha256:hash,atomic:true,storage:{root:'public/',scope:'consensus-state',consensusState:true}});}else{sess.nextChunk++;saveUploadSessions(sessions);await sendOutput(user,{type:'upload-ack',actionId:message.actionId||null,uploadId,chunkNo,totalChunks,staged:true});}}
async function listPublicAssets(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const assets=walkFiles(PUBLIC_ROOT).map(f=>({path:`public/${f.path}`,size:f.size,sha256:f.sha256}));await sendOutput(user,{type:'public-assets',actionId:message.actionId||null,storage:{root:'.',scope:'consensus-state',consensusState:true},assets});}

async function nodeRuntimeInfo(user,message,ctx){
  if(!ctx.readonly) throw new Error('Node runtime info is node-local and is available only through a read request.');
  const local = runtimeFromLocalHealth();
  await sendOutput(user,{type:'node-runtime-info',actionId:message.actionId||null,...local,nodePublicKey:local.nodePublicKey||normalizePublicKeyMaybe(ctx.publicKey)||normalizePublicKeyMaybe(ctx.public_key)||null});
}

function resolveReadableCodeFile(message){
  const kind=safeString(message.kind||'frontend',24).toLowerCase();
  if(kind==='frontend'){
    const rel=normalizePublicPath(message.path||'public/evernode.html');
    const file=path.resolve(STATE_ROOT,rel);
    if(!file.startsWith(PUBLIC_ROOT+path.sep))throw new Error('Frontend path escaped public root.');
    return {kind,source:'state',rel,file,protected:false,consensusState:true};
  }
  if(kind!=='contract')throw new Error('Code kind must be frontend or contract.');
  const source=safeString(message.source||'active',32).toLowerCase();
  const rel=normalizeVersionRel(message.path||message.filename||'sidedish.js');
  if(source==='base'){
    if(!['sidedish.js','index.js'].includes(rel))throw new Error('Built-in source exposes sidedish.js and protected index.js only.');
    return {kind,source,rel,file:path.resolve(STATE_ROOT,rel),protected:rel==='index.js',consensusState:true};
  }
  const versions=loadVersions();
  let versionId=null;
  if(source==='active') versionId=versions.activeVersion;
  else if(source==='version') versionId=normalizeVersionId(message.versionId);
  else throw new Error('Contract source must be base, active or version.');
  if(!versionId)throw new Error('There is no active staged contract version. Load the built-in base instead.');
  if(!versions.versions[versionId])throw new Error('Contract version not found.');
  const root=versionRoot(versionId),file=targetIn(root,rel);
  return {kind,source,versionId,rel,file,protected:false,consensusState:true};
}

async function readCodeFile(user,message,ctx){
  const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;
  const target=resolveReadableCodeFile(message);
  const text=assertEditableTextFile(target.file,target.rel);
  await sendOutput(user,{type:'code-file',actionId:message.actionId||null,kind:target.kind,source:target.source,versionId:target.versionId||null,path:target.rel,protected:target.protected,consensusState:true,stateRootLabel:'HotPocket state (contract working directory)',...text});
}

function copyContractDraftTree(src,dst,prefix=''){
  ensureDir(dst);
  for(const name of fs.readdirSync(src)){
    const rel=prefix?`${prefix}/${name}`:name;
    if(rel==='manifest.json')continue;
    const s=path.join(src,name),d=path.join(dst,name),l=fs.lstatSync(s);
    if(l.isSymbolicLink())throw new Error('Symlinks are not allowed in contract versions.');
    if(l.isDirectory())copyContractDraftTree(s,d,rel);
    else if(l.isFile())fs.copyFileSync(s,d);
  }
}

async function prepareContractDraft(user,message,ctx){
  if(ctx.readonly)throw new Error('Preparing a contract draft requires consensus input.');
  const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;
  const bundleId=safeUploadId(message.versionUploadId),root=versionUploadRoot(bundleId);
  fs.rmSync(root,{recursive:true,force:true});ensureDir(root);
  const source=safeString(message.source||'active',32).toLowerCase();
  const versions=loadVersions();
  let copiedFrom=null;
  if(source==='active'){
    if(versions.activeVersion){copiedFrom=versions.activeVersion;copyContractDraftTree(versionRoot(copiedFrom),root);}
    else {copiedFrom='base';fs.copyFileSync(path.resolve(STATE_ROOT,'sidedish.js'),path.join(root,'sidedish.js'));}
  }else if(source==='base'){
    copiedFrom='base';fs.copyFileSync(path.resolve(STATE_ROOT,'sidedish.js'),path.join(root,'sidedish.js'));
  }else if(source==='version'){
    copiedFrom=normalizeVersionId(message.versionId);if(!versions.versions[copiedFrom])throw new Error('Source contract version not found.');copyContractDraftTree(versionRoot(copiedFrom),root);
  }else if(source==='empty'){copiedFrom='empty';}
  else throw new Error('Draft source must be active, base, version or empty.');
  const files=walkFiles(root);
  await sendOutput(user,{type:'contract-draft-prepared',actionId:message.actionId||null,versionUploadId:bundleId,copiedFrom,files,storage:{root:'.contract-version-uploads',scope:'consensus-state',consensusState:true}});
}

function normalizeVersionRel(value){const rel=safeString(value||'sidedish.js',512).replace(/\\/g,'/').replace(/^\/+/, '');if(!rel||rel.includes('..')||rel.startsWith('.'))throw new Error('Invalid version file path.');return rel;}
function normalizeVersionId(value){const id=safeString(value,160);if(!/^[a-zA-Z0-9._-]{3,160}$/.test(id)||id.includes('..'))throw new Error('Invalid version id.');return id;}
function versionRoot(id){const r=path.resolve(CONTRACT_VERSIONS_ROOT,normalizeVersionId(id));if(!r.startsWith(CONTRACT_VERSIONS_ROOT+path.sep))throw new Error('Invalid version path.');return r;}
function versionUploadRoot(id){const r=path.resolve(CONTRACT_UPLOADS_ROOT,safeUploadId(id));if(!r.startsWith(CONTRACT_UPLOADS_ROOT+path.sep))throw new Error('Invalid upload path.');return r;}
function targetIn(root,rel){const t=path.resolve(root,normalizeVersionRel(rel));if(!t.startsWith(path.resolve(root)+path.sep))throw new Error('Version path escaped root.');return t;}
function walkFiles(dir,prefix=''){if(!fs.existsSync(dir))return[];let out=[];for(const name of fs.readdirSync(dir).sort()){const f=path.join(dir,name),rel=prefix?`${prefix}/${name}`:name,l=fs.lstatSync(f);if(l.isSymbolicLink())throw new Error('Symlinks are not allowed.');if(l.isDirectory())out=out.concat(walkFiles(f,rel));else if(l.isFile()){if(l.size>MAX_CONTRACT_FILE_BYTES)throw new Error(`File too large: ${rel}`);out.push({path:rel,size:l.size,sha256:sha256Hex(fs.readFileSync(f))});}}return out;}
function bundleHash(files){const h=crypto.createHash('sha256');for(const f of files){h.update(f.path);h.update('\0');h.update(String(f.size));h.update('\0');h.update(f.sha256);h.update('\n');}return h.digest('hex');}
function copyTree(src,dst){ensureDir(dst);for(const name of fs.readdirSync(src)){const s=path.join(src,name),d=path.join(dst,name),l=fs.lstatSync(s);if(l.isSymbolicLink())throw new Error('Symlinks are not allowed.');if(l.isDirectory())copyTree(s,d);else if(l.isFile())fs.copyFileSync(s,d);}}
function loadVersions(){const d=readJson(CONTRACT_VERSIONS_INDEX_FILE,{activeVersion:null,previousActiveVersion:null,versions:{}});d.versions=d.versions&&typeof d.versions==='object'?d.versions:{};return d;} function saveVersions(d){ensureDir(CONTRACT_VERSIONS_ROOT);writeJson(CONTRACT_VERSIONS_INDEX_FILE,d);}
async function uploadContractVersionFile(user,message,ctx){if(ctx.readonly)throw new Error('Uploads require consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const bundleId=safeUploadId(message.versionUploadId);const fileId=safeUploadId(message.uploadId);const rel=normalizeVersionRel(message.filename||message.path);const root=versionUploadRoot(bundleId),target=targetIn(root,rel);const chunkNo=Number(message.chunkNo),totalChunks=Number(message.totalChunks);if(!Number.isInteger(chunkNo)||!Number.isInteger(totalChunks)||chunkNo<1||totalChunks<1||chunkNo>totalChunks)throw new Error('Invalid chunk numbers.');const hex=String(message.chunk||'');if(!/^[0-9a-fA-F]*$/.test(hex))throw new Error('Chunk must be hex.');const sessions=loadUploadSessions();const key=`version:${bundleId}:${fileId}`;ensureDir(path.dirname(target));if(chunkNo===1){if(fs.existsSync(target))fs.rmSync(target,{force:true});sessions[key]={rel,totalChunks,nextChunk:1};}const s=sessions[key];if(!s||s.rel!==rel||s.totalChunks!==totalChunks||s.nextChunk!==chunkNo)throw new Error('Version upload session mismatch.');fs.appendFileSync(target,Buffer.from(hex,'hex'));if(fs.statSync(target).size>MAX_CONTRACT_FILE_BYTES){fs.rmSync(target,{force:true});delete sessions[key];saveUploadSessions(sessions);throw new Error('Contract file too large.');}if(chunkNo===totalChunks){delete sessions[key];saveUploadSessions(sessions);await sendOutput(user,{type:'contract-version-file-uploaded',actionId:message.actionId||null,versionUploadId:bundleId,filename:rel,size:fs.statSync(target).size});}else{s.nextChunk++;saveUploadSessions(sessions);await sendOutput(user,{type:'upload-ack',actionId:message.actionId||null,versionUploadId:bundleId,filename:rel,chunkNo,totalChunks});}}
async function finalizeContractVersion(user,message,ctx){if(ctx.readonly)throw new Error('Finalization requires consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const bundleId=safeUploadId(message.versionUploadId),root=versionUploadRoot(bundleId),entry=normalizeVersionRel(message.entryFile||'sidedish.js');if(!fs.existsSync(root))throw new Error('Version upload not found.');const entryPath=targetIn(root,entry);if(!fs.existsSync(entryPath)||fs.statSync(entryPath).size<1)throw new Error('Entry file is missing/empty.');if(path.extname(entryPath)==='.js'){try{new Function('exports','require','module','__filename','__dirname',fs.readFileSync(entryPath,'utf8'));}catch(err){throw new Error(`JavaScript syntax check failed: ${err.message}`);}}const files=walkFiles(root);const total=files.reduce((n,f)=>n+f.size,0);if(total>MAX_CONTRACT_TOTAL_BYTES)throw new Error('Contract bundle is too large.');const hash=bundleHash(files);const label=safeString(message.label||'contract',48).replace(/[^a-zA-Z0-9._-]+/g,'-').replace(/^-+|-+$/g,'')||'contract';const stamp=new Date(a.timestampMs).toISOString().replace(/[-:]/g,'').replace(/\.\d+Z$/,'z');const id=normalizeVersionId(`${stamp}-${label}-${hash.slice(0,12)}`);const dst=versionRoot(id);if(fs.existsSync(dst))throw new Error('Version already exists.');copyTree(root,dst);fs.rmSync(root,{recursive:true,force:true});const manifest={versionId:id,label,entryFile:entry,bundleHash:hash,status:'staged',createdAt:a.timestampMs,createdBy:a.auth.userId,activatedAt:null,activatedBy:null,fileCount:files.length,totalBytes:total,files};writeJson(path.join(dst,'manifest.json'),manifest);const index=loadVersions();index.versions[id]=manifest;saveVersions(index);await sendOutput(user,{type:'contract-version-finalized',actionId:message.actionId||null,version:manifest});}
async function listContractVersions(user,message,ctx){const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const index=loadVersions();await sendOutput(user,{type:'contract-versions',actionId:message.actionId||null,activeVersion:index.activeVersion,previousActiveVersion:index.previousActiveVersion,versions:Object.values(index.versions).sort((x,y)=>Number(y.createdAt||0)-Number(x.createdAt||0)),loaderMode:true,baseAppVersion:APP_VERSION});}
async function activateContractVersion(user,message,ctx){if(ctx.readonly)throw new Error('Activation requires consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const id=normalizeVersionId(message.versionId),index=loadVersions(),v=index.versions[id];if(!v)throw new Error('Version not found.');const expected=safeString(message.expectedHash||message.bundleHash,128).toLowerCase();if(expected&&expected!==String(v.bundleHash).toLowerCase())throw new Error('Expected hash does not match.');const entry=targetIn(versionRoot(id),v.entryFile||'sidedish.js');if(!fs.existsSync(entry))throw new Error('Version entry file is missing.');if(index.activeVersion&&index.activeVersion!==id)index.previousActiveVersion=index.activeVersion;index.activeVersion=id;for(const [vid,rec] of Object.entries(index.versions)){if(rec)rec.status=vid===id?'active':(rec.status==='active'?'inactive':rec.status);}v.activatedAt=a.timestampMs;v.activatedBy=a.auth.userId;saveVersions(index);writeJson(ACTIVE_VERSION_FILE,{versionId:id,entryFile:v.entryFile||'sidedish.js',bundleHash:v.bundleHash,activatedAt:a.timestampMs,activatedBy:a.auth.userId});if(index.previousActiveVersion)writeJson(PREVIOUS_VERSION_FILE,{versionId:index.previousActiveVersion});await sendOutput(user,{type:'contract-version-activated',actionId:message.actionId||null,activeVersion:id,previousActiveVersion:index.previousActiveVersion,loaderMode:true,message:'Version activated behind stable loader. It will be loaded on the next invocation.'});}
async function rollbackContractVersion(user,message,ctx){if(ctx.readonly)throw new Error('Rollback requires consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const index=loadVersions();const id=normalizeVersionId(message.versionId||index.previousActiveVersion);if(!index.versions[id])throw new Error('Rollback version not found.');const old=index.activeVersion;index.activeVersion=id;index.previousActiveVersion=old&&old!==id?old:index.previousActiveVersion;for(const [vid,rec] of Object.entries(index.versions)){if(rec)rec.status=vid===id?'active':(rec.status==='active'?'inactive':rec.status);}saveVersions(index);const v=index.versions[id];writeJson(ACTIVE_VERSION_FILE,{versionId:id,entryFile:v.entryFile||'sidedish.js',bundleHash:v.bundleHash,activatedAt:a.timestampMs,activatedBy:a.auth.userId,rollback:true});await sendOutput(user,{type:'contract-version-rolled-back',actionId:message.actionId||null,activeVersion:id,previousActiveVersion:index.previousActiveVersion});}
async function deactivateContractVersion(user,message,ctx){if(ctx.readonly)throw new Error('Deactivation requires consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const index=loadVersions();if(index.activeVersion)index.previousActiveVersion=index.activeVersion;index.activeVersion=null;saveVersions(index);if(fs.existsSync(ACTIVE_VERSION_FILE))fs.rmSync(ACTIVE_VERSION_FILE,{force:true});await sendOutput(user,{type:'contract-version-deactivated',actionId:message.actionId||null,baseAppVersion:APP_VERSION});}
async function deleteContractVersion(user,message,ctx){if(ctx.readonly)throw new Error('Deletion requires consensus input.');const a=await requireRole(user,message,ctx,[ROLE_HEAD_ADMIN]);if(!a)return;const id=normalizeVersionId(message.versionId),index=loadVersions();if(id===index.activeVersion||id===index.previousActiveVersion)throw new Error('Cannot delete active or rollback version.');if(!index.versions[id])throw new Error('Version not found.');fs.rmSync(versionRoot(id),{recursive:true,force:true});delete index.versions[id];saveVersions(index);await sendOutput(user,{type:'contract-version-deleted',actionId:message.actionId||null,versionId:id});}

async function getDiagnostics(user,message,ctx){const a=await requireRole(user,message,ctx);if(!a)return;let cfg={};try{cfg=await ctx.getConfig();}catch{}const local=getLocalNodePublicKey(ctx,cfg);const nodeRuntime=ctx.readonly?runtimeFromLocalHealth():{detected:false,userPort:null,source:'consensus-execution'};let customStat=null,customError=null;try{customStat=fs.existsSync(LOCAL_CUSTOM_FILE)?fs.statSync(LOCAL_CUSTOM_FILE):null;}catch(err){customError=err.message;}const auth=loadAuthState(),versions=loadVersions(),prune=loadPruneState();const pubFiles=['index.html','evernode.html','runtime.php'].map(n=>{const f=path.join(PUBLIC_ROOT,n);return fs.existsSync(f)?{name:n,size:fs.statSync(f).size,sha256:sha256Hex(fs.readFileSync(f))}:{name:n,missing:true};});await sendOutput(user,{type:'diagnostics',actionId:message.actionId||null,app:{name:APP_NAME,version:APP_VERSION,loaderMode:true},node:{publicKey:local,readonly:!!ctx.readonly,ledgerNo:ledgerNo(ctx),ledgerHash:safeString(ctx.lclHash||'',256),timestamp:nowMs(ctx),runtime:nodeRuntime},config:{unl:getConfigUnl(cfg),visibility:readVisibility(cfg),consensusThreshold:readThreshold(cfg),roundtime:readRoundtime(cfg)},auth:{bootstrapComplete:auth.bootstrapComplete,activeUsers:Object.values(auth.users||{}).filter(u=>u&&u.active!==false).length,activeHeadAdmins:countActiveHeadAdmins(auth),authorizedDevices:Object.keys(auth.authorizedDevices||{}).length},custom:{path:'../custom.json',absolutePath:LOCAL_CUSTOM_FILE,storageScope:'node-local-seed',consensusState:false,exists:!!customStat,size:customStat?customStat.size:0,error:customError,fieldCount:loadCustomFields().fields.length},localHealth:{path:'../unl-health.json',snapshot:readLocalHealth()},prune:pruneStatus(prune,cfg,nowMs(ctx)),versions:{activeVersion:versions.activeVersion,previousActiveVersion:versions.previousActiveVersion,count:Object.keys(versions.versions||{}).length},publicFiles:pubFiles});}

async function loadDashboard(user,message,ctx){const state=loadAuthState();const ts=nowMs(ctx);const device=getUserPublicKey(user);const auth=getDeviceAuth(state,device,ts);if(!auth){await sendOutput(user,{type:'dashboard-state',actionId:message.actionId||null,authorized:false});return;}let cfg={};try{cfg=await ctx.getConfig();}catch{}const base={type:'dashboard-state',actionId:message.actionId||null,authorized:true,auth:{role:auth.role,userId:auth.userId,username:auth.user.username||null,method:auth.user.method,expiresAt:auth.expiresAt},customFields:loadCustomFields().fields.map(f=>({...f,mode:fieldMode(f)})),localNodePublicKey:getLocalNodePublicKey(ctx,cfg),unls:getConfigUnl(cfg).map(k=>({publicKey:k,...(loadUnlMetadata()[k]||{})})),unlSummary:{count:getConfigUnl(cfg).length,visibility:readVisibility(cfg),threshold:readThreshold(cfg),roundtime:readRoundtime(cfg)}};if(auth.role===ROLE_HEAD_ADMIN){base.users=Object.entries(state.users||{}).map(([id,r])=>publicUserRecord(normalizeUserRecord(id,r)));base.unls=getConfigUnl(cfg).map(k=>({publicKey:k,...(loadUnlMetadata()[k]||{}),...(loadPruneState().nodes[k]||{})}));base.removedUnls=loadRemovedUnls();base.prune=pruneStatus(loadPruneState(),cfg,ts);base.versions={activeVersion:loadVersions().activeVersion,previousActiveVersion:loadVersions().previousActiveVersion,versions:Object.values(loadVersions().versions||{})};}await sendOutput(user,base);}

async function route(user,message,ctx){
  const type=safeString(message&&message.type,128);
  if(type==='ping'){await sendOutput(user,{type:'pong',actionId:message.actionId||null,appVersion:APP_VERSION});return;}
  if(type==='node-runtime-info'){await nodeRuntimeInfo(user,message,ctx);return;}
  if(type==='auth-status'){await authStatus(user,message,ctx);return;}
  if(type==='bootstrap-head-admin'){await bootstrapHeadAdmin(user,message,ctx);return;}
  if(type==='password-login-info'){await passwordLoginInfo(user,message,ctx);return;}
  if(type==='password-login'){await passwordLogin(user,message,ctx);return;}
  if(type==='everstoring-login-info'){await everstoringLoginInfo(user,message,ctx);return;}
  if(type==='everstoring-login'){await everstoringLogin(user,message,ctx);return;}
  if(type==='load-dashboard'){await loadDashboard(user,message,ctx);return;}
  const handlers={
    'logout-device':logoutDevice,'list-users':listUsers,'add-user':addUser,'set-user-role':setUserRole,'remove-user':removeUser,'change-password':changePassword,'set-user-2fa':setUserTwoFactor,
    'list-unls':listUnls,'add-unl':addUnl,'remove-unl':removeUnl,'set-cluster-visibility-mode':setVisibility,'set-consensus-threshold':setThreshold,'set-consensus-roundtime':setRoundtime,
    'get-unl-prune-settings':getPruneSettings,'set-unl-prune-settings':setPruneSettings,'refresh-unl-health':manualHealth,'get-local-unl-health':getLocalHealth,'report-unl-health':reportUnlHealth,'prune-silent-unls':manualPrune,'submit-removed-unl-health':reportRemovedHealth,'readd-removed-unls':readdRemoved,'delete-removed-unl':deleteRemoved,
    'list-custom-fields':listCustomFields,'add-custom-field':addCustomField,'update-custom-field':updateCustomField,'remove-custom-field':removeCustomField,'set-custom-value':setCustomValue,'append-custom-value':appendCustomValue,'remove-custom-item':removeCustomItem,'clear-custom-value':clearCustomValue,'get-local-custom':getLocalCustom,
    'upload-public-asset':uploadPublicAsset,'list-public-assets':listPublicAssets,'read-code-file':readCodeFile,
    'prepare-contract-draft':prepareContractDraft,'upload-contract-version-file':uploadContractVersionFile,'finalize-contract-version':finalizeContractVersion,'list-contract-versions':listContractVersions,'activate-contract-version':activateContractVersion,'rollback-contract-version':rollbackContractVersion,'deactivate-contract-version':deactivateContractVersion,'delete-contract-version':deleteContractVersion,
    'get-diagnostics':getDiagnostics
  };
  const fn=handlers[type];if(!fn){await sendOutput(user,{type:'error',action:type,actionId:message.actionId||null,error:`Unknown message type: ${type}`});return;}await fn(user,message,ctx);
}

async function processInputs(ctx){let count=0;for(const user of ctx.users.list()){for(const input of user.inputs){count++;let message;try{message=runtime.bson.deserialize(await ctx.users.read(input));await route(user,message,ctx);}catch(err){try{await sendOutput(user,{type:'error',action:message&&message.type||null,actionId:message&&message.actionId||null,error:err.message});}catch{console.log(`Output error: ${err.message}`);}}}}return count;}

async function maintenance(ctx){if(ctx.readonly)return;const ln=ledgerNo(ctx);if(!ln)return;const state=loadPruneState();if(state.settings.enabled&&ln%Math.max(1,boundInt(state.settings.healthEveryLedgers,10,1,100000))===0&&state.lastPruneLedger!==ln){try{await evaluatePrune(ctx,'automatic','scheduled-report-evaluation');}catch(err){console.log(`UNL prune tick failed: ${err.message}`);}}const latest=loadPruneState();if(latest.settings.autoReaddEnabled&&ln%boundInt(latest.settings.readdEveryLedgers,60,1,100000)===0&&latest.lastReaddLedger!==ln){try{await evaluateReadd(ctx,'automatic','scheduled');}catch(err){console.log(`UNL readd tick failed: ${err.message}`);}}}

async function contract(ctx, injectedRuntime) {
  runtime = injectedRuntime || runtime;
  ensureDir(PUBLIC_ROOT); ensureDir(CONTRACT_VERSIONS_ROOT);
  if (!ctx.readonly) { try { await refreshLocalHealthRuntime(ctx); } catch (err) { console.log(`Local runtime health refresh failed: ${err.message}`); } }
  const inputCount = await processInputs(ctx);
  if (!ctx.readonly && inputCount === 0) await maintenance(ctx);
}

module.exports = { contract, APP_VERSION, APP_NAME };

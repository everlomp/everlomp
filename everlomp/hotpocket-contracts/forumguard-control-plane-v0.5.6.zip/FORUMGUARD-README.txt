ForumGuard Control Plane v0.5.6

EverAdmin-derived HotPocket contract bundle with the inherited control-plane/dashboard abilities plus public Atom/RSS forum scoring.

Default source:
  https://evernode.forum/feed.php

Default fetch:
  every 5 minutes
  look back 1440 minutes (24 hours)

SCORING MODEL
-------------
Each eligible post gets a score. Rules add or subtract points. The final per-post score is clamped to 0..100 by default.

Default scoring.rules JSON:

[
  {
    "label": "Missing Evernode context",
    "field": "text",
    "when": "contains_none",
    "values": ["EVR", "Evernode"],
    "points": 25,
    "caseSensitive": false
  },
  {
    "label": "XRP / XAH / XAHAU context",
    "field": "text",
    "when": "contains_any",
    "values": ["XRP", "XAH", "XAHAU"],
    "points": -10,
    "caseSensitive": false
  }
]

Examples:
- contains neither EVR nor Evernode => +25 once
- contains EVR or Evernode => +0 from that rule
- contains any XRP, XAH, XAHAU => -10 once
- contains XRP + XAH + XAHAU => still only -10
- no EVR/Evernode + XRP => 15/100 before other rules
- Evernode + XRP => raw -10, final 0/100 because scores are clamped at zero

Available scoring "when" values:
- contains       : one value is present
- not_contains   : one value is absent
- contains_any   : at least one value in values[] is present; apply points once
- contains_none  : none of the values in values[] is present; apply points once

Extra spam-word examples:
[
  {"label":"Casino spam", "field":"text", "when":"contains", "value":"casino", "points":40},
  {"label":"Telegram promotion", "field":"text", "when":"contains", "value":"telegram", "points":15}
]

FILTERS
-------
Filters decide whether a post is eligible for scoring. They do not add points.

AND example:
[
  {"field":"text", "operator":"not_contains", "value":"trusted marker"}
]

OR example:
[
  {"field":"text", "operator":"contains", "value":"EVR"},
  {"field":"text", "operator":"contains", "value":"Evernode"}
]

State files:
- spam-oracle-config.json
- spam-oracle-state.json
- spam-score-events.ndjson

Deploy with the existing ZIP library using "Stage as contract" and entry file sidedish.js.

v0.2.1 packaging compatibility
------------------------------
This archive is intentionally usable in both deployment paths:

1. EverAdmin ZIP library -> Stage as contract
   - Recommended Entry file: sidedish.js
   - A root-level compatibility entry named "admin" is also included in case a
     browser/password manager autofills the Entry file field with "admin".

2. Full/regular HotPocket contract replacement
   - contract.deploy.json is at the ZIP root.
   - index.js is at the ZIP root and is the deployBinArgs target.
   - ever.deploy.json is included as a compatibility alias for tooling that
     refers to that manifest name.

This is a hybrid package: it contains both contract deployment manifests and an
everadmin.package.json runtime manifest, so the current EverAdmin ZIP shelf can
stage it as a contract or inspect/apply it through the runtime upgrader.


v0.2.4 scoring migration fixes:
- Empty AND/OR eligibility filters explicitly mean score every feed post.
- Empty scoring rules now restore the built-in EVR/Evernode +25 and XRP/XAH/XAHAU -10 defaults.
- Spam threshold defaults to 25/100 and score events are explicitly classified SPAM / not spam.
- Existing tracked posts are rescored when they reappear because the effective rules hash changes.

v0.2.3 fetch fixes:
- raw feed preview independent of scoring lookback
- NPL wait budget derived from consensus roundtime
- leader processes its fetched payload directly instead of waiting for self-broadcast
- ForumGuard and validator-health NPL consumers never run in same invocation
- 4-second round-friendly default HTTP timeout

v0.3.4 moderation build:
- Consensus moderation queue with configurable review/delete+ban/purge thresholds.
- Node-local Forum Manager credentials saved under ../custom.json → forumguard_manager using a read-only request to the connected validator; recovery.php is not involved.
- Forum Manager election over NPL: lowest numeric priority wins; validator public key breaks ties.
- Elected-manager phpBB web-form executor for post deletion, username bans, and ACP user purge. Real moderation runs inline; the non-destructive manager test may still use a local child process.
- Failed executor is skipped for that action so the next manager priority can retry.


Forum Manager local storage (v0.3.4):
- Uses EverAdmin's existing ../custom.json node-local store.
- Key: forumguard_manager (sensitive custom field).
- Save/status/clear use a read-only contract request to the connected validator, not recovery.php.
- The password is never returned by status and is redacted in normal Custom Data reads.


v0.3.6 Custom Data local-write experiment:
- Forum Manager save/clear use generic EverAdmin Custom Data local-only read-request handlers.
- No Forum Manager button calls recovery.php.
- forumguard_manager remains a sensitive JSON field in ../custom.json.
- Admin HTML navigation is network-only/cache-busted to prevent stale manager UI.


v0.3.7 Custom Data standard-write fix:
- Forum Manager Save/Clear now reuse the exact normal set-custom-value / clear-custom-value path that EverAdmin Custom Data uses.
- Writes target only the currently connected validator public key and persist to ../custom.json outside consensus state.
- The command payload still travels through HotPocket, matching the existing Custom Data semantics.
- forumguard_manager requires head-admin and JSON merge preserves a saved password when the password field is left blank.
- Read-only execution is used only for status reads; it no longer attempts to write the seed parent.


v0.3.8 moderation clarity/debug:
- Human-readable moderation states and explanations.
- Persisted per-action timeline: queued, assigned, worker failure, result timeout, manual retry, completed.
- Separate assignment / worker-failure / timeout counters.
- Selected + excluded executors shown in UI.
- Retry warning explains possible partial destructive work after timeouts.
- Each assignment has a sequence-specific local action/result file so stale prior results cannot poison retries.
- Worker spawn failures are converted into manager result files for deterministic failover.


v0.4.0 Forum Manager test + worker diagnostics:
- Adds a non-destructive Test Forum Manager button targeted to the connected validator.
- Test steps: saved config, worker launch, phpBB login, Moderator Control Panel access, ACP access.
- Worker status is persisted locally per assignment and broadcast as sanitized diagnostics.
- Worker stdout/stderr goes to a sequence-specific node-local .worker.log file.
- Early worker/bootstrap failures preserve actionId + assignmentSeq instead of becoming anonymous timeouts.
- Dead worker processes are detected and converted into explicit failures before the result timeout when possible.
- Test failures are terminal/non-destructive; destructive failures keep the existing failover behavior.
- Result timeout uses >= resultWaitLedgers, so an 8-ledger window is exactly 8 ledgers.
- Worker results and old result files are sanitized before NPL/consensus: cookies, SID/session data, HTML, headers, tokens, passwords, form bodies and credentials are dropped.
- Active/stale manager heartbeat state is now shown explicitly.

v0.4.0 local worker runtime + direct manager test:
- Fixes a real permission bug in v0.3.9: moderation worker IPC directories were siblings of ../custom.json. A validator may be able to update an existing custom.json while lacking permission to create new sibling directories, causing worker launch to disappear into a ledger timeout.
- Worker action/result/status/log IPC now lives in a private node-local temporary directory under os.tmpdir() (mode 0700), isolated from consensus state and from the seed parent directory.
- Worker runtime/setup failures are retained as local synthetic results so they can be reported instead of silently timing out.
- Test Forum Manager no longer enters the consensus moderation queue. It is a head-admin read-only request executed directly by the connected validator and returns in wall-clock time.
- The local test checks worker runtime writability, worker file presence, worker spawn, saved config, phpBB login, MCP access, and ACP access. It performs no moderation mutations.
- Last local test result is retained in the node-local temporary runtime for convenient reload display; diagnostics are sanitized.
- Temporary worker artifacts older than 48 hours are cleaned automatically.
- Legacy forum-manager-local-save/clear read-only write endpoints are explicitly disabled; manager persistence continues to use EverAdmin set-custom-value/clear-custom-value targeted at the selected validator.


v0.4.1 phpBB login verification:
- Login success is verified with a separate authenticated follow-up request instead of treating HTTP 200 / returned login markup as decisive.
- Preserves phpBB cookies across redirects and recognizes the authenticated user cookie/logout-session signals.
- Detects phpBB CAPTCHA / anti-spambot login-attempt challenges separately from bad credentials.
- Detects extra-authentication (2FA/OTP/WebAuthn) separately from bad credentials.
- Reports phpBB's recognizable login error when one is actually returned.
- If credentials are submitted but the session remains guest, reports a session/auth-flow problem without falsely claiming the password is wrong.
- Forum Manager test UI no longer duplicates Local worker runtime / Worker file rows.
- Successful login diagnostics show the independent follow-up-session verification.


v0.4.2 phpBB session/form-key hardening:
- Selects the strongest phpBB login form, preferring creation_time + form_token + sid instead of the first username/password form in the page.
- Resolves the POST action relative to the exact final URL that produced the login form and uses that URL as Referer.
- Sends Origin for the actual login target and disables cached login-form reuse.
- FORM_INVALID is retried exactly once using a completely new guest cookie/session and freshly fetched form key; real credential failures are never automatically retried.
- A second FORM_INVALID explicitly reports a cookie/SID/session compatibility problem instead of blaming the saved password.
- Fixes phpBB ACP re-authentication by supporting phpBB's dynamic password_<credential> field name.
- Keeps all token/cookie/SID values out of worker results and NPL.


v0.4.3 dashboard + phpBB guest-session compatibility:
- Restores the renderSpam() dashboard renderer accidentally omitted from v0.4.0-v0.4.2.
- Uses a browser-compatible cookie jar with Domain, Path, Secure and expiry handling.
- Keeps a single keep-alive connection where possible during phpBB authentication.
- Primes the phpBB guest session before fetching the login form.
- Preserves phpBB SID fallback transport when the board cannot rely on cookies.
- Adds safe guest-session continuity diagnostics without exposing cookies, SID or form tokens.


v0.4.4 phpBB minimum form-age fix:
- Fixes the phpBB FORM_INVALID loop caused by ForumGuard submitting a freshly generated form key in the exact same server second.
- phpBB check_form_key() intentionally rejects diff=0; the worker now waits at least 1150 ms after parsing every token-bearing phpBB form before POSTing it.
- The fix is generic, so login, ACP re-authentication, delete, ban, purge, and other creation_time + form_token submissions all receive the same protection.
- Regression-tested against a mock phpBB that reproduces phpBB's same-second rejection: v0.4.3 fails twice, v0.4.4 passes login -> MCP -> ACP.
- Dashboard renderSpam calls are guarded and renderSpam is explicitly exported on window to avoid transient hot-swap renderer errors.

v0.4.5 moderation-control audit:
- Restores the missing moderation command function that was accidentally dropped during the v0.4.0 manager-test refactor.
- Removes inline onclick handlers from moderation rows; queue/action buttons now use delegated listeners inside the dashboard IIFE, so scope changes cannot produce `moderateCase is not defined`.
- Audited all dashboard onclick attributes: v0.4.5 ships with zero inline onclick handlers.
- Delete+ban, purge, dismiss/reopen, and Retry now share one guarded moderation command path with explicit confirmation text.
- Prevents duplicate destructive actions while a case is already pending/running.
- Backend now rejects unsafe Retry while running/completed and rejects retry when there is no recorded failure/timeout/exclusion to clear.
- Dismiss/reopen is blocked while destructive phpBB work is active, because dismissing a review does not cancel an already-running worker.
- Keeps the working v0.4.4 phpBB form-age/session authentication fix unchanged.



v0.4.7 inline Forum Manager execution:
- Removes the detached background-child dependency from REAL moderation actions. Some HotPocket deployments terminate the contract invocation process tree when the round ends, which can kill a detached phpBB worker before it writes a result.
- The elected Forum Manager now runs login/delete/ban/purge inline inside its own contract invocation. Non-elected validators do not contact phpBB.
- The inline execution result is sanitized and buffered under ../custom.json -> forumguard_manager._forumguardRuntime on that validator. Credentials remain in the existing node-local Forum Manager object.
- On the next moderation round the elected manager broadcasts the buffered sanitized result over NPL; all validators then apply the same consensus moderation outcome.
- The private runtime buffer is removed automatically after consensus records the result.
- Direct Test Forum Manager keeps its existing non-destructive child-process test path, so it remains isolated from the real-action execution path.
- Inspect Manager Execution displays the buffered inline diagnostic/result plus legacy/test worker files.
- Keeps the v0.4.6 progress-aware timeout and late-result reconciliation as fallback protection.
- Keeps the working phpBB form-age/session fix and v0.4.5 moderation-button audit intact.


v0.5.5 ACP entry SID continuity fix:
- Enters phpBB ACP with the currently authenticated forum SID, matching phpBB's NEED_SID requirement and official functional-test sequence.
- Submits the ACP administrator confirmation against that exact forum session, then adopts the newly created session_admin SID for destructive user-management calls.
- Fixes boards where normal forum login succeeds but ACP re-authentication does not remain authenticated when adm/index.php is opened without ?sid=<forum-session>.

v0.5.3 ACP session-rotation purge fix:
- Fixes phpBB ACP re-authentication rotating the SID and ForumGuard accidentally reusing the pre-auth SID.
- ACP session is now verified with the newly issued cookie/SID before any destructive user-management request.
- Reproduces and fixes the exact `forms: search, login+token` purge failure returned by v0.5.2.

v0.5.2 ACP purge compatibility fix:
- Purge no longer requires an exact #user_delete form in the rendered ACP template.
- If that form is hidden/renamed by an ACP style or extension, ForumGuard reuses another acp_users token-bearing overview form and submits phpBB's native delete/remove parameters.
- phpBB still performs all permission, founder, self-delete and confirmation checks.

v0.5.1 moderation execution + package integrity fix:
- Permanent and timed user bans both use phpBB MCP ban flow and complete its confirmation step.
- Purge retries are idempotent: if a prior attempt already removed the user, retry records success instead of failing forever.
- phpBB worker errors include the returned page/error text and failed step for easier diagnosis.
- Runtime package manifest hashes/sizes are regenerated so the upgrader can actually apply the patched files.
- Dashboard status surfaces the exact worker error next to FAILED -> WAITING FOR FAILOVER.

v0.5.0 cluster scoring + moderation safety:
- Shared State score remains the consensus rule-set score.
- Each validator can store forumguard_individual_scoring in ../custom.json and cast its own post score vote.
- Cluster score is the normalized arithmetic mean of individual validator votes and records vote count/completeness.
- Moderation queue has Delete, Delete + Ban and Purge User controls with a 15+ row scroll viewport.
- Comma-separated whitelist protects usernames or id:<n>/#<n> identities from all destructive moderation while keeping analytics.
- ACP ban/purge can resolve users by username when the feed does not contain a numeric phpBB user ID.


v0.5.5 phpBB confirmation replay fix:
- Confirmation POSTs now use the exact localized Yes submit value rendered by phpBB instead of confirm=1.
- Preserves confirm_uid, sess, sid and confirm_key from phpBB's confirmation form/action.
- Fixes ACP purge failures reporting: The submitted form was invalid.

v0.5.6 score-basis quorum vote:
- Restores the per-validator checkbox ballot for using Cluster score instead of State score as the effective moderation score.
- The ballot no longer uses a separate >50% majority. It uses the same HotPocket consensus threshold configured for the cluster.
- Required score-mode votes are calculated exactly like the regular quorum: ceil(UNL validators × consensus threshold / 100).
- The quorum follows future consensus-threshold changes automatically.

<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

$healthFile = realpath(__DIR__ . '/../unl-health.json');
$expectedSeedRoot = realpath(__DIR__ . '/..');

if ($healthFile === false || $expectedSeedRoot === false || !str_starts_with($healthFile, $expectedSeedRoot . DIRECTORY_SEPARATOR) || !is_file($healthFile) || !is_readable($healthFile)) {
    http_response_code(503);
    echo json_encode([
        'ok' => false,
        'source' => '../unl-health.json',
        'error' => 'Node-local recovery health is not available yet.',
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

$decoded = json_decode((string) file_get_contents($healthFile), true);
if (!is_array($decoded)) {
    http_response_code(503);
    echo json_encode([
        'ok' => false,
        'source' => '../unl-health.json',
        'error' => 'Node-local recovery health is invalid.',
    ], JSON_UNESCAPED_SLASHES);
    exit;
}

$validPort = static function (mixed $value): ?int {
    if (!is_int($value) && !is_string($value) && !is_float($value)) {
        return null;
    }
    $port = (int) $value;
    return $port >= 1 && $port <= 65535 ? $port : null;
};

$validKey = static function (mixed $value): ?string {
    $key = strtolower(trim((string) $value));
    if (preg_match('/^ed[0-9a-f]{64}$/', $key) === 1) {
        return $key;
    }
    if (preg_match('/^[0-9a-f]{64}$/', $key) === 1) {
        return 'ed' . $key;
    }
    return null;
};

$reporter = $validKey($decoded['reporterPublicKey'] ?? null);
$localRuntime = is_array($decoded['localRuntime'] ?? null) ? $decoded['localRuntime'] : [];
$localKey = $validKey($localRuntime['nodePublicKey'] ?? null) ?? $reporter;
$localUserPort = $validPort($localRuntime['userPort'] ?? null);
$localMeshPort = $validPort($localRuntime['meshPort'] ?? null);
$runtimeUpdatedAt = (int) ($localRuntime['updatedAt'] ?? $decoded['runtimeUpdatedAt'] ?? 0);

$observations = is_array($decoded['observations'] ?? null) ? $decoded['observations'] : [];
$validators = [];
foreach ($observations as $publicKey => $observation) {
    if (!is_array($observation)) {
        continue;
    }
    $key = $validKey($publicKey);
    if ($key === null) {
        continue;
    }
    $status = strtolower(trim((string) ($observation['status'] ?? 'unknown')));
    if (!in_array($status, ['alive', 'silent', 'unknown'], true)) {
        $status = 'unknown';
    }
    $validators[] = [
        'publicKey' => $key,
        'status' => $status,
        'userPort' => $validPort($observation['userPort'] ?? null),
        'meshPort' => $validPort($observation['meshPort'] ?? null),
        'observedAt' => (int) ($observation['observedAt'] ?? 0) ?: null,
    ];
}

if ($localUserPort === null && $localKey !== null) {
    foreach ($validators as $validator) {
        if ($validator['publicKey'] === $localKey && $validator['userPort'] !== null) {
            $localUserPort = $validator['userPort'];
            if ($localMeshPort === null) {
                $localMeshPort = $validator['meshPort'];
            }
            break;
        }
    }
}

usort($validators, static fn(array $a, array $b): int => strcmp($a['publicKey'], $b['publicKey']));

if ($localUserPort === null) {
    http_response_code(503);
}

echo json_encode([
    'ok' => $localUserPort !== null,
    'source' => '../unl-health.json',
    'localNodePublicKey' => $localKey,
    'localUserPort' => $localUserPort,
    'localMeshPort' => $localMeshPort,
    'updatedAt' => $runtimeUpdatedAt > 0 ? $runtimeUpdatedAt : null,
    'validators' => $validators,
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

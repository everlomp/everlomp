'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const zlib = require('zlib');
const os = require('os');

const APP_NAME = 'ForumGuard Spam Engine';
const APP_VERSION = '0.5.6';
const STATE_ROOT = process.cwd();
const STATE_FILE = path.resolve(STATE_ROOT, 'spam-oracle-state.json');
const CONFIG_FILE = path.resolve(STATE_ROOT, 'spam-oracle-config.json');
const EVENT_FILE = path.resolve(STATE_ROOT, 'spam-score-events.ndjson');
const DEFAULT_CONFIG_FILE = path.resolve(__dirname, 'spam-config.default.json');
const LOCAL_CUSTOM_FILE = path.resolve(STATE_ROOT, '..', 'custom.json');
const LOCAL_MANAGER_KEY = 'forumguard_manager';
const LOCAL_SCORING_KEY = 'forumguard_individual_scoring';
function normalizeAdminPath(value) {
  let v = safeString(value || 'adm/', 80).replace(/\\/g, '/').replace(/^\/+/, '').replace(/\/+$/, '');
  if (!v) v = 'adm';
  const parts = v.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || !/^[A-Za-z0-9._-]+$/.test(part))) throw new Error('ACP path must be a relative directory such as adm/.');
  return parts.join('/') + '/';
}
function readLocalCustomRoot() {
  const d = readJson(LOCAL_CUSTOM_FILE, {});
  return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
}
function writeLocalCustomRoot(d) {
  fs.mkdirSync(path.dirname(LOCAL_CUSTOM_FILE), { recursive: true });
  fs.writeFileSync(LOCAL_CUSTOM_FILE, JSON.stringify(d, null, 2) + '\n', { mode: 0o600 });
  try { fs.chmodSync(LOCAL_CUSTOM_FILE, 0o600); } catch {}
}
function localManagerPrivate() {
  const root = readLocalCustomRoot();
  const d = root[LOCAL_MANAGER_KEY] && typeof root[LOCAL_MANAGER_KEY] === 'object' && !Array.isArray(root[LOCAL_MANAGER_KEY]) ? root[LOCAL_MANAGER_KEY] : {};
  return {
    forumManager: d.forumManager === true,
    priority: finiteInt(d.priority, 100, 1, 1000000),
    forumUrl: safeString(d.forumUrl || 'https://evernode.forum', 2048),
    username: safeString(d.username, 255),
    password: safeString(d.password, 4096),
    requestTimeoutMs: finiteInt(d.requestTimeoutMs, 5000, 1000, 20000),
    adminPath: (() => { try { return normalizeAdminPath(d.adminPath || 'adm/'); } catch { return 'adm/'; } })()
  };
}
function localManagerStorage() { return { path: '../custom.json', key: LOCAL_MANAGER_KEY, scope: 'node-local-seed', consensusState: false }; }
const LOCAL_MANAGER_RUNTIME_KEY = '_forumguardRuntime';
function readLocalManagerRuntime(){
  try{const root=readLocalCustomRoot(),m=root[LOCAL_MANAGER_KEY];const r=m&&typeof m==='object'&&!Array.isArray(m)?m[LOCAL_MANAGER_RUNTIME_KEY]:null;return r&&typeof r==='object'&&!Array.isArray(r)?r:{};}catch{return {};}
}
function writeLocalManagerRuntime(patch){
  const root=readLocalCustomRoot();
  const m=root[LOCAL_MANAGER_KEY]&&typeof root[LOCAL_MANAGER_KEY]==='object'&&!Array.isArray(root[LOCAL_MANAGER_KEY])?root[LOCAL_MANAGER_KEY]:{};
  const prior=m[LOCAL_MANAGER_RUNTIME_KEY]&&typeof m[LOCAL_MANAGER_RUNTIME_KEY]==='object'&&!Array.isArray(m[LOCAL_MANAGER_RUNTIME_KEY])?m[LOCAL_MANAGER_RUNTIME_KEY]:{};
  m[LOCAL_MANAGER_RUNTIME_KEY]={...prior,...patch,updatedAt:Date.now()}; root[LOCAL_MANAGER_KEY]=m; writeLocalCustomRoot(root); return m[LOCAL_MANAGER_RUNTIME_KEY];
}
function clearLocalManagerRuntime(){
  try{const root=readLocalCustomRoot(),m=root[LOCAL_MANAGER_KEY];if(m&&typeof m==='object'&&!Array.isArray(m)&&Object.prototype.hasOwnProperty.call(m,LOCAL_MANAGER_RUNTIME_KEY)){delete m[LOCAL_MANAGER_RUNTIME_KEY];root[LOCAL_MANAGER_KEY]=m;writeLocalCustomRoot(root);}}catch{}
}
function getLocalManagerStatus() { const d = localManagerPrivate(); return { forumManager:d.forumManager, priority:d.priority, forumUrl:d.forumUrl, username:d.username, passwordSet:!!d.password, requestTimeoutMs:d.requestTimeoutMs, adminPath:d.adminPath, storage:localManagerStorage(), workerRuntime:workerRuntimeStatus(), lastLocalTest:sanitizeWorkerResult(readJson(LOCAL_TEST_RESULT_FILE,null)) }; }
function saveLocalManager(input) {
  const root = readLocalCustomRoot();
  const current = localManagerPrivate();
  const next = {
    forumManager: input && input.forumManager === true,
    priority: finiteInt(input && input.priority, current.priority, 1, 1000000),
    forumUrl: safeString(input && input.forumUrl || current.forumUrl || 'https://evernode.forum', 2048),
    username: safeString(input && input.username !== undefined ? input.username : current.username, 255),
    password: input && Object.prototype.hasOwnProperty.call(input, 'password') && safeString(input.password, 4096) ? safeString(input.password, 4096) : current.password,
    requestTimeoutMs: finiteInt(input && input.requestTimeoutMs, current.requestTimeoutMs, 1000, 20000),
    adminPath: normalizeAdminPath(input && input.adminPath || current.adminPath || 'adm/')
  };
  if (next.forumManager && (!next.forumUrl || !next.username || !next.password)) throw new Error('Forum Manager requires forum URL, username and password.');
  const priorRuntime = root[LOCAL_MANAGER_KEY] && typeof root[LOCAL_MANAGER_KEY] === 'object' && !Array.isArray(root[LOCAL_MANAGER_KEY]) ? root[LOCAL_MANAGER_KEY][LOCAL_MANAGER_RUNTIME_KEY] : null;
  if (priorRuntime && typeof priorRuntime === 'object' && !Array.isArray(priorRuntime)) next[LOCAL_MANAGER_RUNTIME_KEY] = priorRuntime;
  root[LOCAL_MANAGER_KEY] = next;
  writeLocalCustomRoot(root);
  return getLocalManagerStatus();
}
function clearLocalManager() { const root = readLocalCustomRoot(); delete root[LOCAL_MANAGER_KEY]; writeLocalCustomRoot(root); return getLocalManagerStatus(); }
const LOCAL_RUNTIME_ROOT = path.join(os.tmpdir(), 'forumguard-manager');
const LOCAL_ACTION_DIR = path.join(LOCAL_RUNTIME_ROOT, 'actions');
const LOCAL_RESULT_DIR = path.join(LOCAL_RUNTIME_ROOT, 'results');
const LOCAL_WORKER_LOG_DIR = path.join(LOCAL_RUNTIME_ROOT, 'logs');
const LOCAL_TEST_RESULT_FILE = path.join(LOCAL_RUNTIME_ROOT, 'last-manager-test.json');
const localImmediateResults = new Map();
function ensureLocalRuntimeDirs(){
  fs.mkdirSync(LOCAL_RUNTIME_ROOT,{recursive:true,mode:0o700});
  fs.mkdirSync(LOCAL_ACTION_DIR,{recursive:true,mode:0o700});
  fs.mkdirSync(LOCAL_RESULT_DIR,{recursive:true,mode:0o700});
  fs.mkdirSync(LOCAL_WORKER_LOG_DIR,{recursive:true,mode:0o700});
  try{fs.chmodSync(LOCAL_RUNTIME_ROOT,0o700);fs.chmodSync(LOCAL_ACTION_DIR,0o700);fs.chmodSync(LOCAL_RESULT_DIR,0o700);fs.chmodSync(LOCAL_WORKER_LOG_DIR,0o700);}catch{}
  return LOCAL_RUNTIME_ROOT;
}
function workerRuntimeStatus(){
  const out={runtimeRoot:LOCAL_RUNTIME_ROOT,writable:false,workerExists:fs.existsSync(path.resolve(__dirname,'forum-manager-worker.js')),nodeExecutable:process.execPath};
  try{ensureLocalRuntimeDirs();const probe=path.join(LOCAL_RUNTIME_ROOT,`.probe-${process.pid}-${Date.now()}`);fs.writeFileSync(probe,'ok',{mode:0o600});fs.unlinkSync(probe);out.writable=true;}catch(e){out.error=safeString(e&&e.message||e,700);} return out;
}
function cleanupLocalRuntime(maxAgeMs=48*60*60*1000){try{ensureLocalRuntimeDirs();const cutoff=Date.now()-maxAgeMs;for(const dir of [LOCAL_ACTION_DIR,LOCAL_RESULT_DIR,LOCAL_WORKER_LOG_DIR]){for(const name of fs.readdirSync(dir).slice(0,2000)){const f=path.join(dir,name);try{const st=fs.statSync(f);if(st.isFile()&&st.mtimeMs<cutoff)fs.unlinkSync(f);}catch{}}}}catch{}}
let runtime = null;
let localLegacyResultsScrubbed = false;

function safeString(value, max = 4096) {
  return String(value === undefined || value === null ? '' : value).trim().slice(0, max);
}
function sanitizeDiagnosticValue(value, depth = 0) {
  if (depth > 4 || value === undefined) return null;
  if (value === null || typeof value === 'boolean' || typeof value === 'number') return value;
  if (typeof value === 'string') return safeString(value, 800);
  if (Array.isArray(value)) return value.slice(0, 25).map(v => sanitizeDiagnosticValue(v, depth + 1));
  if (typeof value !== 'object') return safeString(value, 300);
  const out = {};
  for (const [k, v] of Object.entries(value)) {
    if (/password|passwd|cookie|sid|session|token|secret|authorization|csrf|form|html|header|body|credential/i.test(k)) continue;
    out[safeString(k, 80)] = sanitizeDiagnosticValue(v, depth + 1);
  }
  return out;
}
function sanitizeWorkerResult(raw) {
  if (!raw || typeof raw !== 'object') return null;
  return {
    schema: finiteInt(raw.schema, 3, 1, 100),
    workerVersion: safeString(raw.workerVersion, 40),
    actionId: safeString(raw.actionId, 64),
    assignmentSeq: finiteInt(raw.assignmentSeq, 0, 0, 1000000),
    executor: safeString(raw.executor || raw.publicKey, 160),
    startedAt: finiteInt(raw.startedAt, 0, 0, Number.MAX_SAFE_INTEGER),
    finishedAt: finiteInt(raw.finishedAt, 0, 0, Number.MAX_SAFE_INTEGER),
    ok: raw.ok === true,
    error: safeString(raw.error, 1000),
    failedStep: safeString(raw.failedStep, 100),
    detail: sanitizeDiagnosticValue(raw.detail || null),
    runtime: raw.runtime && typeof raw.runtime === 'object' ? {
      runtimeRoot: safeString(raw.runtime.runtimeRoot, 500),
      writable: raw.runtime.writable === true,
      workerExists: raw.runtime.workerExists === true,
      nodeExecutable: safeString(raw.runtime.nodeExecutable, 500),
      error: safeString(raw.runtime.error, 700)
    } : null,
    steps: Array.isArray(raw.steps) ? raw.steps.slice(0, 25).map(step => ({
      name: safeString(step && step.name, 100),
      ok: step && step.ok === true,
      startedAt: finiteInt(step && step.startedAt, 0, 0, Number.MAX_SAFE_INTEGER),
      finishedAt: finiteInt(step && step.finishedAt, 0, 0, Number.MAX_SAFE_INTEGER),
      error: safeString(step && step.error, 1000),
      detail: sanitizeDiagnosticValue(step && step.detail || null)
    })) : []
  };
}
function sanitizeWorkerDiagnostic(raw) {
  if (!raw || typeof raw !== 'object') return null;
  return {
    schema: finiteInt(raw.schema, 2, 1, 100),
    workerVersion: safeString(raw.workerVersion, 40),
    stage: safeString(raw.stage, 80),
    step: safeString(raw.step, 100),
    actionType: safeString(raw.actionType, 80),
    actionId: safeString(raw.actionId, 64),
    assignmentSeq: finiteInt(raw.assignmentSeq, 0, 0, 1000000),
    executor: safeString(raw.executor || raw.publicKey, 160),
    pid: finiteInt(raw.pid, 0, 0, Number.MAX_SAFE_INTEGER),
    updatedAt: finiteInt(raw.updatedAt, 0, 0, Number.MAX_SAFE_INTEGER),
    startedAt: finiteInt(raw.startedAt, 0, 0, Number.MAX_SAFE_INTEGER),
    finishedAt: finiteInt(raw.finishedAt, 0, 0, Number.MAX_SAFE_INTEGER),
    error: safeString(raw.error, 1000),
    failedStep: safeString(raw.failedStep, 100),
    detail: sanitizeDiagnosticValue(raw.detail || null)
  };
}
function finiteInt(value, fallback = 0, min = -1000000, max = 1000000) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.trunc(n)));
}
function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function readJson(file, fallback) {
  if (!fs.existsSync(file)) return fallback;
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) { fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n'); }
function ledgerNo(ctx) {
  const n = Number(ctx && ctx.lclSeqNo);
  return Number.isFinite(n) ? Math.trunc(n) : null;
}
function ledgerTimeMs(ctx) {
  const raw = Number(ctx && ctx.timestamp);
  if (!Number.isFinite(raw) || raw <= 0) return null;
  return raw < 100000000000 ? Math.trunc(raw * 1000) : Math.trunc(raw);
}
function publicKeyHex(value) {
  if (Buffer.isBuffer(value) || value instanceof Uint8Array) {
    let hex = Buffer.from(value).toString('hex').toLowerCase();
    if (hex.length === 64) hex = 'ed' + hex;
    return hex;
  }
  let s = safeString(value, 160).toLowerCase();
  if (/^[0-9a-f]{64}$/.test(s)) s = 'ed' + s;
  return s;
}
function getUserKey(user) {
  const key = publicKeyHex(user && (user.publicKey || user.pubkey || user.key || user.id));
  if (!/^ed[0-9a-f]{64}$/.test(key)) throw new Error('Could not determine HotPocket user public key.');
  return key;
}
function defaultConfig() {
  const cfg = readJson(DEFAULT_CONFIG_FILE, null);
  return normalizeConfig(cfg || {});
}
function initialState() {
  return {
    schema: 7,
    admins: [],
    feeders: [],
    users: {},
    posts: {},
    sourceStatus: {},
    feedPreview: {},
    recentEvents: [],
    moderationCases: {},
    moderationActions: {},
    managerRegistry: {},
    moderationRuntime: { lastHeartbeatLedger: 0 },
    clusterScoring: { lastVoteLedger: 0, expectedVoters: [], votesApplied: 0, scoreModeVotes: {}, clusterModeYes: 0, clusterModeRequired: 0, clusterModeActive: false, consensusThresholdPercent: 80 },
    totals: {
      fetchAttempts: 0,
      fetchSuccesses: 0,
      fetchErrors: 0,
      postsSeen: 0,
      scored: 0,
      spamTargeted: 0,
      filtered: 0,
      duplicates: 0,
      rescored: 0,
      tooOld: 0,
      moderationQueued: 0,
      moderationCompleted: 0,
      moderationFailed: 0,
      moderationTimeouts: 0,
      moderationDismissed: 0,
      managerTestsQueued: 0,
      managerTestsPassed: 0,
      managerTestsFailed: 0,
      clusterVotesReceived: 0,
      clusterScoreUpdates: 0
    },
    lastLedger: null
  };
}
function loadState() {
  const s = readJson(STATE_FILE, initialState());
  s.schema = 7;
  s.admins = Array.isArray(s.admins) ? [...new Set(s.admins.map(publicKeyHex).filter(k => /^ed[0-9a-f]{64}$/.test(k)))] : [];
  s.feeders = Array.isArray(s.feeders) ? [...new Set(s.feeders.map(publicKeyHex).filter(k => /^ed[0-9a-f]{64}$/.test(k)))] : [];
  s.users = s.users && typeof s.users === 'object' ? s.users : {};
  s.posts = s.posts && typeof s.posts === 'object' ? s.posts : {};
  s.sourceStatus = s.sourceStatus && typeof s.sourceStatus === 'object' ? s.sourceStatus : {};
  s.feedPreview = s.feedPreview && typeof s.feedPreview === 'object' ? s.feedPreview : {};
  s.recentEvents = Array.isArray(s.recentEvents) ? s.recentEvents : [];
  s.moderationCases = s.moderationCases && typeof s.moderationCases === 'object' ? s.moderationCases : {};
  s.moderationActions = s.moderationActions && typeof s.moderationActions === 'object' ? s.moderationActions : {};
  for (const a of Object.values(s.moderationActions)) ensureActionMeta(a);
  s.managerRegistry = s.managerRegistry && typeof s.managerRegistry === 'object' ? s.managerRegistry : {};
  s.moderationRuntime = s.moderationRuntime && typeof s.moderationRuntime === 'object' ? s.moderationRuntime : {lastHeartbeatLedger:0};
  s.clusterScoring = s.clusterScoring && typeof s.clusterScoring === 'object' ? s.clusterScoring : {lastVoteLedger:0,expectedVoters:[],votesApplied:0,scoreModeVotes:{},consensusThresholdPercent:80};
  s.clusterScoring.expectedVoters = Array.isArray(s.clusterScoring.expectedVoters) ? s.clusterScoring.expectedVoters.map(publicKeyHex).filter(k=>/^ed[0-9a-f]{64}$/.test(k)) : [];
  s.clusterScoring.scoreModeVotes = s.clusterScoring.scoreModeVotes && typeof s.clusterScoring.scoreModeVotes === 'object' && !Array.isArray(s.clusterScoring.scoreModeVotes) ? s.clusterScoring.scoreModeVotes : {};
  const mode=refreshClusterScoringMode(s,s.clusterScoring.expectedVoters,{thresholdPercent:finiteInt(s.clusterScoring.consensusThresholdPercent,80,1,100)});
  for (const post of Object.values(s.posts)) { if (!post || typeof post !== 'object') continue; if (post.stateScore === undefined) post.stateScore = finiteInt(post.score,0,-100000000,100000000); if (post.stateRawScore === undefined) post.stateRawScore = finiteInt(post.rawScore,post.stateScore,-100000000,100000000); if (post.stateReasons === undefined) post.stateReasons = Array.isArray(post.reasons)?post.reasons:[]; if (post.stateIsSpam === undefined) post.stateIsSpam = post.isSpam===true; post.clusterVotes = post.clusterVotes && typeof post.clusterVotes === 'object' && !Array.isArray(post.clusterVotes) ? post.clusterVotes : {}; refreshPostClusterScore(post,s.clusterScoring.expectedVoters,mode.clusterModeActive); }
  s.totals = Object.assign(initialState().totals, s.totals || {});
  return s;
}
function loadConfig() {
  if (!fs.existsSync(CONFIG_FILE)) return defaultConfig();
  return normalizeConfig(readJson(CONFIG_FILE, defaultConfig()));
}
function normalizeUrl(value) {
  const raw = safeString(value, 2048);
  let u;
  try { u = new URL(raw); } catch { throw new Error(`Invalid feed URL: ${raw}`); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Feed URLs must use http:// or https://.');
  u.username = '';
  u.password = '';
  return u.toString();
}
function normalizeSource(raw, index, fetchDefaults) {
  if (!raw || typeof raw !== 'object') throw new Error('Feed sources must be objects.');
  const id = safeString(raw.id || `source-${index + 1}`, 80).toLowerCase();
  if (!/^[a-z0-9][a-z0-9._-]{0,79}$/.test(id)) throw new Error(`Invalid feed source id: ${id}`);
  const format = safeString(raw.format || 'auto', 16).toLowerCase();
  if (!['auto', 'atom', 'rss'].includes(format)) throw new Error(`Invalid feed format for ${id}.`);
  return {
    id,
    url: normalizeUrl(raw.url),
    format,
    enabled: raw.enabled !== false,
    pollEveryMinutes: finiteInt(raw.pollEveryMinutes, fetchDefaults.pollEveryMinutes, 1, 10080),
    lookbackMinutes: finiteInt(raw.lookbackMinutes, fetchDefaults.lookbackMinutes, 1, 525600)
  };
}
function normalizeRule(rule, scoring = false) {
  if (!rule || typeof rule !== 'object') throw new Error('Rules must be objects.');
  const field = safeString(rule.field || 'text', 32);
  if (!['text', 'username', 'userId', 'source', 'topicTitle', 'link'].includes(field)) throw new Error(`Unsupported rule field: ${field}`);
  const value = safeString(rule.value, 512);
  if (!value) throw new Error('Rule value cannot be empty.');
  const out = { field, value, caseSensitive: rule.caseSensitive === true };
  if (!scoring) {
    const op = safeString(rule.operator || rule.op, 32).toLowerCase().replace(/-/g, '_');
    if (!['contains', 'not_contains'].includes(op)) throw new Error('Filter operator must be contains or not_contains.');
    out.operator = op;
  } else {
    out.points = finiteInt(rule.points, 1, -100000, 100000);
  }
  return out;
}

function normalizeScoreRule(rule) {
  if (!rule || typeof rule !== 'object') throw new Error('Scoring rules must be objects.');
  const field = safeString(rule.field || 'text', 32);
  if (!['text', 'username', 'userId', 'source', 'topicTitle', 'link'].includes(field)) throw new Error(`Unsupported scoring field: ${field}`);
  const when = safeString(rule.when || rule.operator || 'contains', 32).toLowerCase().replace(/-/g, '_');
  if (!['contains', 'not_contains', 'contains_any', 'contains_none'].includes(when)) {
    throw new Error('Scoring rule "when" must be contains, not_contains, contains_any, or contains_none.');
  }
  const out = {
    label: safeString(rule.label || '', 120),
    field,
    when,
    points: finiteInt(rule.points, 1, -100, 100),
    caseSensitive: rule.caseSensitive === true
  };
  if (when === 'contains_any' || when === 'contains_none') {
    const rawValues = Array.isArray(rule.values) ? rule.values : [];
    out.values = [...new Set(rawValues.map(v => safeString(v, 512)).filter(Boolean))].slice(0, 50);
    if (!out.values.length) throw new Error(`${when} scoring rule needs at least one value.`);
  } else {
    out.value = safeString(rule.value, 512);
    if (!out.value) throw new Error(`${when} scoring rule needs a value.`);
  }
  return out;
}

function defaultScoreRules() {
  return [
    { label: 'Missing Evernode context', field: 'text', when: 'contains_none', values: ['EVR', 'Evernode'], points: 25, caseSensitive: false },
    { label: 'XRP / XAH / XAHAU context', field: 'text', when: 'contains_any', values: ['XRP', 'XAH', 'XAHAU'], points: -10, caseSensitive: false }
  ];
}
function legacyScoringRules(scoring, schema) {
  // Empty rules means "use the sensible built-in defaults". This also migrates
  // older ForumGuard configs that saved rules: [] and accidentally scored everything 0.
  if (Array.isArray(scoring.rules) && scoring.rules.length > 0) return scoring.rules;
  const rules = [];
  for (const r of (Array.isArray(scoring.requiredAny) ? scoring.requiredAny : [])) {
    rules.push({ label: r.label || '', field: r.field || 'text', when: 'contains_none', values: r.values || [], points: r.points ?? r.pointsIfMissing ?? 1, caseSensitive: r.caseSensitive === true });
  }
  for (const r of (Array.isArray(scoring.contains) ? scoring.contains : [])) {
    rules.push({ label: r.label || '', field: r.field || 'text', when: 'contains', value: r.value, points: r.points ?? 1, caseSensitive: r.caseSensitive === true });
  }
  for (const r of (Array.isArray(scoring.notContains) ? scoring.notContains : [])) {
    rules.push({ label: r.label || '', field: r.field || 'text', when: 'not_contains', value: r.value, points: r.points ?? 1, caseSensitive: r.caseSensitive === true });
  }
  if (rules.length) return rules;
  return defaultScoreRules();
}

function normalizeWhitelistUsers(value) {
  const raw = Array.isArray(value) ? value : String(value || '').split(',');
  return [...new Set(raw.map(v => safeString(v, 255).trim()).filter(Boolean).map(v => v.toLowerCase()))].slice(0, 1000);
}
function isWhitelistedIdentity(identity, config) {
  const list = config?.moderation?.whitelist?.users || [];
  if (!list.length) return false;
  const username = safeString(identity?.username, 255).trim().toLowerCase();
  const userId = safeString(identity?.userId, 100).trim().toLowerCase();
  return list.some(raw => {
    const v = safeString(raw,255).trim().toLowerCase();
    if (!v) return false;
    if (v.startsWith('id:')) return !!userId && userId === v.slice(3).trim();
    if (v.startsWith('#')) return !!userId && userId === v.slice(1).trim();
    return !!username && username === v;
  });
}
function moderationScoreView(post) {
  const stateScore = Number(post?.stateScore ?? post?.score ?? 0);
  const maxScore = Math.max(1, Number(post?.maxScore || 100));
  const votes = Math.max(0, Number(post?.clusterVoteCount || 0));
  const clusterScore = votes > 0 && Number.isFinite(Number(post?.clusterScore)) ? Number(post.clusterScore) : null;
  const basis = post?.effectiveScoreBasis === 'cluster' && clusterScore !== null ? 'cluster' : 'state';
  const effective = basis === 'cluster' ? clusterScore : stateScore;
  return {score:effective,maxScore,reasons:Array.isArray(post?.stateReasons)?post.stateReasons:(Array.isArray(post?.reasons)?post.reasons:[]),stateScore,clusterScore,clusterVoteCount:votes,clusterExpectedCount:Math.max(0,Number(post?.clusterExpectedCount||0)),clusterComplete:post?.clusterComplete===true,basis};
}
function scoreModeConsensusQuorum(hpConfig, expectedVoters=[]) {
  const expected = Array.isArray(expectedVoters) ? [...new Set(expectedVoters.map(publicKeyHex).filter(k=>/^ed[0-9a-f]{64}$/.test(k)))] : [];
  const c=hpConfig&&hpConfig.contract&&typeof hpConfig.contract==='object'?hpConfig.contract:(hpConfig||{});
  const raw=Number(c?.consensus?.threshold);
  const thresholdPercent=Number.isInteger(raw)&&raw>=1&&raw<=100?raw:80;
  return {thresholdPercent,totalNodes:expected.length,requiredVotes:expected.length?Math.max(1,Math.ceil(expected.length*thresholdPercent/100)):0};
}
function clusterScoringModeSummary(clusterScoring, expectedVoters=[], quorumInfo={}) {
  const expected = Array.isArray(expectedVoters) ? [...new Set(expectedVoters.map(publicKeyHex).filter(k=>/^ed[0-9a-f]{64}$/.test(k)))] : [];
  const raw = clusterScoring?.scoreModeVotes && typeof clusterScoring.scoreModeVotes === 'object' && !Array.isArray(clusterScoring.scoreModeVotes) ? clusterScoring.scoreModeVotes : {};
  const votes = {};
  for (const pk of expected) {
    const v=raw[pk];
    if (!v || typeof v !== 'object') continue;
    votes[pk]={useClusterScore:v.useClusterScore===true,ledger:finiteInt(v.ledger,0,0,Number.MAX_SAFE_INTEGER)};
  }
  const yes=Object.values(votes).filter(v=>v.useClusterScore===true).length;
  const storedThreshold=finiteInt(clusterScoring?.consensusThresholdPercent,80,1,100);
  const thresholdPercent=finiteInt(quorumInfo?.thresholdPercent,storedThreshold,1,100);
  const required=expected.length?Math.max(1,Math.ceil(expected.length*thresholdPercent/100)):0;
  return {expectedVoters:expected,expectedCount:expected.length,votes,ballotsReceived:Object.keys(votes).length,clusterModeYes:yes,clusterModeRequired:required,clusterModeActive:required>0&&yes>=required,consensusThresholdPercent:thresholdPercent,quorumSource:'hotpocket-consensus-threshold'};
}
function refreshClusterScoringMode(state, expectedVoters=[], quorumInfo={}) {
  state.clusterScoring=state.clusterScoring&&typeof state.clusterScoring==='object'?state.clusterScoring:{};
  const summary=clusterScoringModeSummary(state.clusterScoring,expectedVoters,quorumInfo);
  state.clusterScoring.expectedVoters=summary.expectedVoters;
  state.clusterScoring.scoreModeVotes=summary.votes;
  state.clusterScoring.clusterModeYes=summary.clusterModeYes;
  state.clusterScoring.clusterModeRequired=summary.clusterModeRequired;
  state.clusterScoring.clusterModeActive=summary.clusterModeActive;
  state.clusterScoring.ballotsReceived=summary.ballotsReceived;
  state.clusterScoring.consensusThresholdPercent=summary.consensusThresholdPercent;
  state.clusterScoring.quorumSource=summary.quorumSource;
  return summary;
}
function refreshPostClusterScore(post, expectedVoters=[], useClusterEffective=false) {
  if (!post || typeof post !== 'object') return post;
  post.clusterVotes = post.clusterVotes && typeof post.clusterVotes === 'object' && !Array.isArray(post.clusterVotes) ? post.clusterVotes : {};
  const expected = Array.isArray(expectedVoters) ? [...new Set(expectedVoters.map(publicKeyHex).filter(k=>/^ed[0-9a-f]{64}$/.test(k)))] : [];
  const entries = Object.entries(post.clusterVotes).filter(([pk,v]) => /^ed[0-9a-f]{64}$/.test(publicKeyHex(pk)) && v && v.contentHash === post.contentHash && (!expected.length || expected.includes(publicKeyHex(pk))));
  const targetMax = Math.max(1, finiteInt(post.maxScore,100,1,1000));
  const normalized = entries.map(([,v]) => {
    const vm = Math.max(1, finiteInt(v.maxScore,100,1,1000));
    const vs = Math.max(0, Math.min(vm, Number(v.score)||0));
    return (vs / vm) * targetMax;
  });
  post.clusterVoteCount = normalized.length;
  post.clusterExpectedCount = expected.length;
  post.clusterComplete = expected.length ? normalized.length >= expected.length : normalized.length > 0;
  post.clusterScore = normalized.length ? Math.round((normalized.reduce((a,b)=>a+b,0)/normalized.length)*10)/10 : null;
  post.clusterIsSpam = normalized.length ? post.clusterScore >= finiteInt(post.spamThreshold,25,0,targetMax) : false;
  post.stateScore = Number(post.stateScore ?? post.score ?? 0);
  post.stateIsSpam = post.stateScore >= finiteInt(post.spamThreshold,25,0,targetMax);
  const clusterEffective = useClusterEffective === true && normalized.length > 0;
  post.effectiveScore = clusterEffective ? post.clusterScore : post.stateScore;
  post.effectiveScoreBasis = clusterEffective ? 'cluster' : 'state';
  post.isSpam = post.effectiveScore >= finiteInt(post.spamThreshold,25,0,targetMax);
  return post;
}
function normalizeLocalScoring(input, sharedConfig) {
  const d=input&&typeof input==='object'&&!Array.isArray(input)?input:{};
  const f=d.filters&&typeof d.filters==='object'?d.filters:{};
  const sc=d.scoring&&typeof d.scoring==='object'?d.scoring:{};
  const shared=sharedConfig||defaultConfig();
  const rules = Array.isArray(sc.rules) ? sc.rules : (shared.scoring?.rules || defaultScoreRules());
  return {
    schema:2,
    label:safeString(d.label||'',120),
    useClusterScoreVote:d.useClusterScoreVote===true,
    filters:{and:(Array.isArray(f.and)?f.and:(shared.filters?.and||[])).slice(0,100).map(r=>normalizeRule(r,false)),or:(Array.isArray(f.or)?f.or:(shared.filters?.or||[])).slice(0,100).map(r=>normalizeRule(r,false))},
    scoring:{baseScore:finiteInt(sc.baseScore,shared.scoring?.baseScore??0,-100,100),maxScore:finiteInt(sc.maxScore,shared.scoring?.maxScore??100,1,1000),spamThreshold:finiteInt(sc.spamThreshold,shared.scoring?.spamThreshold??25,0,1000),rules:rules.slice(0,500).map(normalizeScoreRule)}
  };
}
function getLocalIndividualScoring(sharedConfig) {
  const root=readLocalCustomRoot();
  const raw=root[LOCAL_SCORING_KEY];
  const configured=!!(raw&&typeof raw==='object'&&!Array.isArray(raw));
  const config=normalizeLocalScoring(configured?raw:{filters:sharedConfig?.filters||{},scoring:sharedConfig?.scoring||{}},sharedConfig);
  return {configured,config,storage:{path:'../custom.json',key:LOCAL_SCORING_KEY,scope:'node-local-seed',consensusState:false}};
}
function localScoringHash(local) { return sha256(JSON.stringify({filters:local.filters,scoring:local.scoring})); }
function expectedValidatorKeys(hpConfig,self) {
  const c=hpConfig&&hpConfig.contract&&typeof hpConfig.contract==='object'?hpConfig.contract:(hpConfig||{});
  const keys=(Array.isArray(c.unl)?c.unl:[]).map(publicKeyHex).filter(k=>/^ed[0-9a-f]{64}$/.test(k));
  if (/^ed[0-9a-f]{64}$/.test(self) && !keys.includes(self)) keys.push(self);
  return [...new Set(keys)].sort();
}

function normalizeConfig(input) {
  const c = input && typeof input === 'object' ? input : {};
  const fetch = c.fetch && typeof c.fetch === 'object' ? c.fetch : {};
  const fetchCfg = {
    pollEveryMinutes: finiteInt(fetch.pollEveryMinutes, 5, 1, 10080),
    lookbackMinutes: finiteInt(fetch.lookbackMinutes, 1440, 1, 525600),
    requestTimeoutMs: finiteInt(fetch.requestTimeoutMs, 8000, 1000, 30000),
    maxFeedBytes: finiteInt(fetch.maxFeedBytes, 2 * 1024 * 1024, 1024, 8 * 1024 * 1024),
    maxNplPayloadBytes: finiteInt(fetch.maxNplPayloadBytes, 120000, 8192, 124000),
    userAgent: safeString(fetch.userAgent || `Evernode-Spam-Oracle/${APP_VERSION}`, 200)
  };
  const filters = c.filters && typeof c.filters === 'object' ? c.filters : {};
  const scoring = c.scoring && typeof c.scoring === 'object' ? c.scoring : {};
  const limits = c.limits && typeof c.limits === 'object' ? c.limits : {};
  const rawSources = Array.isArray(c.sources) ? c.sources : [];
  const scoreRulesInput = legacyScoringRules(scoring, c.schema);
  const moderation = c.moderation && typeof c.moderation === 'object' ? c.moderation : {};
  const review = moderation.review && typeof moderation.review === 'object' ? moderation.review : {};
  const deleteBan = moderation.deleteBan && typeof moderation.deleteBan === 'object' ? moderation.deleteBan : {};
  const purgeUser = moderation.purgeUser && typeof moderation.purgeUser === 'object' ? moderation.purgeUser : {};
  const manager = moderation.manager && typeof moderation.manager === 'object' ? moderation.manager : {};
  const whitelist = moderation.whitelist && typeof moderation.whitelist === 'object' ? moderation.whitelist : {};
  return {
    schema: 7,
    fetch: fetchCfg,
    sources: rawSources.slice(0, 32).map((s, i) => normalizeSource(s, i, fetchCfg)),
    filters: {
      and: (Array.isArray(filters.and) ? filters.and : []).slice(0, 100).map(r => normalizeRule(r, false)),
      or: (Array.isArray(filters.or) ? filters.or : []).slice(0, 100).map(r => normalizeRule(r, false))
    },
    scoring: {
      baseScore: finiteInt(scoring.baseScore, 0, -100, 100),
      maxScore: finiteInt(scoring.maxScore, 100, 1, 1000),
      spamThreshold: finiteInt(scoring.spamThreshold, 25, 0, 1000),
      rules: scoreRulesInput.slice(0, 500).map(normalizeScoreRule)
    },
    moderation: {
      review: { enabled: review.enabled !== false, scoreAtLeast: finiteInt(review.scoreAtLeast, 25, 0, 1000), target: ['post','topic'].includes(safeString(review.target,16)) ? safeString(review.target,16) : 'post' },
      deleteBan: { enabled: deleteBan.enabled !== false, scoreAtLeast: finiteInt(deleteBan.scoreAtLeast, 80, 0, 1000), automatic: deleteBan.automatic === true, banMinutes: finiteInt(deleteBan.banMinutes, 0, 0, 525600) },
      purgeUser: { enabled: purgeUser.enabled !== false, scoreAtLeast: finiteInt(purgeUser.scoreAtLeast, 95, 0, 1000), automatic: purgeUser.automatic === true },
      manager: { heartbeatEveryLedgers: finiteInt(manager.heartbeatEveryLedgers, 3, 1, 1000), staleAfterLedgers: finiteInt(manager.staleAfterLedgers, 12, 2, 10000), resultWaitLedgers: finiteInt(manager.resultWaitLedgers, 8, 2, 10000), resultWaitSeconds: finiteInt(manager.resultWaitSeconds, 60, 10, 600), failoverGraceLedgers: finiteInt(manager.failoverGraceLedgers, 2, 0, 100) },
      whitelist: { users: normalizeWhitelistUsers(whitelist.users ?? moderation.whitelistUsers ?? []) }
    },
    limits: {
      maxPostsPerFetch: finiteInt(limits.maxPostsPerFetch, 500, 1, 2000),
      maxTextChars: finiteInt(limits.maxTextChars, 32000, 256, 200000),
      maxTrackedPosts: finiteInt(limits.maxTrackedPosts, 100000, 1000, 1000000),
      recentEvents: finiteInt(limits.recentEvents, 5000, 100, 50000)
    }
  };
}

function fieldValue(post, field) { return safeString(post[field], field === 'text' ? 200000 : 4096); }
function includesValue(haystack, needle, caseSensitive) {
  if (!caseSensitive) return haystack.toLowerCase().includes(needle.toLowerCase());
  return haystack.includes(needle);
}
function matchFilter(post, rule) {
  const found = includesValue(fieldValue(post, rule.field), rule.value, rule.caseSensitive);
  return rule.operator === 'contains' ? found : !found;
}
function passesFilters(post, config) {
  const andPass = config.filters.and.every(r => matchFilter(post, r));
  const orPass = config.filters.or.length === 0 || config.filters.or.some(r => matchFilter(post, r));
  return { pass: andPass && orPass, andPass, orPass };
}
function scorePost(post, config, eligible) {
  const maxScore = finiteInt(config?.scoring?.maxScore, 100, 1, 1000);
  if (!eligible) { const spamThreshold = finiteInt(config?.scoring?.spamThreshold, 25, 0, maxScore); return { score: 0, rawScore: 0, maxScore, spamThreshold, isSpam: false, reasons: [] }; }
  let score = config.scoring.baseScore;
  const reasons = [];
  if (config.scoring.baseScore !== 0) reasons.push({ kind: 'base', points: config.scoring.baseScore });

  for (const rule of config.scoring.rules || []) {
    const haystack = fieldValue(post, rule.field);
    let matched = false;
    if (rule.when === 'contains') {
      matched = includesValue(haystack, rule.value, rule.caseSensitive);
    } else if (rule.when === 'not_contains') {
      matched = !includesValue(haystack, rule.value, rule.caseSensitive);
    } else if (rule.when === 'contains_any') {
      matched = rule.values.some(value => includesValue(haystack, value, rule.caseSensitive));
    } else if (rule.when === 'contains_none') {
      matched = !rule.values.some(value => includesValue(haystack, value, rule.caseSensitive));
    }
    if (!matched) continue;
    score += rule.points;
    reasons.push({
      kind: rule.when,
      label: rule.label || '',
      field: rule.field,
      ...(rule.value ? { value: rule.value } : {}),
      ...(rule.values ? { values: rule.values } : {}),
      points: rule.points
    });
  }

  const rawScore = score;
  score = Math.max(0, Math.min(maxScore, score));
  const spamThreshold = finiteInt(config?.scoring?.spamThreshold, 25, 0, maxScore);
  const isSpam = score >= spamThreshold;
  return { score, rawScore, maxScore, spamThreshold, isSpam, reasons };
}

function scoringRulesHash(config) {
  return sha256(JSON.stringify({ filters: config.filters, scoring: config.scoring }));
}

function decodeXmlEntities(text) {
  const named = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
  return String(text || '').replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (_, entity) => {
    const e = entity.toLowerCase();
    if (e.startsWith('#x')) return String.fromCodePoint(parseInt(e.slice(2), 16));
    if (e.startsWith('#')) return String.fromCodePoint(parseInt(e.slice(1), 10));
    return named[e] || _;
  });
}
function unwrapCdata(value) {
  return String(value || '').replace(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/i, '$1');
}
function stripMarkup(value) {
  let s = unwrapCdata(value);
  s = decodeXmlEntities(s);
  s = s.replace(/<script\b[\s\S]*?<\/script>/gi, ' ')
       .replace(/<style\b[\s\S]*?<\/style>/gi, ' ')
       .replace(/<br\s*\/?\s*>/gi, '\n')
       .replace(/<\/p\s*>/gi, '\n')
       .replace(/<[^>]+>/g, ' ');
  s = decodeXmlEntities(s);
  return s.replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/\n[ \t]+/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function escapeRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
function elementInner(block, names) {
  for (const name of names) {
    const n = escapeRe(name);
    const re = new RegExp(`<${n}\\b[^>]*>([\\s\\S]*?)<\\/${n}>`, 'i');
    const m = String(block).match(re);
    if (m) return m[1];
  }
  return '';
}
function elementText(block, names) { return stripMarkup(elementInner(block, names)); }
function firstTagAttr(block, tagName, attrName) {
  const tag = escapeRe(tagName), attr = escapeRe(attrName);
  const re = new RegExp(`<${tag}\\b[^>]*\\b${attr}\\s*=\\s*(["'])(.*?)\\1[^>]*\\/?\s*>`, 'i');
  const m = String(block).match(re);
  return m ? decodeXmlEntities(m[2]) : '';
}
function parseDateMs(value) {
  const t = Date.parse(safeString(value, 200));
  return Number.isFinite(t) ? Math.trunc(t) : 0;
}
function extractQueryId(urlValue, key) {
  if (!urlValue) return '';
  try {
    const u = new URL(urlValue);
    const q = u.searchParams.get(key);
    if (q && /^\d+$/.test(q)) return q;
    if (key === 'p') {
      const m = u.hash.match(/^#p(\d+)$/i);
      if (m) return m[1];
    }
  } catch {}
  if (key === 'p') {
    const m = String(urlValue).match(/[?&]p=(\d+)|#p(\d+)/i);
    if (m) return m[1] || m[2] || '';
  }
  if (key === 'u') {
    const m = String(urlValue).match(/[?&]u=(\d+)/i);
    if (m) return m[1] || '';
  }
  return '';
}
function normalizeEntryId(rawId, link, sourceId) {
  const postId = extractQueryId(link, 'p');
  if (postId) return postId;
  const id = safeString(rawId, 1000);
  if (id) {
    const p = extractQueryId(id, 'p');
    if (p) return p;
    const trailing = id.match(/(?:post|p)[-/:#]?([0-9]{1,20})$/i);
    if (trailing) return trailing[1];
    return `entry-${sha256(id).slice(0, 24)}`;
  }
  return `entry-${sha256(`${sourceId}\n${link}`).slice(0, 24)}`;
}
function parseAtom(xml, source, config) {
  const entries = String(xml).match(/<entry\b[\s\S]*?<\/entry>/gi) || [];
  const posts = [];
  for (const entry of entries.slice(0, config.limits.maxPostsPerFetch)) {
    const link = firstTagAttr(entry, 'link', 'href') || elementText(entry, ['link']);
    const authorBlock = elementInner(entry, ['author']);
    const username = elementText(authorBlock, ['name']) || elementText(entry, ['dc:creator', 'author']) || 'unknown';
    const authorUri = elementText(authorBlock, ['uri']);
    const userId = extractQueryId(authorUri, 'u');
    const rawId = elementText(entry, ['id', 'guid']);
    const postId = normalizeEntryId(rawId, link, source.id);
    const title = elementText(entry, ['title']);
    const contentRaw = elementInner(entry, ['content']) || elementInner(entry, ['summary']);
    const text = safeString(stripMarkup(contentRaw), config.limits.maxTextChars);
    const postedMs = parseDateMs(elementText(entry, ['published', 'updated']));
    const topicId = extractQueryId(link, 't');
    const forumId = extractQueryId(link, 'f');
    posts.push({
      source: source.id,
      sourceUrl: source.url,
      postId,
      userId,
      username,
      text,
      topicId,
      forumId,
      topicTitle: title,
      postedAtUnix: postedMs > 0 ? Math.floor(postedMs / 1000) : 0,
      link
    });
  }
  return posts;
}
function parseRss(xml, source, config) {
  const items = String(xml).match(/<item\b[\s\S]*?<\/item>/gi) || [];
  const posts = [];
  for (const item of items.slice(0, config.limits.maxPostsPerFetch)) {
    const link = elementText(item, ['link']);
    const rawId = elementText(item, ['guid', 'id']);
    const postId = normalizeEntryId(rawId, link, source.id);
    const username = elementText(item, ['dc:creator', 'author']) || 'unknown';
    const authorUri = elementText(item, ['author_uri', 'dc:author_uri']);
    const userId = extractQueryId(authorUri, 'u');
    const title = elementText(item, ['title']);
    const contentRaw = elementInner(item, ['content:encoded', 'description', 'content']);
    const text = safeString(stripMarkup(contentRaw), config.limits.maxTextChars);
    const postedMs = parseDateMs(elementText(item, ['pubDate', 'published', 'date', 'dc:date']));
    posts.push({
      source: source.id,
      sourceUrl: source.url,
      postId,
      userId,
      username,
      text,
      topicId: extractQueryId(link, 't'),
      forumId: extractQueryId(link, 'f'),
      topicTitle: title,
      postedAtUnix: postedMs > 0 ? Math.floor(postedMs / 1000) : 0,
      link
    });
  }
  return posts;
}
function parseFeed(xml, source, config) {
  const format = source.format === 'auto'
    ? (/<feed\b/i.test(xml) && /<entry\b/i.test(xml) ? 'atom' : (/<rss\b/i.test(xml) || /<item\b/i.test(xml) ? 'rss' : 'unknown'))
    : source.format;
  if (format === 'atom') return { format, posts: parseAtom(xml, source, config) };
  if (format === 'rss') return { format, posts: parseRss(xml, source, config) };
  throw new Error('Could not detect Atom or RSS feed format.');
}

function requestFeed(urlValue, options, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 4) return reject(new Error('Too many feed redirects.'));
    let url;
    try { url = new URL(urlValue); } catch { return reject(new Error('Invalid feed URL.')); }
    const transport = url.protocol === 'https:' ? https : http;
    const req = transport.request(url, {
      method: 'GET',
      headers: {
        'user-agent': options.userAgent,
        'accept': 'application/atom+xml, application/rss+xml, application/xml, text/xml;q=0.9, */*;q=0.1',
        'accept-encoding': 'identity',
        'connection': 'close'
      }
    }, res => {
      const status = Number(res.statusCode || 0);
      if ([301, 302, 303, 307, 308].includes(status) && res.headers.location) {
        res.resume();
        const next = new URL(res.headers.location, url).toString();
        return resolve(requestFeed(next, options, redirects + 1));
      }
      if (status < 200 || status >= 300) {
        res.resume();
        return reject(new Error(`Feed HTTP status ${status}.`));
      }
      const chunks = [];
      let bytes = 0;
      res.on('data', chunk => {
        bytes += chunk.length;
        if (bytes > options.maxFeedBytes) {
          req.destroy(new Error(`Feed exceeds ${options.maxFeedBytes} bytes.`));
          return;
        }
        chunks.push(chunk);
      });
      res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    });
    req.setTimeout(options.requestTimeoutMs, () => req.destroy(new Error('Feed request timed out.')));
    req.on('error', reject);
    req.end();
  });
}
function nplEnvelope(source, xml, ctx, config) {
  const compressed = zlib.gzipSync(Buffer.from(xml, 'utf8'), { level: 9 });
  const payload = {
    kind: 'spam-feed-v2',
    ledger: ledgerNo(ctx),
    sourceId: source.id,
    sourceUrl: source.url,
    fetchTimestampMs: ledgerTimeMs(ctx),
    encoding: 'gzip-base64',
    sha256: sha256(xml),
    body: compressed.toString('base64')
  };
  const encoded = Buffer.from(JSON.stringify(payload));
  if (encoded.length > config.fetch.maxNplPayloadBytes) {
    throw new Error(`Compressed feed NPL payload is ${encoded.length} bytes; max is ${config.fetch.maxNplPayloadBytes}.`);
  }
  return payload;
}
function decodeNplEnvelope(payload, source, ctx) {
  if (!payload || payload.kind !== 'spam-feed-v2') throw new Error('Invalid feed NPL envelope.');
  if (Number(payload.ledger) !== Number(ledgerNo(ctx))) throw new Error('Feed NPL envelope belongs to another ledger.');
  if (payload.sourceId !== source.id || payload.sourceUrl !== source.url) throw new Error('Feed NPL source mismatch.');
  if (payload.encoding !== 'gzip-base64') throw new Error('Unsupported feed NPL encoding.');
  const xml = zlib.gunzipSync(Buffer.from(String(payload.body || ''), 'base64')).toString('utf8');
  if (sha256(xml) !== payload.sha256) throw new Error('Feed NPL payload hash mismatch.');
  return xml;
}
function leaderKey(ctx) {
  const keys = ctx.unl.list().map(n => publicKeyHex(n.publicKey)).filter(k => /^ed[0-9a-f]{64}$/.test(k));
  const self = publicKeyHex(ctx.publicKey);
  if (/^ed[0-9a-f]{64}$/.test(self) && !keys.includes(self)) keys.push(self);
  keys.sort();
  return keys[0] || self;
}
function createFeedNplInbox(ctx) {
  const queued = new Map();
  const waiters = new Map();
  const currentLedger = Number(ledgerNo(ctx));
  ctx.unl.onMessage((node, msg) => {
    try {
      const payload = JSON.parse(Buffer.from(msg).toString('utf8'));
      if (!payload || !['spam-feed-v2', 'spam-feed-error-v2'].includes(payload.kind)) return;
      if (Number(payload.ledger) !== currentLedger) return;
      const sourceId = safeString(payload.sourceId, 80);
      if (!sourceId) return;
      const waiter = waiters.get(sourceId);
      if (waiter) {
        waiters.delete(sourceId);
        clearTimeout(waiter.timer);
        waiter.resolve(payload);
      } else {
        queued.set(sourceId, payload);
      }
    } catch {}
  });
  return {
    wait(sourceId, timeoutMs) {
      if (queued.has(sourceId)) {
        const payload = queued.get(sourceId);
        queued.delete(sourceId);
        return Promise.resolve(payload);
      }
      return new Promise(resolve => {
        const timer = setTimeout(() => {
          const current = waiters.get(sourceId);
          if (current && current.timer === timer) waiters.delete(sourceId);
          resolve(null);
        }, timeoutMs);
        waiters.set(sourceId, { resolve, timer });
      });
    }
  };
}

function normalizePost(raw, config, sourceDefault) {
  if (!raw || typeof raw !== 'object') throw new Error('Post must be an object.');
  const source = safeString(raw.source || sourceDefault || 'feed', 80) || 'feed';
  const postId = safeString(raw.postId ?? raw.id, 100);
  if (!postId) throw new Error('Post id is required.');
  return {
    source,
    sourceUrl: safeString(raw.sourceUrl, 2048),
    postId,
    userId: safeString(raw.userId ?? raw.posterId ?? '', 100),
    username: safeString(raw.username || raw.user || raw.author || 'unknown', 255) || 'unknown',
    text: safeString(raw.text ?? raw.postText ?? raw.content ?? '', config.limits.maxTextChars),
    topicId: safeString(raw.topicId ?? '', 100),
    forumId: safeString(raw.forumId ?? '', 100),
    topicTitle: safeString(raw.topicTitle ?? '', 1000),
    postedAtUnix: finiteInt(raw.postedAtUnix ?? raw.postTime ?? 0, 0, 0, 4102444800),
    link: safeString(raw.link ?? '', 2048)
  };
}
function postHash(post) { return sha256(JSON.stringify(post)); }
function userKeyForPost(post) { return `${post.source}:${post.userId || post.username.toLowerCase()}`; }
function requireAdmin(state, userKey) { if (!state.admins.includes(userKey)) throw new Error('Admin authorization required.'); }
function requireFeeder(state, userKey) { if (!state.feeders.includes(userKey) && !state.admins.includes(userKey)) throw new Error('Feeder authorization required.'); }
function appendEvent(state, event, config) {
  fs.appendFileSync(EVENT_FILE, JSON.stringify(event) + '\n');
  state.recentEvents.push(event);
  if (state.recentEvents.length > config.limits.recentEvents) state.recentEvents.splice(0, state.recentEvents.length - config.limits.recentEvents);
}
function pruneTrackedPosts(state, maxTracked) {
  const keys = Object.keys(state.posts);
  if (keys.length <= maxTracked) return;
  keys.sort((a, b) => finiteInt((state.posts[a] || {}).lastLedger, 0, 0, Number.MAX_SAFE_INTEGER) - finiteInt((state.posts[b] || {}).lastLedger, 0, 0, Number.MAX_SAFE_INTEGER) || a.localeCompare(b));
  for (const k of keys.slice(0, keys.length - maxTracked)) delete state.posts[k];
}
function processPosts(posts, source, ctx, state, config, lookbackMinutes) {
  const ln = ledgerNo(ctx), ts = ledgerTimeMs(ctx);
  const cutoffUnix = ts ? Math.floor((ts - lookbackMinutes * 60000) / 1000) : 0;
  const result = { received: posts.length, newPosts: 0, duplicates: 0, rescored: 0, filtered: 0, scored: 0, tooOld: 0, events: [] };
  for (const raw of posts.slice(0, config.limits.maxPostsPerFetch)) {
    const post = normalizePost(raw, config, source.id);
    if (cutoffUnix > 0 && post.postedAtUnix > 0 && post.postedAtUnix < cutoffUnix) {
      result.tooOld++; state.totals.tooOld++; continue;
    }
    if (cutoffUnix > 0 && post.postedAtUnix === 0) {
      result.tooOld++; state.totals.tooOld++; continue;
    }
    const key = `${post.source}:${post.postId}`;
    const hash = postHash(post);
    const previous = state.posts[key] || null;
    const rulesHash = scoringRulesHash(config);
    if (previous && previous.contentHash === hash && previous.rulesHash === rulesHash) { refreshPostClusterScore(previous,state.clusterScoring?.expectedVoters||[],state.clusterScoring?.clusterModeActive===true); previous.whitelisted=isWhitelistedIdentity(previous,config); if (previous.eligible !== false) updateModerationCase(state, previous, moderationScoreView(previous), true, config, ctx); result.duplicates++; state.totals.duplicates++; continue; }
    const filterResult = passesFilters(post, config);
    const scored = scorePost(post, config, filterResult.pass);
    const userKey = userKeyForPost(post);
    const oldUserKey = previous ? previous.userKey : null;
    const oldScore = previous ? finiteInt(previous.score, 0, -100000000, 100000000) : 0;
    if (previous && oldUserKey && oldUserKey !== userKey && state.users[oldUserKey]) state.users[oldUserKey].score = finiteInt(state.users[oldUserKey].score, 0, -1000000000, 1000000000) - oldScore;
    const u = state.users[userKey] || { source: post.source, userId: post.userId, username: post.username, score: 0, scoredPosts: 0, lastPostId: null, lastLedger: null };
    if (!previous || oldUserKey !== userKey) u.scoredPosts = finiteInt(u.scoredPosts, 0, 0, 100000000) + 1;
    const delta = previous && oldUserKey === userKey ? scored.score - oldScore : scored.score;
    u.score = finiteInt(u.score, 0, -1000000000, 1000000000) + delta;
    u.username = post.username; u.userId = post.userId; u.lastPostId = post.postId; u.lastLedger = ln;
    state.users[userKey] = u;
    state.posts[key] = { ...post, userKey, score: scored.score, rawScore: scored.rawScore, stateScore: scored.score, stateRawScore: scored.rawScore, stateReasons: scored.reasons, stateIsSpam: scored.isSpam, maxScore: scored.maxScore, spamThreshold: scored.spamThreshold, isSpam: scored.isSpam, eligible: filterResult.pass, reasons: scored.reasons, contentHash: hash, rulesHash, clusterVotes:(previous&&previous.contentHash===hash&&previous.clusterVotes&&typeof previous.clusterVotes==='object')?previous.clusterVotes:{}, firstLedger: previous ? previous.firstLedger : ln, lastLedger: ln, whitelisted:isWhitelistedIdentity(post,config) }; refreshPostClusterScore(state.posts[key],state.clusterScoring?.expectedVoters||[],state.clusterScoring?.clusterModeActive===true);
    const event = {
      schema: 2,
      ledger: ln,
      ledgerTimeMs: ts,
      type: previous ? 'post-rescored' : 'post-scored',
      source: post.source,
      sourceUrl: post.sourceUrl,
      postId: post.postId,
      userId: post.userId,
      username: post.username,
      postedAtUnix: post.postedAtUnix,
      forumId: post.forumId,
      topicId: post.topicId,
      topicTitle: post.topicTitle,
      link: post.link,
      text: post.text,
      eligible: filterResult.pass,
      score: scored.score,
      rawScore: scored.rawScore,
      maxScore: scored.maxScore,
      spamThreshold: scored.spamThreshold,
      isSpam: scored.isSpam,
      delta,
      userTotalScore: u.score,
      reasons: scored.reasons,
      contentHash: hash
    };
    appendEvent(state, event, config);
    updateModerationCase(state, state.posts[key], moderationScoreView(state.posts[key]), filterResult.pass, config, ctx);
    result.events.push({ postId: post.postId, username: post.username, score: scored.score, maxScore: scored.maxScore, spamThreshold: scored.spamThreshold, isSpam: scored.isSpam, delta, total: u.score, eligible: filterResult.pass });
    state.totals.postsSeen++;
    if (previous) { result.rescored++; state.totals.rescored++; } else result.newPosts++;
    if (!filterResult.pass) { result.filtered++; state.totals.filtered++; } else { result.scored++; state.totals.scored++; if (scored.isSpam) state.totals.spamTargeted++; }
  }
  state.lastLedger = ln;
  pruneTrackedPosts(state, config.limits.maxTrackedPosts);
  return result;
}

async function fetchBudget(ctx, config) {
  let roundtime = 4000;
  try {
    const hp = await ctx.getConfig();
    const n = Number(hp && hp.contract && hp.contract.consensus && hp.contract.consensus.roundtime);
    if (Number.isFinite(n) && n >= 1000) roundtime = Math.trunc(n);
  } catch {}
  // NPL timeouts should fit inside the current consensus execution. Keep a
  // healthy margin for HotPocket to finish the invocation and consensus work.
  const totalBudgetMs = Math.max(1000, Math.min(12000, Math.floor(roundtime * 0.72)));
  const requestTimeoutMs = Math.max(750, Math.min(config.fetch.requestTimeoutMs, totalBudgetMs - 350));
  const peerWaitMs = Math.max(900, Math.min(totalBudgetMs, requestTimeoutMs + 300));
  return { roundtime, totalBudgetMs, requestTimeoutMs, peerWaitMs };
}
function isFetchDue(ctx) {
  if (!ctx || ctx.readonly) return false;
  const now = ledgerTimeMs(ctx);
  if (!now) return false;
  const state = loadState(), config = loadConfig();
  return config.sources.some(source => {
    if (!source.enabled) return false;
    const status = state.sourceStatus[source.id] || {};
    const lastAttempt = finiteInt(status.lastAttemptAtMs, 0, 0, Number.MAX_SAFE_INTEGER);
    return !(lastAttempt > 0 && now - lastAttempt < source.pollEveryMinutes * 60000);
  });
}
async function fetchDueSources(ctx, state, config) {
  if (ctx.readonly || config.sources.length === 0) return;
  const now = ledgerTimeMs(ctx);
  if (!now) return;
  const leader = leaderKey(ctx);
  const self = publicKeyHex(ctx.publicKey);
  const budget = await fetchBudget(ctx, config);
  // The elected leader does not need to receive its own NPL broadcast. Peers
  // register one NPL inbox for this invocation and wait for the leader payload.
  const inbox = self === leader ? null : createFeedNplInbox(ctx);

  for (const source of config.sources) {
    if (!source.enabled) continue;
    const status = state.sourceStatus[source.id] || {};
    const lastAttempt = finiteInt(status.lastAttemptAtMs, 0, 0, Number.MAX_SAFE_INTEGER);
    if (lastAttempt > 0 && now - lastAttempt < source.pollEveryMinutes * 60000) continue;

    let payload = null;
    if (self === leader) {
      try {
        const xml = await requestFeed(source.url, { ...config.fetch, requestTimeoutMs: budget.requestTimeoutMs });
        payload = nplEnvelope(source, xml, ctx, config);
        await ctx.unl.send(JSON.stringify(payload));
      } catch (err) {
        payload = {
          kind: 'spam-feed-error-v2',
          ledger: ledgerNo(ctx),
          sourceId: source.id,
          sourceUrl: source.url,
          fetchTimestampMs: now,
          error: safeString(err && err.message || err, 500)
        };
        try { await ctx.unl.send(JSON.stringify(payload)); } catch {}
      }
    } else {
      payload = await inbox.wait(source.id, budget.peerWaitMs);
    }

    const nextStatus = state.sourceStatus[source.id] || {};
    nextStatus.url = source.url;
    nextStatus.lastAttemptAtMs = now;
    nextStatus.lastLedger = ledgerNo(ctx);
    nextStatus.lastFetchLeader = leader;
    nextStatus.roundtimeMs = budget.roundtime;
    nextStatus.fetchBudgetMs = budget.totalBudgetMs;
    state.totals.fetchAttempts++;

    if (!payload) {
      nextStatus.lastError = `No feed result arrived within ${budget.peerWaitMs} ms.`;
      nextStatus.lastErrorAtMs = now;
      state.totals.fetchErrors++;
      state.sourceStatus[source.id] = nextStatus;
      continue;
    }

    if (payload.kind === 'spam-feed-error-v2') {
      nextStatus.lastError = safeString(payload.error, 500);
      nextStatus.lastErrorAtMs = now;
      state.totals.fetchErrors++;
      state.sourceStatus[source.id] = nextStatus;
      continue;
    }

    try {
      const xml = decodeNplEnvelope(payload, source, ctx);
      const parsed = parseFeed(xml, source, config);
      const result = processPosts(parsed.posts, source, ctx, state, config, source.lookbackMinutes);
      const preview = parsed.posts.slice(0, 30).map(post => ({
        postId: post.postId,
        userId: post.userId,
        username: post.username,
        postedAtUnix: post.postedAtUnix,
        topicTitle: post.topicTitle,
        link: post.link,
        text: safeString(post.text, 1200)
      }));
      state.feedPreview[source.id] = preview;
      nextStatus.lastSuccessAtMs = now;
      nextStatus.lastError = '';
      nextStatus.lastFormat = parsed.format;
      nextStatus.lastFeedHash = payload.sha256;
      nextStatus.lastEntries = parsed.posts.length;
      nextStatus.lastNewPosts = result.newPosts;
      nextStatus.lastDuplicates = result.duplicates;
      nextStatus.lastTooOld = result.tooOld;
      nextStatus.lastWithinLookback = Math.max(0, parsed.posts.length - result.tooOld);
      nextStatus.latestEntryAtUnix = preview.reduce((m,p)=>Math.max(m, finiteInt(p.postedAtUnix,0,0,Number.MAX_SAFE_INTEGER)),0);
      state.totals.fetchSuccesses++;
      state.sourceStatus[source.id] = nextStatus;
      console.log(`[${APP_NAME}] ${source.id}: ${parsed.posts.length} feed entries, ${result.newPosts} new, ${result.duplicates} duplicate, ${result.tooOld} outside lookback.`);
    } catch (err) {
      nextStatus.lastError = safeString(err && err.message || err, 500);
      nextStatus.lastErrorAtMs = now;
      state.totals.fetchErrors++;
      state.sourceStatus[source.id] = nextStatus;
    }
  }

  state.lastLedger = ledgerNo(ctx);
  writeJson(STATE_FILE, state);
}


function moderationCaseId(post) { return sha256(`${post.source}:${post.postId}`).slice(0, 24); }
function moderationActionId(caseId, type, contentHash='') { return sha256(`${caseId}:${type}:${contentHash}`).slice(0, 32); }
function actionEvent(a, event, reason, ledger, executor='', extra=null) {
  if (!a || typeof a !== 'object') return;
  const item = {
    event: safeString(event, 64),
    reason: safeString(reason, 1000),
    ledger: finiteInt(ledger, 0, 0, Number.MAX_SAFE_INTEGER),
    executor: safeString(executor, 160)
  };
  if (extra && typeof extra === 'object') {
    for (const [k,v] of Object.entries(extra)) {
      if (['event','reason','ledger','executor'].includes(k)) continue;
      if (typeof v === 'string') item[k] = safeString(v, 1000);
      else if (typeof v === 'number' || typeof v === 'boolean' || v === null) item[k] = v;
    }
  }
  a.history = Array.isArray(a.history) ? a.history : [];
  a.history.push(item);
  if (a.history.length > 30) a.history = a.history.slice(-30);
  a.lastTransition = item;
}
function ensureActionMeta(a) {
  if (!a || typeof a !== 'object') return a;
  const legacyAttempts = finiteInt(a.attempts, 0, 0, 1000000);
  a.failedExecutors = Array.isArray(a.failedExecutors) ? [...new Set(a.failedExecutors.map(x=>safeString(x,160)).filter(Boolean))] : [];
  const legacyHadExecutorFailure = a.status === 'pending' && a.failedExecutors.length > 0;
  a.assignments = finiteInt(a.assignments, (a.status==='assigned'||legacyHadExecutorFailure)?1:0, 0, 1000000);
  a.assignmentSeq = finiteInt(a.assignmentSeq, a.assignments, 0, 1000000);
  a.workerFailures = finiteInt(a.workerFailures, legacyAttempts, 0, 1000000);
  a.timeouts = finiteInt(a.timeouts, legacyHadExecutorFailure && legacyAttempts===0 ? 1 : 0, 0, 1000000);
  a.history = Array.isArray(a.history) ? a.history.slice(-40) : [];
  a.lastExecutor = safeString(a.lastExecutor || a.executor || a.failedExecutors[a.failedExecutors.length-1] || '', 160) || null;
  a.targetExecutor = safeString(a.targetExecutor || '', 160) || null;
  a.nonDestructive = a.nonDestructive === true || a.type === 'test_forum_manager';
  a.lastResult = a.lastResult ? sanitizeWorkerResult(a.lastResult) : null;
  a.workerDiagnostic = a.workerDiagnostic ? sanitizeWorkerDiagnostic(a.workerDiagnostic) : null;
  a.lastDiagnosticStage = safeString(a.lastDiagnosticStage || a.workerDiagnostic?.stage || '', 80);
  a.lastDiagnosticUpdatedAt = finiteInt(a.lastDiagnosticUpdatedAt || a.workerDiagnostic?.updatedAt, 0, 0, Number.MAX_SAFE_INTEGER);
  a.assignedAtMs = finiteInt(a.assignedAtMs, 0, 0, Number.MAX_SAFE_INTEGER);
  a.lastProgressLedger = finiteInt(a.lastProgressLedger, a.assignedLedger || 0, 0, Number.MAX_SAFE_INTEGER);
  a.lastProgressAtMs = finiteInt(a.lastProgressAtMs, a.assignedAtMs || 0, 0, Number.MAX_SAFE_INTEGER);
  a.failoverNotBeforeLedger = finiteInt(a.failoverNotBeforeLedger, 0, 0, Number.MAX_SAFE_INTEGER);
  a.handledResultSeq = finiteInt(a.handledResultSeq, 0, 0, 1000000);
  if (!a.lastTransition) {
    const ledger = finiteInt(a.updatedLedger || a.createdLedger, 0, 0, Number.MAX_SAFE_INTEGER);
    let event = a.status === 'completed' ? 'completed' : a.status === 'failed' ? 'worker_failed' : a.status === 'assigned' ? 'assigned' : legacyHadExecutorFailure && legacyAttempts>0 ? 'worker_failed' : legacyHadExecutorFailure ? 'result_timeout' : 'queued';
    let reason = a.status === 'completed' ? 'Action completed before diagnostics history was introduced.' : a.status === 'failed' ? 'Action failed before diagnostics history was introduced.' : a.status === 'assigned' ? 'Action was assigned before diagnostics history was introduced.' : event==='worker_failed' ? 'Legacy action returned after a manager worker failure.' : event==='result_timeout' ? 'Legacy action returned to pending after an assigned manager produced no accepted result; treated as a timeout for diagnostics.' : 'Action is waiting for an eligible Forum Manager.';
    a.lastTransition = {event, reason, ledger, executor:safeString(a.executor||a.lastExecutor||'',160)};
  }
  return a;
}
function actionManagerSet(state, config, rawAction) {
  const a = ensureActionMeta(rawAction);
  const currentLedger = Math.max(finiteInt(state.lastLedger,0,0,Number.MAX_SAFE_INTEGER), finiteInt(state.moderationRuntime?.lastHeartbeatLedger,0,0,Number.MAX_SAFE_INTEGER));
  const managers = Object.values(state.managerRegistry||{}).filter(m=>m&&m.enabled!==false&&currentLedger-finiteInt(m.lastSeenLedger,0,0,currentLedger)<=config.moderation.manager.staleAfterLedgers).sort((x,y)=>finiteInt(x.priority,999999,1,999999)-finiteInt(y.priority,999999,1,999999)||String(x.publicKey).localeCompare(String(y.publicKey)));
  const eligible = managers.filter(m=>!(a.failedExecutors||[]).includes(m.publicKey) && (!a.targetExecutor || m.publicKey===a.targetExecutor));
  return {currentLedger, managers, eligible};
}
function actionDiagnostic(state, config, raw) {
  const a = ensureActionMeta({...raw, history:Array.isArray(raw?.history)?raw.history.map(x=>({...x})):[]});
  const {currentLedger, managers, eligible} = actionManagerSet(state, config, a);
  const wait = config.moderation.manager.resultWaitLedgers;
  const waitSeconds = config.moderation.manager.resultWaitSeconds;
  const progressLedger = finiteInt(a.lastProgressLedger || a.assignedLedger, currentLedger, 0, currentLedger);
  const elapsed = a.status==='assigned' ? Math.max(0,currentLedger-progressLedger) : 0;
  const remaining = a.status==='assigned' ? Math.max(0,wait-elapsed) : null;
  const lastEvent = safeString(a.lastTransition?.event,64);
  const isTest = a.type === 'test_forum_manager';
  let label=isTest?'WAITING TO TEST THIS MANAGER':'WAITING FOR MANAGER', explanation=isTest?'The non-destructive manager test is queued. No phpBB content will be changed.':'The action is queued. No phpBB mutation is currently confirmed.', nextStep=isTest?'ForumGuard will run the test when the selected validator advertises an active Forum Manager heartbeat.':'ForumGuard will assign the lowest-priority eligible manager automatically.', severity='info';
  if (a.status==='assigned') {
    label=isTest?'TEST RUNNING':'RUNNING / AWAITING RESULT'; severity='warn';
    const stage=a.workerDiagnostic?.stage, step=a.workerDiagnostic?.step;
    explanation=isTest?`Selected manager ${safeString(a.executor||'',160)||'unknown'} is running a non-destructive phpBB access test.`:`Manager ${safeString(a.executor||'',160) || 'unknown'} has been assigned. The worker may currently be changing phpBB. ForumGuard is waiting for its result.`;
    if(stage) explanation += ` Worker: ${stage}${step?` (${step})`:''}.`;
    nextStep=`Wait for the worker result. ForumGuard now waits for BOTH ${wait} idle ledgers and at least ${waitSeconds}s without worker progress; about ${remaining} idle ledger(s) remain.`;
  } else if (a.status==='completed') {
    label=isTest?'TEST PASSED':(lastEvent==='late_completed'?'COMPLETED · LATE RESULT RECONCILED':'COMPLETED'); severity='good'; explanation=isTest?'Credentials, phpBB login, Moderator Control Panel access and ACP access all passed without changing forum content.':(lastEvent==='late_completed'?'The worker finished after the previous timeout, but ForumGuard reconciled the late success before a retry/failover could repeat the destructive operation.':'ForumGuard received a successful result from the assigned manager.'); nextStep=isTest?'This validator is ready to execute ForumGuard moderation.':'No retry is required.';
  } else if (a.status==='failed' && isTest) {
    label=lastEvent==='result_timeout'?'TEST TIMED OUT':'TEST FAILED'; severity='bad'; explanation=lastEvent==='result_timeout'?'The selected manager did not return a test result inside the configured ledger window. No destructive action was requested.':'The non-destructive Forum Manager test returned an error.'; nextStep='Fix the reported credential/path/permission/worker error, then run Test Forum Manager again.';
  } else if (a.status==='pending' && lastEvent==='worker_failed') {
    label='FAILED → WAITING FOR FAILOVER'; severity='bad'; explanation='The worker returned an explicit error. That executor is excluded from this action until a manual retry clears the exclusion list.';
    nextStep=eligible.length ? `${eligible.length} other eligible manager(s) remain and can be assigned automatically.` : 'No eligible manager remains. Check phpBB for partial changes, fix the cause, then use Retry / clear exclusions.';
  } else if (a.status==='pending' && lastEvent==='result_timeout') {
    label='TIMED OUT → WAITING FOR FAILOVER'; severity='bad'; explanation='No worker result arrived inside the configured ledger window. The phpBB operation may have failed, still be running, or partially completed.';
    nextStep=eligible.length ? `${eligible.length} other eligible manager(s) remain. Check phpBB before failover/retry if duplicate destructive work would be dangerous.` : 'No eligible manager remains. Check phpBB first, then use Retry / clear exclusions only when safe.';
  } else if (a.status==='pending' && lastEvent==='manual_retry') {
    label='RETRY QUEUED'; severity='warn'; explanation='A head admin cleared failed-executor exclusions and requested another attempt.'; nextStep='ForumGuard will elect an eligible manager again.';
  }
  return {...a, diagnostic:{label,severity,explanation,nextStep,currentLedger,resultWaitLedgers:wait,resultWaitSeconds:waitSeconds,ledgersWaiting:elapsed,ledgersRemaining:remaining,managerCount:managers.length,eligibleManagerCount:eligible.length,destructiveMayHavePartiallyRun:!isTest&&(a.workerFailures>0||a.timeouts>0)&&a.status!=='completed'}};
}
function queueModerationAction(state, c, type, config, automatic=false) {
  if (isWhitelistedIdentity(c,config)) throw new Error('This user is protected by the ForumGuard whitelist. No destructive action will be queued.');
  const actionId = moderationActionId(c.caseId, type, c.contentHash || '');
  const existing = state.moderationActions[actionId];
  if (existing && !['failed','cancelled'].includes(existing.status)) {
    const a=ensureActionMeta(existing);
    c.actionId=a.actionId; c.actionStatus=a.status; c.status=a.status==='completed'?'action_completed':'action_pending'; c.executor=a.executor||null;
    return a;
  }
  const ln=finiteInt(c.lastLedger,0,0,Number.MAX_SAFE_INTEGER);
  const a = { schema:2, actionId, caseId:c.caseId, type, source:c.source, postId:c.postId, topicId:c.topicId, userId:c.userId, username:c.username, link:c.link, score:c.score, maxScore:c.maxScore, automatic:!!automatic, banMinutes: config.moderation.deleteBan.banMinutes, status:'pending', executor:null, lastExecutor:null, attempts:0, assignments:0, assignmentSeq:0, workerFailures:0, timeouts:0, failedExecutors:[], history:[], createdLedger:ln, updatedLedger:ln };
  actionEvent(a,'queued','Action queued; waiting for an eligible Forum Manager.',ln,'');
  state.moderationActions[actionId]=a; state.totals.moderationQueued++;
  c.actionId=actionId; c.actionStatus='pending'; c.status='action_pending'; c.executor=null;
  return a;
}
function queueForumManagerTest(input, ctx) {
  ensureFiles();
  const state=loadState(), config=loadConfig(), ln=finiteInt(ledgerNo(ctx),0,0,Number.MAX_SAFE_INTEGER);
  const target=safeString(input&&input.targetPublicKey,160);
  if(!/^ed[0-9a-f]{64}$/.test(target)) throw new Error('A valid target validator public key is required for Forum Manager test.');
  const requestId=safeString(input&&input.requestId,80) || sha256(`${target}:${ln}`).slice(0,24);
  const actionId=sha256(`forum-manager-test:${target}:${requestId}`).slice(0,32);
  let a=state.moderationActions[actionId];
  if(!a){
    a={schema:3,actionId,caseId:null,type:'test_forum_manager',source:'forum-manager-test',postId:'',topicId:'',userId:'',username:'',link:'',score:0,maxScore:100,automatic:false,banMinutes:0,status:'pending',executor:null,lastExecutor:null,targetExecutor:target,nonDestructive:true,attempts:0,assignments:0,assignmentSeq:0,workerFailures:0,timeouts:0,failedExecutors:[],history:[],createdLedger:ln,updatedLedger:ln};
    actionEvent(a,'queued','Non-destructive Forum Manager test queued for the selected validator.',ln,target);
    state.moderationActions[actionId]=a; state.totals.managerTestsQueued=finiteInt(state.totals.managerTestsQueued,0,0,100000000)+1;
    const tests=Object.values(state.moderationActions).filter(x=>x&&x.type==='test_forum_manager').sort((x,y)=>finiteInt(y.createdLedger,0)-finiteInt(x.createdLedger,0));
    for(const old of tests.slice(60)) delete state.moderationActions[old.actionId];
  }
  writeJson(STATE_FILE,state);
  return {actionId, spam:snapshot({leaderboardLimit:200,eventLimit:200})};
}
function updateModerationCase(state, post, scored, eligible, config, ctx) {
  const caseId=moderationCaseId(post), ln=ledgerNo(ctx), contentHash=post.contentHash || postHash(post);
  const protectedUser=isWhitelistedIdentity(post,config);
  const prior=state.moderationCases[caseId]||{};
  if(protectedUser){
    // Whitelisting protects the identity from destructive moderation, but it does
    // not need to flood the review queue with low-scoring safe posts. Keep/update
    // a case only when one already exists or the post would otherwise be reviewable.
    const reviewable = eligible && config.moderation.review.enabled && Number(scored.score||0) >= config.moderation.review.scoreAtLeast;
    if(!prior.caseId && !reviewable) return null;
    const c={...prior,schema:2,caseId,source:post.source,postId:post.postId,topicId:post.topicId,forumId:post.forumId,userId:post.userId,username:post.username,link:post.link,topicTitle:post.topicTitle,text:safeString(post.text,4000),score:Number(scored.score||0),stateScore:Number(scored.stateScore??post.stateScore??post.score??0),clusterScore:scored.clusterScore??post.clusterScore??null,clusterVoteCount:Number(scored.clusterVoteCount??post.clusterVoteCount??0),clusterExpectedCount:Number(scored.clusterExpectedCount??post.clusterExpectedCount??0),clusterComplete:scored.clusterComplete===true||post.clusterComplete===true,maxScore:scored.maxScore,reasons:scored.reasons,reviewTarget:config.moderation.review.target,contentHash,firstLedger:prior.firstLedger||ln,lastLedger:ln,status:'whitelisted',whitelisted:true}; state.moderationCases[caseId]=c; return c;
  }
  if (!eligible || !config.moderation.review.enabled || Number(scored.score||0) < config.moderation.review.scoreAtLeast) return null;
  const c={...prior, schema:2, caseId, source:post.source, postId:post.postId, topicId:post.topicId, forumId:post.forumId, userId:post.userId, username:post.username, link:post.link, topicTitle:post.topicTitle, text:safeString(post.text,4000), score:Number(scored.score||0), stateScore:Number(scored.stateScore??post.stateScore??post.score??0), clusterScore:scored.clusterScore??post.clusterScore??null, clusterVoteCount:Number(scored.clusterVoteCount??post.clusterVoteCount??0), clusterExpectedCount:Number(scored.clusterExpectedCount??post.clusterExpectedCount??0), clusterComplete:scored.clusterComplete===true||post.clusterComplete===true, scoreBasis:scored.basis||post.effectiveScoreBasis||'state', maxScore:scored.maxScore, reasons:scored.reasons, reviewTarget:config.moderation.review.target, contentHash, firstLedger:prior.firstLedger||ln, lastLedger:ln, whitelisted:false};
  if (!prior.status || ['below_threshold','dismissed','whitelisted'].includes(prior.status)) c.status = prior.status==='dismissed' && prior.contentHash===contentHash ? 'dismissed' : 'pending_review';
  state.moderationCases[caseId]=c;
  const autoReady = c.clusterComplete === true;
  if (autoReady && config.moderation.purgeUser.enabled && config.moderation.purgeUser.automatic && c.score >= config.moderation.purgeUser.scoreAtLeast) queueModerationAction(state,c,'purge_user',config,true);
  else if (autoReady && config.moderation.deleteBan.enabled && config.moderation.deleteBan.automatic && c.score >= config.moderation.deleteBan.scoreAtLeast) queueModerationAction(state,c,'delete_post_and_ban_user',config,true);
  return c;
}
function moderationCommand(input, ctx) {
  ensureFiles();
  const state=loadState(), config=loadConfig();
  const caseId=safeString(input&&input.caseId,64), command=safeString(input&&input.command,64);
  const c=state.moderationCases[caseId];
  if(!c) throw new Error('Moderation case not found.');
  const ln=ledgerNo(ctx); c.lastLedger=ln;
  const linked=c.actionId ? ensureActionMeta(state.moderationActions[c.actionId]) : null;
  const linkedActive=!!(linked && ['pending','assigned'].includes(linked.status));
  const protectedUser=isWhitelistedIdentity(c,config);
  if(protectedUser && ['delete_post','delete_post_and_ban_user','purge_user'].includes(command)) throw new Error('This user is protected by the ForumGuard whitelist. No destructive action is allowed.');

  if(command==='dismiss'){
    if(linkedActive) throw new Error('Cannot dismiss this review while a destructive action is pending or running. Dismiss does not cancel phpBB work.');
    if(c.status!=='dismissed') state.totals.moderationDismissed++;
    c.status='dismissed'; c.dismissedLedger=ln;
  }
  else if(command==='reopen'){
    if(linkedActive) throw new Error('Cannot reopen this review while a destructive action is pending or running.');
    c.status='pending_review'; delete c.dismissedLedger;
  }
  else if(command==='delete_post'){
    if(linkedActive) throw new Error('This moderation case already has a destructive action pending or running. Wait for its result or use Retry only after a recorded failure/timeout.');
    queueModerationAction(state,c,'delete_post',config,false);
  }
  else if(command==='delete_post_and_ban_user'){
    if(!config.moderation.deleteBan.enabled) throw new Error('Delete + ban action is disabled.');
    if(linkedActive) throw new Error('This moderation case already has a destructive action pending or running. Wait for its result or use Retry only after a recorded failure/timeout.');
    queueModerationAction(state,c,'delete_post_and_ban_user',config,false);
  }
  else if(command==='purge_user'){
    if(!config.moderation.purgeUser.enabled) throw new Error('Purge user action is disabled.');
    if(!String(c.userId||'').trim()&&!String(c.username||'').trim()) throw new Error('Purge requires a phpBB user ID or username from the feed.');
    if(linkedActive) throw new Error('This moderation case already has a destructive action pending or running. Wait for its result or use Retry only after a recorded failure/timeout.');
    queueModerationAction(state,c,'purge_user',config,false);
  }
  else if(command==='retry'){
    const a=linked;
    if(!a) throw new Error('No action to retry.');
    if(a.status==='assigned') throw new Error('Cannot retry while a Forum Manager is currently executing this action. Wait for its result or timeout.');
    if(a.status==='completed') throw new Error('Cannot retry a completed moderation action.');
    if(a.status!=='pending') throw new Error(`Action is ${a.status||'unknown'} and is not eligible for retry.`);
    const failed=Array.isArray(a.failedExecutors)?a.failedExecutors:[];
    if(finiteInt(a.workerFailures,0,0,1000000)<1 && finiteInt(a.timeouts,0,0,1000000)<1 && failed.length<1) throw new Error('This action is already pending normally; there is no failed-manager exclusion to clear.');
    const prior=a.executor||a.lastExecutor||'';
    a.status='pending'; a.executor=null; a.failedExecutors=[]; a.updatedLedger=ln;
    actionEvent(a,'manual_retry','Head admin cleared failed-executor exclusions and requested another attempt.',ln,prior);
    c.status='action_pending'; c.actionStatus='pending'; c.executor=null;
  }
  else throw new Error('Unsupported moderation command.');
  writeJson(STATE_FILE,state);
  return snapshot({leaderboardLimit:200,eventLimit:200});
}
function readLocalManager() { return getLocalManagerStatus(); }
function managerHeartbeat(ctx) { const m=readLocalManager(); if(!m.forumManager||!m.forumUrl||!m.username||!m.passwordSet)return null; return {kind:'forum-manager-heartbeat-v1',ledger:ledgerNo(ctx),priority:m.priority,forumHost:(()=>{try{return new URL(m.forumUrl).host}catch{return ''}})(),capabilities:['test_manager','delete_post','ban_user','delete_post_and_ban_user','purge_user','cluster_score_vote_v1']}; }

function buildLocalClusterVote(state, config, ctx, self, maxVotes=40) {
  if (!/^ed[0-9a-f]{64}$/.test(self)) return null;
  const local=getLocalIndividualScoring(config).config, rulesHash=localScoringHash(local), ln=finiteInt(ledgerNo(ctx),0,0,Number.MAX_SAFE_INTEGER);
  const rows=Object.entries(state.posts||{}).filter(([,p])=>p&&p.contentHash).sort((a,b)=>finiteInt(b[1].lastLedger,0)-finiteInt(a[1].lastLedger,0)||a[0].localeCompare(b[0])).slice(0,Math.max(1,Math.min(100,maxVotes)));
  const votes=[];
  for(const [postKey,post] of rows){
    const eligible=passesFilters(post,{filters:local.filters}).pass;
    const scored=scorePost(post,{scoring:local.scoring},eligible);
    votes.push({postKey,contentHash:post.contentHash,score:scored.score,maxScore:scored.maxScore,eligible,rulesHash,ledger:ln});
  }
  return {kind:'forum-spam-score-vote-v1',ledger:ln,useClusterScore:local.useClusterScoreVote===true,votes};
}
function applyClusterVoteMessage(state, message, sender, config, ctx, expectedVoters, quorumInfo={}) {
  if(!message||message.kind!=='forum-spam-score-vote-v1'||!/^ed[0-9a-f]{64}$/.test(sender))return 0;
  let changed=0; const ln=finiteInt(ledgerNo(ctx),0,0,Number.MAX_SAFE_INTEGER);
  state.clusterScoring=state.clusterScoring&&typeof state.clusterScoring==='object'?state.clusterScoring:{};
  state.clusterScoring.scoreModeVotes=state.clusterScoring.scoreModeVotes&&typeof state.clusterScoring.scoreModeVotes==='object'&&!Array.isArray(state.clusterScoring.scoreModeVotes)?state.clusterScoring.scoreModeVotes:{};
  const oldMode=state.clusterScoring.clusterModeActive===true;
  const priorModeVote=state.clusterScoring.scoreModeVotes[sender];
  const nextModeVote={useClusterScore:message.useClusterScore===true,ledger:finiteInt(message.ledger,ln,0,Number.MAX_SAFE_INTEGER)};
  state.clusterScoring.scoreModeVotes[sender]=nextModeVote;
  const modeVoteChanged=!priorModeVote||priorModeVote.useClusterScore!==nextModeVote.useClusterScore;
  const mode=refreshClusterScoringMode(state,expectedVoters,quorumInfo);
  for(const raw of (Array.isArray(message.votes)?message.votes:[]).slice(0,100)){
    const key=safeString(raw.postKey,300),post=state.posts[key]; if(!post||raw.contentHash!==post.contentHash)continue;
    const maxScore=finiteInt(raw.maxScore,100,1,1000),score=Math.max(0,Math.min(maxScore,Number(raw.score)||0));
    const prior=post.clusterVotes&&post.clusterVotes[sender];
    const vote={score,maxScore,eligible:raw.eligible!==false,rulesHash:safeString(raw.rulesHash,128),contentHash:post.contentHash,ledger:finiteInt(raw.ledger,ln,0,Number.MAX_SAFE_INTEGER)};
    if(!post.clusterVotes||typeof post.clusterVotes!=='object'||Array.isArray(post.clusterVotes))post.clusterVotes={};
    const differs=!prior||prior.score!==vote.score||prior.maxScore!==vote.maxScore||prior.eligible!==vote.eligible||prior.rulesHash!==vote.rulesHash||prior.contentHash!==vote.contentHash;
    post.clusterVotes[sender]=vote; refreshPostClusterScore(post,expectedVoters,mode.clusterModeActive); post.whitelisted=isWhitelistedIdentity(post,config);
    if(differs){changed++;state.totals.clusterVotesReceived=finiteInt(state.totals.clusterVotesReceived,0,0,100000000)+1;state.totals.clusterScoreUpdates=finiteInt(state.totals.clusterScoreUpdates,0,0,100000000)+1;state.clusterScoring.votesApplied=finiteInt(state.clusterScoring.votesApplied,0,0,100000000)+1;updateModerationCase(state,post,moderationScoreView(post),post.eligible!==false,config,ctx);}
  }
  if(modeVoteChanged||oldMode!==mode.clusterModeActive){
    for(const post of Object.values(state.posts||{})){if(!post)continue;refreshPostClusterScore(post,expectedVoters,mode.clusterModeActive);post.whitelisted=isWhitelistedIdentity(post,config);if(post.eligible!==false)updateModerationCase(state,post,moderationScoreView(post),true,config,ctx);}
  }
  if(changed||modeVoteChanged)state.clusterScoring.lastVoteLedger=ln;
  return changed;
}
function applyWhitelistProtection(state,config,ctx){
  const ln=finiteInt(ledgerNo(ctx),0,0,Number.MAX_SAFE_INTEGER);
  for(const c of Object.values(state.moderationCases||{})){
    if(!c)continue; const protectedUser=isWhitelistedIdentity(c,config); c.whitelisted=protectedUser;
    if(protectedUser && !['action_completed'].includes(c.status)) c.status='whitelisted';
  }
  for(const a of Object.values(state.moderationActions||{})){
    if(!a||!['pending','assigned'].includes(a.status)||a.type==='test_forum_manager')continue;
    if(!isWhitelistedIdentity(a,config))continue;
    const executor=a.executor||a.lastExecutor||''; a.status='cancelled';a.executor=null;a.updatedLedger=ln;actionEvent(a,'whitelist_cancelled','Action cancelled because the user is on the ForumGuard whitelist.',ln,executor);
    const c=a.caseId?state.moderationCases[a.caseId]:null;if(c){c.status='whitelisted';c.actionStatus='cancelled';c.executor=null;c.whitelisted=true;}
  }
}

function createManagerInbox(ctx) {
  const heartbeats=[],results=[],diagnostics=[],scoreVotes=[]; const current=Number(ledgerNo(ctx));
  ctx.unl.onMessage((node,msg)=>{try{const x=JSON.parse(Buffer.from(msg).toString('utf8')); if(!x||Number(x.ledger)!==current)return; const sender=publicKeyHex(node&&node.publicKey); if(!/^ed[0-9a-f]{64}$/.test(sender))return; if(x.kind==='forum-manager-heartbeat-v1')heartbeats.push({...x,publicKey:sender}); else if(x.kind==='forum-manager-result-v1')results.push({...x,publicKey:sender}); else if(x.kind==='forum-manager-diagnostic-v1')diagnostics.push({...x,publicKey:sender}); else if(x.kind==='forum-spam-score-vote-v1')scoreVotes.push({...x,publicKey:sender});}catch{}});
  return {collect(ms){return new Promise(r=>setTimeout(()=>r({heartbeats,results,diagnostics,scoreVotes}),ms));}};
}
function scrubLegacyLocalResultFiles(){
  if(localLegacyResultsScrubbed)return;
  localLegacyResultsScrubbed=true;
  try{
    if(!fs.existsSync(LOCAL_RESULT_DIR))return;
    const names=fs.readdirSync(LOCAL_RESULT_DIR).filter(n=>/^[a-f0-9]{16,64}(?:-\d+)?\.json$/i.test(n)&&!n.endsWith('.status.json')).slice(0,500);
    for(const name of names){
      const f=path.join(LOCAL_RESULT_DIR,name),raw=readJson(f,null),clean=sanitizeWorkerResult(raw);
      if(!clean||!clean.actionId)continue;
      const before=JSON.stringify(raw),after=JSON.stringify(clean);
      if(before!==after)writeJson(f,clean);
    }
  }catch{}
}
function localResultForAssigned(state,self){
  try{
    const actions=Object.values(state.moderationActions||{}).filter(a=>a&&a.status==='assigned'&&a.executor===self).map(ensureActionMeta);
    const runtime=readLocalManagerRuntime(),cached=sanitizeWorkerResult(runtime.result);
    for(const a of actions){const seq=finiteInt(a.assignmentSeq,0,0,1000000);if(cached&&cached.actionId===a.actionId&&finiteInt(cached.assignmentSeq,seq,0,1000000)===seq)return cached;const key=`${a.actionId}-${seq}`;if(localImmediateResults.has(key)){const x=localImmediateResults.get(key);localImmediateResults.delete(key);return sanitizeWorkerResult(x);}}
    if(!fs.existsSync(LOCAL_RESULT_DIR))return null;
    for(const a of actions){const seq=finiteInt(a.assignmentSeq,0,0,1000000),f=path.join(LOCAL_RESULT_DIR,`${a.actionId}-${seq}.json`);if(fs.existsSync(f)){const x=sanitizeWorkerResult(readJson(f,null));if(x&&x.actionId===a.actionId&&finiteInt(x.assignmentSeq,seq,0,1000000)===seq)return x;}}
  }catch{}
  return null;
}
function localLateResultForTimedOut(state,self){
  try{
    const actions=Object.values(state.moderationActions||{}).map(ensureActionMeta).filter(a=>a&&a.status==='pending'&&a.lastExecutor===self&&a.timeouts>0&&finiteInt(a.handledResultSeq,0,0,1000000)<finiteInt(a.assignmentSeq,0,0,1000000));
    const runtime=readLocalManagerRuntime(),cached=sanitizeWorkerResult(runtime.result);
    for(const a of actions){const seq=finiteInt(a.assignmentSeq,0,0,1000000);if(cached&&cached.actionId===a.actionId&&finiteInt(cached.assignmentSeq,seq,0,1000000)===seq)return {...cached,late:true};if(fs.existsSync(LOCAL_RESULT_DIR)){const f=path.join(LOCAL_RESULT_DIR,`${a.actionId}-${seq}.json`);if(fs.existsSync(f)){const x=sanitizeWorkerResult(readJson(f,null));if(x&&x.actionId===a.actionId&&finiteInt(x.assignmentSeq,seq,0,1000000)===seq)return {...x,late:true};}}}
  }catch{}
  return null;
}
function applyManagerResult(state,result,ctx){
  result=sanitizeWorkerResult(result); if(!result)return;
  const a=ensureActionMeta(state.moderationActions[safeString(result.actionId,64)]); if(!a)return;
  const resultExecutor=safeString(result.executor||result.publicKey,160), resultSeq=finiteInt(result.assignmentSeq,a.assignmentSeq,0,1000000);
  const normal=a.status==='assigned'&&a.executor===resultExecutor&&resultSeq===finiteInt(a.assignmentSeq,0,0,1000000);
  const late=a.status==='pending'&&a.lastExecutor===resultExecutor&&a.timeouts>0&&resultSeq===finiteInt(a.assignmentSeq,0,0,1000000)&&finiteInt(a.handledResultSeq,0,0,1000000)<resultSeq;
  if(!normal&&!late)return;
  const c=a.caseId?state.moderationCases[a.caseId]:null, ln=ledgerNo(ctx), executor=normal?a.executor:a.lastExecutor, isTest=a.type==='test_forum_manager';
  a.updatedLedger=ln; a.lastExecutor=executor; a.lastResult=result; a.handledResultSeq=resultSeq; a.failoverNotBeforeLedger=0;
  if(result.ok===true){
    a.status='completed'; a.executor=null;
    actionEvent(a,late?'late_completed':(isTest?'test_passed':'completed'),late?'A worker result arrived after the previous timeout; success was reconciled before a retry/failover.':(isTest?'Forum Manager access test passed.':'Manager reported successful phpBB moderation.'),ln,executor,{assignmentSeq:resultSeq});
    if(c){c.status='action_completed';c.actionStatus='completed';c.executor=executor;}
    if(isTest)state.totals.managerTestsPassed=finiteInt(state.totals.managerTestsPassed,0,0,100000000)+1;else state.totals.moderationCompleted++;
  } else {
    a.attempts=finiteInt(a.attempts,0,0,100000)+1; a.workerFailures=finiteInt(a.workerFailures,0,0,100000)+1;
    if(isTest){a.status='failed';a.executor=null;actionEvent(a,'test_failed',safeString(result.error,1000)||'Forum Manager test returned an unspecified error.',ln,executor,{assignmentSeq:resultSeq});state.totals.managerTestsFailed=finiteInt(state.totals.managerTestsFailed,0,0,100000000)+1;}
    else {a.failedExecutors=Array.from(new Set([...(a.failedExecutors||[]),executor]));a.status='pending';a.executor=null;actionEvent(a,late?'late_worker_failed':'worker_failed',safeString(result.error,1000)||'Forum Manager worker returned an unspecified error.',ln,executor,{assignmentSeq:resultSeq});if(c){c.status='action_pending';c.actionStatus='pending';c.executor=null;}state.totals.moderationFailed++;}
  }
}
function chooseActionExecutor(state,ctx,config){ const ln=finiteInt(ledgerNo(ctx),0,0,Number.MAX_SAFE_INTEGER); const managers=Object.values(state.managerRegistry||{}).filter(m=>m&&m.enabled!==false&&ln-finiteInt(m.lastSeenLedger,0,0,ln)<=config.moderation.manager.staleAfterLedgers).sort((a,b)=>finiteInt(a.priority,999999,1,999999)-finiteInt(b.priority,999999,1,999999)||String(a.publicKey).localeCompare(String(b.publicKey)));
  const actions=Object.values(state.moderationActions||{}).filter(a=>a&&a.status==='pending').map(ensureActionMeta).sort((a,b)=>finiteInt(a.createdLedger,0)-finiteInt(b.createdLedger,0)||String(a.actionId).localeCompare(String(b.actionId)));
  for(const a of actions){ if(finiteInt(a.failoverNotBeforeLedger,0,0,Number.MAX_SAFE_INTEGER)>ln)continue; const pick=managers.find(m=>!(a.failedExecutors||[]).includes(m.publicKey)&&(!a.targetExecutor||m.publicKey===a.targetExecutor)); if(!pick)continue; a.assignments=finiteInt(a.assignments,0,0,1000000)+1; a.assignmentSeq=finiteInt(a.assignmentSeq,0,0,1000000)+1; a.executor=pick.publicKey; a.lastExecutor=pick.publicKey; a.status='assigned';a.assignedLedger=ln;a.assignedAtMs=ledgerTimeMs(ctx)||0;a.lastProgressLedger=ln;a.lastProgressAtMs=a.assignedAtMs;a.failoverNotBeforeLedger=0;a.updatedLedger=ln;a.workerDiagnostic=null;a.lastDiagnosticStage=''; actionEvent(a,a.type==='test_forum_manager'?'test_assigned':'assigned',a.type==='test_forum_manager'?`Selected validator priority ${finiteInt(pick.priority,100,1,1000000)} assigned to non-destructive manager test.`:`Assigned to Forum Manager priority ${finiteInt(pick.priority,100,1,1000000)}; waiting for worker result.`,ln,pick.publicKey,{assignmentSeq:a.assignmentSeq}); const c=a.caseId?state.moderationCases[a.caseId]:null;if(c){c.status='action_pending';c.actionStatus='assigned';c.executor=pick.publicKey;} return a; }
  return null;
}
function workerPaths(action){ const seq=finiteInt(action.assignmentSeq,0,0,1000000),stem=`${action.actionId}-${seq}`; return {seq,stem,actionFile:path.join(LOCAL_ACTION_DIR,`${stem}.json`),resultFile:path.join(LOCAL_RESULT_DIR,`${stem}.json`),statusFile:path.join(LOCAL_RESULT_DIR,`${stem}.status.json`),logFile:path.join(LOCAL_WORKER_LOG_DIR,`${stem}.worker.log`)}; }
function processAlive(pid){ if(!pid)return false; try{process.kill(pid,0);return true;}catch{return false;} }
function localDiagnosticForAssigned(state,self){
  try{
    const runtime=readLocalManagerRuntime(),cached=sanitizeWorkerDiagnostic(runtime.diagnostic);
    if(cached){const a=ensureActionMeta(state.moderationActions[cached.actionId]);if(a&&a.status==='assigned'&&a.executor===self&&finiteInt(cached.assignmentSeq,a.assignmentSeq,0,1000000)===finiteInt(a.assignmentSeq,0,0,1000000))return cached;}
    for(const raw of Object.values(state.moderationActions||{})){const a=ensureActionMeta(raw);if(!a||a.status!=='assigned'||a.executor!==self)continue;const p=workerPaths(a);if(fs.existsSync(p.statusFile)){const d=sanitizeWorkerDiagnostic(readJson(p.statusFile,null));if(d&&d.actionId===a.actionId&&finiteInt(d.assignmentSeq,p.seq,0,1000000)===p.seq)return d;}}
  }catch{}
  return null;
}
function localSyntheticFailureForAssigned(state,self,currentLedger){
  try{
    for(const raw of Object.values(state.moderationActions||{})){
      const a=ensureActionMeta(raw);if(!a||a.status!=='assigned'||a.executor!==self)continue;
      if(localResultForAssigned(state,self))continue;
      const runtime=readLocalManagerRuntime(),d=sanitizeWorkerDiagnostic(runtime.diagnostic);
      if(d&&d.actionId===a.actionId&&finiteInt(d.assignmentSeq,a.assignmentSeq,0,1000000)===finiteInt(a.assignmentSeq,0,0,1000000)&&['worker_failed','inline_interrupted'].includes(d.stage))return {schema:3,workerVersion:d.workerVersion,actionId:a.actionId,assignmentSeq:a.assignmentSeq,executor:self,startedAt:d.startedAt||d.updatedAt,finishedAt:d.finishedAt||d.updatedAt,ok:false,error:d.error||`Inline Forum Manager execution ended at ${d.stage}.`,failedStep:d.failedStep||d.step||d.stage,detail:{executionMode:'inline',workerStage:d.stage}};
      if(!d&&finiteInt(currentLedger,0)-finiteInt(a.assignedLedger,0)>=2)return {schema:3,workerVersion:APP_VERSION,actionId:a.actionId,assignmentSeq:a.assignmentSeq,executor:self,startedAt:Date.now(),finishedAt:Date.now(),ok:false,error:'Assigned Forum Manager produced neither an inline result nor a progress record. The contract invocation may have been interrupted before phpBB execution started.',failedStep:'inline_execution_missing',detail:{executionMode:'inline'}};
    }
  }catch{}
  return null;
}
async function runInlineAssignedAction(action,self){
  if(!action||action.status!=='assigned'||action.executor!==self)return null;
  const seq=finiteInt(action.assignmentSeq,0,0,1000000),runtime=readLocalManagerRuntime(),existing=sanitizeWorkerResult(runtime.result);
  if(existing&&existing.actionId===action.actionId&&finiteInt(existing.assignmentSeq,seq,0,1000000)===seq)return existing;
  const cfg=localManagerPrivate();
  const worker=require(path.resolve(__dirname,'forum-manager-worker.js'));
  if(!worker||typeof worker.runForumManagerAction!=='function')throw new Error('Forum Manager inline worker module is unavailable.');
  const persistDiag=(d)=>{try{const clean=sanitizeWorkerDiagnostic({...d,executor:self,actionId:action.actionId,assignmentSeq:seq});writeLocalManagerRuntime({mode:'inline',diagnostic:clean,result:null});}catch{}};
  persistDiag({schema:2,workerVersion:APP_VERSION,stage:'inline_started',actionType:action.type,updatedAt:Date.now(),startedAt:Date.now()});
  let result;
  try{result=await worker.runForumManagerAction({...action,executor:self,assignmentSeq:seq},cfg,persistDiag);}catch(err){result={schema:3,workerVersion:APP_VERSION,actionId:action.actionId,assignmentSeq:seq,executor:self,startedAt:Date.now(),finishedAt:Date.now(),ok:false,error:`Inline Forum Manager execution failed: ${safeString(err&&err.message||err,1000)}`,failedStep:'inline_worker',detail:{executionMode:'inline'},steps:[]};}
  result=sanitizeWorkerResult({...result,executor:self,actionId:action.actionId,assignmentSeq:seq});
  writeLocalManagerRuntime({mode:'inline',diagnostic:sanitizeWorkerDiagnostic({schema:2,workerVersion:APP_VERSION,stage:result.ok?'result_ready':'worker_failed',actionId:action.actionId,assignmentSeq:seq,executor:self,updatedAt:Date.now(),finishedAt:result.finishedAt,error:result.error||'',failedStep:result.failedStep||''}),result});
  return result;
}
function applyWorkerDiagnostic(state,raw,ctx){const d=sanitizeWorkerDiagnostic(raw);if(!d)return;const a=ensureActionMeta(state.moderationActions[d.actionId]);if(!a||a.status!=='assigned'||a.executor!==safeString(d.executor||raw.publicKey,160)||finiteInt(d.assignmentSeq,a.assignmentSeq,0,1000000)!==finiteInt(a.assignmentSeq,0,0,1000000))return;const stage=d.stage||'unknown',diagUpdated=finiteInt(d.updatedAt,0,0,Number.MAX_SAFE_INTEGER),isFresh=diagUpdated>finiteInt(a.lastDiagnosticUpdatedAt,0,0,Number.MAX_SAFE_INTEGER)||stage!==a.lastDiagnosticStage;a.workerDiagnostic=d;a.updatedLedger=ledgerNo(ctx);if(isFresh){a.lastProgressLedger=finiteInt(ledgerNo(ctx),a.lastProgressLedger||a.assignedLedger,0,Number.MAX_SAFE_INTEGER);a.lastProgressAtMs=ledgerTimeMs(ctx)||a.lastProgressAtMs||a.assignedAtMs||0;a.lastDiagnosticUpdatedAt=Math.max(finiteInt(a.lastDiagnosticUpdatedAt,0,0,Number.MAX_SAFE_INTEGER),diagUpdated);}if(stage!==a.lastDiagnosticStage){a.lastDiagnosticStage=stage;const labels={inline_started:'Inline phpBB execution started on the elected manager.',launch_requested:'Worker launch requested.',spawned:'Worker process spawned.',worker_started:'Forum Manager execution started.',step_started:`Forum Manager started step ${d.step||'unknown'}.`,step_ok:`Forum Manager completed step ${d.step||'unknown'}.`,step_failed:`Forum Manager failed step ${d.step||'unknown'}.`,result_ready:'Inline result buffered locally for broadcast on the next moderation round.',result_written:'Worker wrote a result file.',worker_failed:`Forum Manager failed at ${d.failedStep||d.step||'unknown step'}.`,fatal_result_write_failed:'Worker could not write its result file.'};actionEvent(a,'worker_diagnostic',labels[stage]||`Worker stage: ${stage}.`,ledgerNo(ctx),a.executor,{assignmentSeq:a.assignmentSeq,workerStage:stage,workerStep:d.step||''});}}
function spawnLocalAction(action,self){
  if(!action||action.executor!==self)return null;
  const paths=workerPaths(action), key=`${action.actionId}-${paths.seq}`;
  try{
    ensureLocalRuntimeDirs();
    if(fs.existsSync(paths.resultFile))return {started:true,paths};
    if(fs.existsSync(paths.statusFile)){
      const old=sanitizeWorkerDiagnostic(readJson(paths.statusFile,null));
      if(old&&old.actionId===action.actionId&&finiteInt(old.assignmentSeq,paths.seq,0,1000000)===paths.seq&&['launch_requested','spawned','worker_started','step_started','step_ok'].includes(old.stage)&&(!old.pid||processAlive(old.pid)))return {started:true,paths};
    }
    fs.writeFileSync(paths.actionFile,JSON.stringify(action,null,2)+'\n',{mode:0o600});
    writeJson(paths.statusFile,{schema:2,workerVersion:APP_VERSION,stage:'launch_requested',actionId:action.actionId,assignmentSeq:paths.seq,executor:self,pid:0,updatedAt:Date.now(),logFile:path.basename(paths.logFile)});
    const logFd=fs.openSync(paths.logFile,'a',0o600); let cp;
    try{cp=require('child_process').spawn(process.execPath,[path.resolve(__dirname,'forum-manager-worker.js'),paths.actionFile,paths.resultFile,LOCAL_CUSTOM_FILE,paths.statusFile],{detached:true,stdio:['ignore',logFd,logFd]});}
    finally{try{fs.closeSync(logFd);}catch{}}
    const currentStatus=readJson(paths.statusFile,null);
    if(!currentStatus||currentStatus.stage==='launch_requested')writeJson(paths.statusFile,{schema:2,workerVersion:APP_VERSION,stage:'spawned',actionId:action.actionId,assignmentSeq:paths.seq,executor:self,pid:cp.pid||0,updatedAt:Date.now(),logFile:path.basename(paths.logFile)});
    cp.unref(); return {started:true,paths,pid:cp.pid||0};
  }catch(err){
    const failure={schema:3,workerVersion:APP_VERSION,actionId:action.actionId,assignmentSeq:paths.seq,executor:self,startedAt:Date.now(),finishedAt:Date.now(),ok:false,error:`Worker local runtime/spawn failed: ${safeString(err&&err.message||err,700)}`,failedStep:'worker_runtime_or_spawn',detail:{runtimeRoot:LOCAL_RUNTIME_ROOT},steps:[]};
    localImmediateResults.set(key,failure);
    console.log(`Forum manager worker spawn failed: ${failure.error}`);
    try{ensureLocalRuntimeDirs();writeJson(paths.statusFile,{schema:2,workerVersion:APP_VERSION,stage:'spawn_error',actionId:action.actionId,assignmentSeq:paths.seq,executor:self,pid:0,updatedAt:Date.now(),error:failure.error});writeJson(paths.resultFile,failure);}catch{}
    return {started:false,error:failure.error,paths};
  }
}
async function testLocalForumManager(options={}){
  ensureFiles(); cleanupLocalRuntime();
  const manager=localManagerPrivate(), runtime=workerRuntimeStatus();
  const baseSteps=[
    {name:'worker_runtime',ok:runtime.writable===true,startedAt:Date.now(),finishedAt:Date.now(),error:runtime.writable?'':(runtime.error||'Local worker runtime is not writable.'),detail:{runtimeRoot:runtime.runtimeRoot}},
    {name:'worker_file',ok:runtime.workerExists===true,startedAt:Date.now(),finishedAt:Date.now(),error:runtime.workerExists?'':'forum-manager-worker.js is missing from this contract package.',detail:{}}
  ];
  if(!runtime.writable){const fail={schema:3,workerVersion:APP_VERSION,actionId:'local-preflight',assignmentSeq:0,executor:safeString(options.executor,160),startedAt:Date.now(),finishedAt:Date.now(),ok:false,error:`ForumGuard local worker runtime is not writable: ${runtime.error||runtime.runtimeRoot}`,failedStep:'worker_runtime',detail:{},steps:baseSteps,runtime};try{ensureLocalRuntimeDirs();writeJson(LOCAL_TEST_RESULT_FILE,fail);}catch{}return fail;}
  if(!runtime.workerExists){const fail={schema:3,workerVersion:APP_VERSION,actionId:'local-preflight',assignmentSeq:0,executor:safeString(options.executor,160),startedAt:Date.now(),finishedAt:Date.now(),ok:false,error:'forum-manager-worker.js is missing from this contract package.',failedStep:'worker_file',detail:{},steps:baseSteps,runtime};try{writeJson(LOCAL_TEST_RESULT_FILE,fail);}catch{}return fail;}
  const self=safeString(options.executor,160)||'local-test';
  const actionId=crypto.randomBytes(16).toString('hex'), action={schema:3,actionId,assignmentSeq:1,executor:self,type:'test_forum_manager',nonDestructive:true};
  const p=workerPaths(action), startedAt=Date.now(); let cp=null, spawnError=null;
  try{
    ensureLocalRuntimeDirs();
    for(const f of [p.actionFile,p.resultFile,p.statusFile,p.logFile]){try{fs.unlinkSync(f);}catch{}}
    fs.writeFileSync(p.actionFile,JSON.stringify(action,null,2)+'\n',{mode:0o600});
    writeJson(p.statusFile,{schema:2,workerVersion:APP_VERSION,stage:'launch_requested',actionId,assignmentSeq:1,executor:self,pid:0,updatedAt:Date.now()});
    const logFd=fs.openSync(p.logFile,'a',0o600);
    try{
      cp=require('child_process').spawn(process.execPath,[path.resolve(__dirname,'forum-manager-worker.js'),p.actionFile,p.resultFile,LOCAL_CUSTOM_FILE,p.statusFile],{detached:false,stdio:['ignore',logFd,logFd]});
      cp.once('error',e=>{spawnError=e;});
    } finally { try{fs.closeSync(logFd);}catch{} }
    const current=readJson(p.statusFile,null);
    if(!current||current.stage==='launch_requested')writeJson(p.statusFile,{schema:2,workerVersion:APP_VERSION,stage:'spawned',actionId,assignmentSeq:1,executor:self,pid:cp.pid||0,updatedAt:Date.now()});
    baseSteps.push({name:'worker_spawn',ok:true,startedAt:startedAt,finishedAt:Date.now(),error:'',detail:{pid:cp.pid||0}});
    const timeoutMs=Math.max(5000,Math.min(60000,finiteInt(options.timeoutMs,Math.max(15000,manager.requestTimeoutMs*4),5000,60000)));
    while(Date.now()-startedAt<timeoutMs){
      if(spawnError){const fail={schema:3,workerVersion:APP_VERSION,actionId,assignmentSeq:1,executor:self,startedAt,finishedAt:Date.now(),ok:false,error:`Forum Manager worker spawn failed: ${safeString(spawnError.message||spawnError,700)}`,failedStep:'worker_spawn',detail:{},steps:[...baseSteps.slice(0,2),{name:'worker_spawn',ok:false,startedAt,finishedAt:Date.now(),error:safeString(spawnError.message||spawnError,700),detail:{}}],runtime};try{writeJson(LOCAL_TEST_RESULT_FILE,fail);}catch{}return fail;}
      if(fs.existsSync(p.resultFile)){
        const result=sanitizeWorkerResult(readJson(p.resultFile,null));
        if(result){result.steps=[...baseSteps,...(result.steps||[])];result.runtime=runtime;try{writeJson(LOCAL_TEST_RESULT_FILE,result);}catch{}return result;}
      }
      if(cp.exitCode!==null){
        await new Promise(r=>setTimeout(r,100));
        if(fs.existsSync(p.resultFile)){const result=sanitizeWorkerResult(readJson(p.resultFile,null));if(result){result.steps=[...baseSteps,...(result.steps||[])];result.runtime=runtime;try{writeJson(LOCAL_TEST_RESULT_FILE,result);}catch{}return result;}}
        const d=sanitizeWorkerDiagnostic(readJson(p.statusFile,null));
        const fail={schema:3,workerVersion:APP_VERSION,actionId,assignmentSeq:1,executor:self,startedAt,finishedAt:Date.now(),ok:false,error:`Forum Manager test worker exited with code ${cp.exitCode} before returning a result${d&&d.stage?` (last stage: ${d.stage}${d.step?` / ${d.step}`:''})`:''}.`,failedStep:d&&d.step||'worker_process_exit',detail:{workerStage:d&&d.stage||''},steps:baseSteps,runtime};try{writeJson(LOCAL_TEST_RESULT_FILE,fail);}catch{}return fail;
      }
      await new Promise(r=>setTimeout(r,100));
    }
    try{cp.kill('SIGTERM');}catch{}
    const d=sanitizeWorkerDiagnostic(readJson(p.statusFile,null));
    const fail={schema:3,workerVersion:APP_VERSION,actionId,assignmentSeq:1,executor:self,startedAt,finishedAt:Date.now(),ok:false,error:`Forum Manager test exceeded ${Math.round(timeoutMs/1000)} seconds${d&&d.stage?` (last stage: ${d.stage}${d.step?` / ${d.step}`:''})`:''}.`,failedStep:d&&d.step||'worker_timeout',detail:{workerStage:d&&d.stage||''},steps:baseSteps,runtime};try{writeJson(LOCAL_TEST_RESULT_FILE,fail);}catch{}return fail;
  }catch(err){
    const fail={schema:3,workerVersion:APP_VERSION,actionId,assignmentSeq:1,executor:self,startedAt,finishedAt:Date.now(),ok:false,error:`Could not start local Forum Manager test: ${safeString(err&&err.message||err,700)}`,failedStep:'worker_runtime_or_spawn',detail:{runtimeRoot:LOCAL_RUNTIME_ROOT},steps:[...baseSteps,{name:'worker_spawn',ok:false,startedAt,finishedAt:Date.now(),error:safeString(err&&err.message||err,700),detail:{}}],runtime};try{ensureLocalRuntimeDirs();writeJson(LOCAL_TEST_RESULT_FILE,fail);}catch{}return fail;
  }
}
function inspectLocalWorkerRuntime(limit=12){
  const localRuntime=readLocalManagerRuntime();
  const out={runtime:{...workerRuntimeStatus(),executionMode:'inline-consensus-invocation',persistentResultStore:'../custom.json → forumguard_manager._forumguardRuntime'},inline:{diagnostic:sanitizeWorkerDiagnostic(localRuntime.diagnostic),result:sanitizeWorkerResult(localRuntime.result)},recent:[]};
  try{
    ensureLocalRuntimeDirs();
    const stems=new Set();
    for(const name of fs.readdirSync(LOCAL_RESULT_DIR)){const m=name.match(/^([a-f0-9]{16,64}-\d+)(?:\.status)?\.json$/i);if(m)stems.add(m[1]);}
    const rows=[];
    for(const stem of stems){
      const rf=path.join(LOCAL_RESULT_DIR,`${stem}.json`),sf=path.join(LOCAL_RESULT_DIR,`${stem}.status.json`);
      let mtime=0;try{mtime=Math.max(fs.existsSync(rf)?fs.statSync(rf).mtimeMs:0,fs.existsSync(sf)?fs.statSync(sf).mtimeMs:0);}catch{}
      const status=fs.existsSync(sf)?sanitizeWorkerDiagnostic(readJson(sf,null)):null;
      const result=fs.existsSync(rf)?sanitizeWorkerResult(readJson(rf,null)):null;
      rows.push({stem,mtime,status,result,pidAlive:status&&status.pid?processAlive(status.pid):false,resultExists:!!result,statusExists:!!status});
    }
    rows.sort((a,b)=>b.mtime-a.mtime);out.recent=rows.slice(0,Math.max(1,Math.min(50,finiteInt(limit,12,1,50))));
  }catch(e){out.error=safeString(e&&e.message||e,700);}
  return out;
}
function isModerationDue(ctx){ if(!ctx||ctx.readonly)return false; const state=loadState(),config=loadConfig(),ln=finiteInt(ledgerNo(ctx),0,0,Number.MAX_SAFE_INTEGER),self=publicKeyHex(ctx.publicKey); if(Object.values(state.moderationActions||{}).some(a=>a&&['pending','assigned'].includes(a.status)))return true; if(/^ed[0-9a-f]{64}$/.test(self)){const localMode=getLocalIndividualScoring(config).config.useClusterScoreVote===true,priorMode=state.clusterScoring?.scoreModeVotes?.[self];if(!priorMode||priorMode.useClusterScore!==localMode)return true;} const recent=Object.values(state.posts||{}).sort((a,b)=>finiteInt(b?.lastLedger,0)-finiteInt(a?.lastLedger,0)).slice(0,40); if(/^ed[0-9a-f]{64}$/.test(self)&&recent.some(p=>p&&(!p.clusterVotes||!p.clusterVotes[self]||p.clusterVotes[self].contentHash!==p.contentHash)))return true; return ln-finiteInt(state.moderationRuntime?.lastHeartbeatLedger,0,0,ln)>=config.moderation.manager.heartbeatEveryLedgers; }
async function moderationMaintenance(ctx){ if(ctx.readonly)return; ensureFiles(); cleanupLocalRuntime(); scrubLegacyLocalResultFiles(); const state=loadState(),config=loadConfig(),ln=ledgerNo(ctx),self=publicKeyHex(ctx.publicKey),hb=managerHeartbeat(ctx),inbox=createManagerInbox(ctx); let hpCfg={};try{hpCfg=await ctx.getConfig();}catch{} const expectedVoters=expectedValidatorKeys(hpCfg,self),quorum=scoreModeConsensusQuorum(hpCfg,expectedVoters),mode=refreshClusterScoringMode(state,expectedVoters,quorum);for(const post of Object.values(state.posts||{}))refreshPostClusterScore(post,expectedVoters,mode.clusterModeActive);applyWhitelistProtection(state,config,ctx); const scoreVote=buildLocalClusterVote(state,config,ctx,self,40); if(hb){try{await ctx.unl.send(JSON.stringify(hb));}catch{}} if(scoreVote){try{await ctx.unl.send(JSON.stringify(scoreVote));}catch{}}
  const localResult=localResultForAssigned(state,self)||localSyntheticFailureForAssigned(state,self,ln)||localLateResultForTimedOut(state,self); if(localResult){try{await ctx.unl.send(JSON.stringify({kind:'forum-manager-result-v1',ledger:ln,...sanitizeWorkerResult(localResult),executor:self}));}catch{}}
  const localDiagnostic=localDiagnosticForAssigned(state,self); if(localDiagnostic){try{await ctx.unl.send(JSON.stringify({kind:'forum-manager-diagnostic-v1',ledger:ln,...localDiagnostic,executor:self}));}catch{}}
  const collected=await inbox.collect(550); const scoreMessages=[...(collected.scoreVotes||[])]; if(scoreVote)scoreMessages.push({...scoreVote,publicKey:self}); scoreMessages.sort((a,b)=>String(a.publicKey||'').localeCompare(String(b.publicKey||''))); for(const msg of scoreMessages)applyClusterVoteMessage(state,msg,publicKeyHex(msg.publicKey),config,ctx,expectedVoters,quorum); applyWhitelistProtection(state,config,ctx); const allHbs=[...(collected.heartbeats||[])]; if(hb)allHbs.push({...hb,publicKey:self}); const uniq={}; for(const m of allHbs){if(!/^ed[0-9a-f]{64}$/.test(m.publicKey))continue; const rec={publicKey:m.publicKey,priority:finiteInt(m.priority,100,1,1000000),forumHost:safeString(m.forumHost,255),capabilities:Array.isArray(m.capabilities)?m.capabilities.slice(0,10):[],lastSeenLedger:ln,enabled:true}; const old=uniq[rec.publicKey]; if(!old||rec.priority<old.priority)uniq[rec.publicKey]=rec;} for(const [k,v] of Object.entries(uniq))state.managerRegistry[k]=v;
  const diagnostics=[...(collected.diagnostics||[])]; if(localDiagnostic)diagnostics.push({...localDiagnostic,executor:self,publicKey:self});diagnostics.sort((a,b)=>String(a.actionId||'').localeCompare(String(b.actionId||''))||String(a.publicKey||'').localeCompare(String(b.publicKey||'')));for(const d of diagnostics)applyWorkerDiagnostic(state,d,ctx);
  const results=[...(collected.results||[])]; if(localResult)results.push({...sanitizeWorkerResult(localResult),executor:self,publicKey:self}); results.sort((a,b)=>String(a.actionId||'').localeCompare(String(b.actionId||''))||String(a.publicKey||'').localeCompare(String(b.publicKey||''))); for(const r of results)applyManagerResult(state,r,ctx);
  for(const raw of Object.values(state.moderationActions||{})){
    const a=ensureActionMeta(raw); if(!a||a.status!=='assigned')continue;
    const progressLedger=finiteInt(a.lastProgressLedger||a.assignedLedger,finiteInt(a.assignedLedger,ln,0,Number.MAX_SAFE_INTEGER),0,Number.MAX_SAFE_INTEGER);
    const idleLedgers=finiteInt(ln,0,0,Number.MAX_SAFE_INTEGER)-progressLedger;
    const nowMs=ledgerTimeMs(ctx), progressMs=finiteInt(a.lastProgressAtMs||a.assignedAtMs,0,0,Number.MAX_SAFE_INTEGER);
    const idleMs=(nowMs&&progressMs&&nowMs>=progressMs)?nowMs-progressMs:null;
    const ledgerExpired=idleLedgers>=config.moderation.manager.resultWaitLedgers;
    const timeExpired=idleMs===null?true:idleMs>=config.moderation.manager.resultWaitSeconds*1000;
    if(!ledgerExpired||!timeExpired)continue;
    const executor=a.executor||'',isTest=a.type==='test_forum_manager';a.timeouts=finiteInt(a.timeouts,0,0,100000)+1;a.lastExecutor=executor||a.lastExecutor;a.failoverNotBeforeLedger=finiteInt(ln,0,0,Number.MAX_SAFE_INTEGER)+config.moderation.manager.failoverGraceLedgers;
    if(isTest){a.executor=null;a.status='failed';state.totals.managerTestsFailed=finiteInt(state.totals.managerTestsFailed,0,0,100000000)+1;actionEvent(a,'result_timeout',`No Forum Manager test result received after ${idleLedgers} idle ledgers and ${idleMs===null?'an unknown wall-clock interval':Math.round(idleMs/1000)+'s'} without worker progress.`,ln,executor,{assignmentSeq:finiteInt(a.assignmentSeq,0,0,1000000)});}
    else{a.failedExecutors=Array.from(new Set([...(a.failedExecutors||[]),executor].filter(Boolean)));a.executor=null;a.status='pending';state.totals.moderationTimeouts=finiteInt(state.totals.moderationTimeouts,0,0,100000000)+1;actionEvent(a,'result_timeout',`No manager result after ${idleLedgers} idle ledgers and ${idleMs===null?'an unknown wall-clock interval':Math.round(idleMs/1000)+'s'} without worker progress. Executor excluded after a short reconciliation grace.`,ln,executor,{assignmentSeq:finiteInt(a.assignmentSeq,0,0,1000000)});const c=a.caseId?state.moderationCases[a.caseId]:null;if(c){c.status='action_pending';c.actionStatus='pending';c.executor=null;}}
    a.updatedLedger=ln;
  }
  const assigned=chooseActionExecutor(state,ctx,config); state.moderationRuntime.lastHeartbeatLedger=ln; writeJson(STATE_FILE,state);
  // Real moderation executes inline on the elected manager. Detached children are
  // not reliable under HotPocket because the contract invocation may terminate
  // its child process tree. The sanitized result is buffered in node-local
  // Custom Data and broadcast at the start of the next moderation round.
  const inlineTarget=assigned&&assigned.executor===self?assigned:Object.values(state.moderationActions||{}).map(ensureActionMeta).find(a=>a&&a.status==='assigned'&&a.executor===self);
  if(inlineTarget){
    if(isWhitelistedIdentity(inlineTarget,config)){inlineTarget.status='cancelled';inlineTarget.executor=null;inlineTarget.updatedLedger=ln;actionEvent(inlineTarget,'whitelist_cancelled','Inline execution refused because the user is on the ForumGuard whitelist.',ln,self);writeJson(STATE_FILE,state);}
    else try{await runInlineAssignedAction(inlineTarget,self);}catch(err){
      try{writeLocalManagerRuntime({mode:'inline',diagnostic:sanitizeWorkerDiagnostic({schema:2,workerVersion:APP_VERSION,stage:'worker_failed',actionId:inlineTarget.actionId,assignmentSeq:inlineTarget.assignmentSeq,executor:self,updatedAt:Date.now(),error:safeString(err&&err.message||err,1000),failedStep:'inline_dispatch'})});}catch{}
    }
  }
  // Once consensus has handled the buffered result, remove only the private
  // runtime cache while keeping the manager credentials intact.
  try{const rt=readLocalManagerRuntime(),rr=sanitizeWorkerResult(rt.result);if(rr){const final=ensureActionMeta(state.moderationActions[rr.actionId]);if(final&&finiteInt(final.handledResultSeq,0,0,1000000)>=finiteInt(rr.assignmentSeq,0,0,1000000)&&final.status!=='assigned')clearLocalManagerRuntime();}}catch{}
}
function send(user, payload) {
  if (runtime && runtime.bson) return user.send(runtime.bson.serialize(payload));
  return user.send(JSON.stringify(payload));
}

function ensureFiles() {
  if (!fs.existsSync(CONFIG_FILE)) writeJson(CONFIG_FILE, defaultConfig());
  if (!fs.existsSync(STATE_FILE)) writeJson(STATE_FILE, initialState());
}

function snapshot(options = {}) {
  const config = loadConfig();
  const state = loadState();
  const leaderboardLimit = finiteInt(options.leaderboardLimit, 100, 1, 500);
  const eventLimit = finiteInt(options.eventLimit, 100, 1, 1000);
  const leaderboard = Object.values(state.users)
    .map(user => {
      const posts = Math.max(0, finiteInt(user.scoredPosts, 0, 0, 100000000));
      const total = finiteInt(user.score, 0, -1000000000, 1000000000);
      return { ...user, averageScore: posts > 0 ? Math.round((total / posts) * 10) / 10 : 0 };
    })
    .sort((a, b) => Number(b.score || 0) - Number(a.score || 0) || String(a.username || '').localeCompare(String(b.username || '')))
    .slice(0, leaderboardLimit);
  return {
    engine: { name: APP_NAME, version: APP_VERSION },
    config, totals: state.totals, sourceStatus: state.sourceStatus, feedPreview: state.feedPreview,
    trackedPosts: Object.keys(state.posts).length, trackedUsers: Object.keys(state.users).length,
    spamPosts: Object.values(state.posts).filter(p => p && p.isSpam === true).length,
    clusterScoring: {expectedVoters:state.clusterScoring?.expectedVoters||[],expectedCount:(state.clusterScoring?.expectedVoters||[]).length,lastVoteLedger:state.clusterScoring?.lastVoteLedger||0,votesApplied:state.clusterScoring?.votesApplied||0,scoreModeVotes:Object.entries(state.clusterScoring?.scoreModeVotes||{}).map(([publicKey,v])=>({publicKey,useClusterScore:v?.useClusterScore===true,ledger:v?.ledger||0})).sort((a,b)=>a.publicKey.localeCompare(b.publicKey)),ballotsReceived:Number(state.clusterScoring?.ballotsReceived||0),clusterModeYes:Number(state.clusterScoring?.clusterModeYes||0),clusterModeRequired:Number(state.clusterScoring?.clusterModeRequired||0),clusterModeActive:state.clusterScoring?.clusterModeActive===true,effectiveBasis:state.clusterScoring?.clusterModeActive===true?'cluster':'state',consensusThresholdPercent:Number(state.clusterScoring?.consensusThresholdPercent||80),quorumSource:state.clusterScoring?.quorumSource||'hotpocket-consensus-threshold'},
    recentPosts: Object.entries(state.posts).sort((a,b)=>finiteInt(b[1]?.lastLedger,0)-finiteInt(a[1]?.lastLedger,0)||a[0].localeCompare(b[0])).slice(0,200).map(([postKey,p])=>({postKey,source:p.source,postId:p.postId,userId:p.userId,username:p.username,link:p.link,text:safeString(p.text,1200),lastLedger:p.lastLedger,maxScore:p.maxScore,stateScore:Number(p.stateScore??p.score??0),stateIsSpam:p.stateIsSpam===true,clusterScore:p.clusterScore,clusterVoteCount:Number(p.clusterVoteCount||0),clusterExpectedCount:Number(p.clusterExpectedCount||0),clusterComplete:p.clusterComplete===true,effectiveScore:Number(p.effectiveScore??p.stateScore??p.score??0),effectiveScoreBasis:p.effectiveScoreBasis||'state',isSpam:p.isSpam===true,whitelisted:p.whitelisted===true,clusterVotes:Object.entries(p.clusterVotes||{}).filter(([,v])=>v&&v.contentHash===p.contentHash).map(([publicKey,v])=>({publicKey,score:Number(v.score||0),maxScore:Number(v.maxScore||100),eligible:v.eligible!==false,rulesHash:v.rulesHash||'',ledger:v.ledger||0})).sort((a,b)=>a.publicKey.localeCompare(b.publicKey))})),
    moderation: {
      cases: Object.values(state.moderationCases||{}).sort((a,b)=>finiteInt(b.lastLedger,0)-finiteInt(a.lastLedger,0)).slice(0,500),
      actions: Object.values(state.moderationActions||{}).map(a=>actionDiagnostic(state,config,a)).sort((a,b)=>finiteInt(b.updatedLedger||b.createdLedger,0)-finiteInt(a.updatedLedger||a.createdLedger,0)).slice(0,500),
      managers: Object.values(state.managerRegistry||{}).map(m=>({...m,active:(Math.max(finiteInt(state.lastLedger,0),finiteInt(state.moderationRuntime?.lastHeartbeatLedger,0))-finiteInt(m.lastSeenLedger,0))<=config.moderation.manager.staleAfterLedgers})).sort((a,b)=>(b.active===true)-(a.active===true)||finiteInt(a.priority,999999)-finiteInt(b.priority,999999)||String(a.publicKey).localeCompare(String(b.publicKey)))
    },
    lastLedger: state.lastLedger, leaderboard, recentEvents: state.recentEvents.slice(-eventLimit).reverse()
  };
}
function setConfig(input) { ensureFiles(); const next = normalizeConfig(input || {}); writeJson(CONFIG_FILE, next); try{const state=loadState();applyWhitelistProtection(state,next,{lclSeqNo:state.lastLedger||0});for(const p of Object.values(state.posts||{})){if(p)p.whitelisted=isWhitelistedIdentity(p,next);}writeJson(STATE_FILE,state);}catch{} return next; }
function resetState() { const next = initialState(); writeJson(STATE_FILE, next); try { fs.writeFileSync(EVENT_FILE, ''); } catch {} return next; }
function markAllDue() { const state=loadState(); for(const status of Object.values(state.sourceStatus||{})) if(status&&typeof status==='object') status.lastAttemptAtMs=0; writeJson(STATE_FILE,state); }
async function fetchNow(ctx) { ensureFiles(); markAllDue(); const state=loadState(), config=loadConfig(); await fetchDueSources(ctx,state,config); return snapshot({leaderboardLimit:200,eventLimit:200}); }
async function maintenance(ctx) { ensureFiles(); if(ctx.readonly)return; const state=loadState(), config=loadConfig(); await fetchDueSources(ctx,state,config); }
module.exports={APP_NAME,APP_VERSION,snapshot,setConfig,resetState,fetchNow,maintenance,isFetchDue,isModerationDue,moderationMaintenance,moderationCommand,queueForumManagerTest,testLocalForumManager,getLocalManagerStatus,saveLocalManager,clearLocalManager,localManagerStorage,getLocalIndividualScoring,workerRuntimeStatus,inspectLocalWorkerRuntime,_test:{parseFeed,parseAtom,parseRss,stripMarkup,normalizeConfig,normalizeScoreRule,normalizeEntryId,extractQueryId,scorePost,passesFilters,processPosts,ensureActionMeta,actionDiagnostic,actionEvent,applyManagerResult,chooseActionExecutor,sanitizeWorkerResult,sanitizeWorkerDiagnostic,applyWorkerDiagnostic,spawnLocalAction,runInlineAssignedAction,workerPaths,workerRuntimeStatus,inspectLocalWorkerRuntime,testLocalForumManager,normalizeLocalScoring,isWhitelistedIdentity,refreshPostClusterScore,scoreModeConsensusQuorum,clusterScoringModeSummary,refreshClusterScoringMode,buildLocalClusterVote,applyClusterVoteMessage,moderationScoreView}};

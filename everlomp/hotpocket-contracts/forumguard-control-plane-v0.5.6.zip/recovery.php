<?php
declare(strict_types=1);

// ForumGuard: never leak PHP warnings/notices into JSON API responses.
@ini_set('display_errors', '0');
@ini_set('html_errors', '0');
$__forumguardResponseSent = false;
register_shutdown_function(static function () use (&$__forumguardResponseSent): void {
    if ($__forumguardResponseSent) return;
    $last = error_get_last();
    if (!is_array($last) || !in_array((int)($last['type'] ?? 0), [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) return;
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, max-age=0');
        http_response_code(500);
    }
    echo json_encode([
        'ok' => false,
        'error' => 'ForumGuard recovery fatal: ' . (string)($last['message'] ?? 'unknown PHP fatal error'),
        'file' => basename((string)($last['file'] ?? '')),
        'line' => (int)($last['line'] ?? 0),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
});

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept, X-Admin-Key-Envelope');
header('Access-Control-Max-Age: 600');
if (strtolower((string)($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_PRIVATE_NETWORK'] ?? '')) === 'true') {
    header('Access-Control-Allow-Private-Network: true');
}
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const RECOVERY_PROTOCOL = 'everadmin-recovery-v1';
const SIGNER_ENVELOPE_PREFIX = 'evadmin:v1:';
const SIGNER_OTP_DIGITS = 24;
const SIGNER_OTP_WINDOW_STEPS = 5;
const TOTP_STEP_SECONDS = 30;
const MAX_BODY_BYTES = 131072;
const MAX_PAYLOAD_BYTES = 65536;
const MAX_LOG_BYTES = 196608;
const MAX_CLOCK_SKEW_MS = 120000;
const CHALLENGE_TTL_MS = 300000;
const RECOVERY_TOKEN_TTL_MS = 600000;

function respond(int $status, array $payload): never {
    global $__forumguardResponseSent;
    $__forumguardResponseSent = true;
    http_response_code($status);
    $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    echo is_string($encoded) ? $encoded : '{"ok":false,"error":"Could not encode recovery response."}';
    exit;
}

function now_ms(): int { return (int) floor(microtime(true) * 1000); }
function clean_public_key(mixed $value): ?string {
    $key = strtolower(trim((string) $value));
    if (preg_match('/^ed[0-9a-f]{64}$/', $key) === 1) return $key;
    if (preg_match('/^[0-9a-f]{64}$/', $key) === 1) return 'ed' . $key;
    return null;
}
function valid_guid(mixed $value): ?string {
    $id = strtolower(trim((string) $value));
    return preg_match('/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/', $id) === 1 ? $id : null;
}
function valid_peer(mixed $value): ?string {
    $peer = trim((string) $value);
    if ($peer === '' || strlen($peer) > 320 || preg_match('/\s|[\/?#]/', $peer) === 1 || str_contains($peer, '://')) return null;
    if (str_starts_with($peer, '[')) {
        if (preg_match('/^\[([0-9a-fA-F:]+)\]:(\d{1,5})$/', $peer, $m) !== 1) return null;
        if (filter_var($m[1], FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false) return null;
        $port = (int) $m[2];
        return $port >= 1 && $port <= 65535 ? '[' . strtolower($m[1]) . ']:' . $port : null;
    }
    $pos = strrpos($peer, ':');
    if ($pos === false || strpos($peer, ':') !== $pos) return null;
    $host = strtolower(trim(substr($peer, 0, $pos)));
    $port = (int) substr($peer, $pos + 1);
    if ($host === '' || $port < 1 || $port > 65535) return null;
    $isIp = filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
    $isHost = preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/', $host) === 1;
    return ($isIp || $isHost) ? $host . ':' . $port : null;
}
function read_json_file(string $path): ?array {
    if (!is_file($path) || is_link($path) || !is_readable($path)) return null;
    $raw = file_get_contents($path);
    if ($raw === false) return null;
    $value = json_decode($raw, true);
    return is_array($value) ? $value : null;
}
function atomic_json_write(string $path, array $value): void {
    $dir = dirname($path);
    if (!is_dir($dir) || is_link($dir) || !is_writable($dir)) {
        throw new RuntimeException('Target directory is not writable by the web listener: ' . $dir);
    }
    try {
        $encoded = json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . "\n";
    } catch (Throwable $e) {
        throw new RuntimeException('Could not encode Forum Manager settings: ' . $e->getMessage());
    }
    $tmp = $dir . '/.' . basename($path) . '.' . bin2hex(random_bytes(6)) . '.tmp';
    $written = @file_put_contents($tmp, $encoded, LOCK_EX);
    if ($written === false || $written !== strlen($encoded)) {
        $err = error_get_last();
        @unlink($tmp);
        throw new RuntimeException('Could not stage node-local settings' . (is_array($err) && !empty($err['message']) ? ': ' . $err['message'] : '.'));
    }
    @chmod($tmp, 0600);
    if (!@rename($tmp, $path)) {
        $err = error_get_last();
        @unlink($tmp);
        throw new RuntimeException('Could not publish node-local settings' . (is_array($err) && !empty($err['message']) ? ': ' . $err['message'] : '.'));
    }
    @chmod($path, 0600);
}


function normalize_forum_admin_path(mixed $value): string {
    $path = trim((string) $value);
    if ($path === '') return 'adm/';
    if (strlen($path) > 160) throw new InvalidArgumentException('phpBB ACP path is too long.');
    if (str_contains($path, "\0") || str_contains($path, '?') || str_contains($path, '#') || str_contains($path, '\\') || str_contains($path, '://')) {
        throw new InvalidArgumentException('phpBB ACP path must be a relative path such as adm/.');
    }
    $path = trim($path, '/');
    if ($path === '') throw new InvalidArgumentException('phpBB ACP path is invalid.');
    foreach (explode('/', $path) as $segment) {
        if ($segment === '' || $segment === '.' || $segment === '..' || preg_match('/^[A-Za-z0-9._-]+$/D', $segment) !== 1) {
            throw new InvalidArgumentException('phpBB ACP path contains an invalid path segment.');
        }
    }
    return $path . '/';
}
function forum_manager_file_candidates(): array {
    $derivedParent = realpath(__DIR__ . '/..');
    if ($derivedParent === false) $derivedParent = dirname(__DIR__);
    $candidates = [
        $derivedParent . '/forum-manager.json',
        $derivedParent . '/restart-hotpocket.queue/.forum-manager.private',
        '/contract/contract_fs/mnt/rw/forum-manager.json',
        '/contract/contract_fs/mnt/rw/restart-hotpocket.queue/.forum-manager.private',
        '/contract/contract_fs/seed/forum-manager.json',
        '/contract/contract_fs/seed/restart-hotpocket.queue/.forum-manager.private',
    ];
    return array_values(array_unique($candidates));
}
function forum_manager_existing_file(): ?string {
    foreach (forum_manager_file_candidates() as $path) {
        if (is_file($path) && !is_link($path) && is_readable($path)) return $path;
    }
    return null;
}
function forum_manager_probe_directory(string $dir): array {
    $result = [
        'directory' => $dir,
        'exists' => is_dir($dir),
        'isLink' => is_link($dir),
        'isWritable' => is_dir($dir) && !is_link($dir) && is_writable($dir),
        'probeWrite' => false,
        'error' => null,
    ];
    if (!$result['isWritable']) return $result;
    try {
        $probe = $dir . '/.forumguard-write-probe-' . bin2hex(random_bytes(4));
        $ok = @file_put_contents($probe, "ok\n", LOCK_EX);
        if ($ok === false) {
            $err = error_get_last();
            $result['error'] = is_array($err) ? (string)($err['message'] ?? 'probe write failed') : 'probe write failed';
            return $result;
        }
        $result['probeWrite'] = true;
        @unlink($probe);
    } catch (Throwable $e) {
        $result['error'] = $e->getMessage();
    }
    return $result;
}
function forum_manager_storage_diagnostics(): array {
    $out = [];
    foreach (forum_manager_file_candidates() as $path) {
        $dir = dirname($path);
        $probe = forum_manager_probe_directory($dir);
        $out[] = [
            'path' => $path,
            'fileExists' => is_file($path),
            'fileReadable' => is_file($path) && is_readable($path),
            'fileWritable' => is_file($path) && is_writable($path),
            'directory' => $probe['directory'],
            'directoryExists' => $probe['exists'],
            'directoryWritable' => $probe['isWritable'],
            'probeWrite' => $probe['probeWrite'],
            'probeError' => $probe['error'],
        ];
    }
    return $out;
}
function forum_manager_writable_file(): ?string {
    // Prefer the existing readable file when its directory passes an actual write probe.
    $existing = forum_manager_existing_file();
    if ($existing !== null) {
        $probe = forum_manager_probe_directory(dirname($existing));
        if (($probe['probeWrite'] ?? false) === true) return $existing;
    }
    foreach (forum_manager_file_candidates() as $path) {
        $probe = forum_manager_probe_directory(dirname($path));
        if (($probe['probeWrite'] ?? false) === true) return $path;
    }
    return null;
}

function forum_manager_storage_label(?string $path): string {
    if ($path === null || $path === '') return 'unavailable';
    $stateParent = realpath(__DIR__ . '/..');
    if ($stateParent !== false && str_starts_with($path, $stateParent . '/')) return '../' . substr($path, strlen($stateParent) + 1);
    return $path;
}
function tail_file(string $path, int $maxBytes = MAX_LOG_BYTES): array {
    if (!is_file($path) || is_link($path) || !is_readable($path)) return ['available' => false, 'path' => $path, 'content' => ''];
    $size = filesize($path); if ($size === false) $size = 0;
    $read = min(max(0, $size), $maxBytes); $fh = fopen($path, 'rb');
    if ($fh === false) return ['available' => false, 'path' => $path, 'content' => ''];
    if ($size > $read) fseek($fh, -$read, SEEK_END);
    $data = $read > 0 ? fread($fh, $read) : ''; fclose($fh); if ($data === false) $data = '';
    return ['available' => true, 'path' => $path, 'size' => $size, 'truncated' => $size > $read, 'content' => $data];
}

function restart_request_candidates(): array {
    $candidates = [
        '/contract/contract_fs/seed/restart-hotpocket.request',
        '/contract/contract_fs/mnt/rw/restart-hotpocket.request',
    ];
    $derived = realpath(__DIR__ . '/..');
    if ($derived !== false) $candidates[] = $derived . '/restart-hotpocket.request';
    return array_values(array_unique($candidates));
}
function restart_queue_dir_candidates(): array {
    return [
        '/contract/contract_fs/seed/restart-hotpocket.queue',
        '/contract/contract_fs/mnt/rw/restart-hotpocket.queue',
    ];
}
function choose_restart_queue_path(string $requestId): ?string {
    if (preg_match('/^[0-9a-f]{32}$/', $requestId) !== 1) throw new RuntimeException('Invalid restart request ID.');
    foreach (restart_queue_dir_candidates() as $dir) {
        if (is_link($dir)) continue;
        if (!is_dir($dir)) {
            $parent = dirname($dir);
            if (!is_dir($parent) || !is_writable($parent) || !@mkdir($dir, 0775, true)) continue;
        }
        if (is_dir($dir) && !is_link($dir) && is_writable($dir)) return $dir . '/' . $requestId . '.json';
    }
    return null;
}
function restart_status_candidates(): array {
    return [
        '/contract/contract_fs/seed/restart-hotpocket.status.json',
        '/contract/contract_fs/mnt/rw/restart-hotpocket.status.json',
        '/contract/contract_fs/restart-hotpocket.status.json',
    ];
}

function restart_audit_candidates(string $kind): array {
    $name = match ($kind) {
        'last-request' => 'restart-hotpocket.last-request.json',
        'last-consumed' => 'restart-hotpocket.last-consumed.json',
        'last-result' => 'restart-hotpocket.last-result.json',
        default => throw new InvalidArgumentException('Unsupported restart audit kind.'),
    };
    return [
        '/contract/contract_fs/seed/' . $name,
        '/contract/contract_fs/mnt/rw/' . $name,
        '/contract/contract_fs/' . $name,
    ];
}
function read_latest_json_candidates(array $paths): ?array {
    $best = null; $bestMtime = -1;
    foreach ($paths as $path) {
        $value = read_json_file($path); if ($value === null) continue;
        $mtime = @filemtime($path); if ($mtime === false) $mtime = 0;
        if ($best === null || $mtime >= $bestMtime) {
            $best = $value; $best['_path'] = $path; $best['_mtime'] = $mtime; $bestMtime = $mtime;
        }
    }
    return $best;
}
function write_restart_request(string $path, array $request): array {
    $encoded = json_encode($request, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
    $bytes = strlen($encoded); $sha256 = hash('sha256', $encoded); $writtenAt = now_ms();
    atomic_json_write($path, $request);
    $requestDir = dirname($path);
    // Queue directories are deliberately owned by the web/PHP worker while the seed parent
    // remains root-owned. Keep the immediate PHP write receipt inside the queue. The root
    // watcher mirrors a persistent restart-hotpocket.last-request.json into seed when it
    // receives the request.
    $auditPath = basename($requestDir) === 'restart-hotpocket.queue'
        ? $requestDir . '/.last-request.web.json'
        : $requestDir . '/restart-hotpocket.last-request.json';
    atomic_json_write($auditPath, [
        'schemaVersion' => 1,
        'writtenAt' => $writtenAt,
        'requestPath' => $path,
        'bytes' => $bytes,
        'sha256' => $sha256,
        'requestId' => $request['requestId'] ?? null,
        'request' => $request,
    ]);
    clearstatcache(true, $path); clearstatcache(true, $auditPath);
    $requestExists = is_file($path);
    $requestMtime = $requestExists ? @filemtime($path) : false;
    $auditMtime = @filemtime($auditPath);
    return [
        'requestId' => $request['requestId'] ?? null,
        'requestPath' => $path,
        'auditPath' => $auditPath,
        'bytes' => $bytes,
        'sha256' => $sha256,
        'writtenAt' => $writtenAt,
        'requestExistsAfterWrite' => $requestExists,
        'requestMtime' => $requestMtime === false ? null : $requestMtime,
        'auditMtime' => $auditMtime === false ? null : $auditMtime,
    ];
}
function wait_for_consumed(string $requestId, int $timeoutMs = 1600): ?array {
    $deadline = microtime(true) + ($timeoutMs / 1000);
    do {
        $rec = read_latest_json_candidates(restart_audit_candidates('last-consumed'));
        $seen = trim((string)($rec['requestId'] ?? ($rec['request']['requestId'] ?? '')));
        if ($rec !== null && $seen !== '' && hash_equals($requestId, $seen)) return $rec;
        usleep(100000);
    } while (microtime(true) < $deadline);
    return null;
}
function read_watcher_status(): ?array {
    $best = null; $bestMtime = -1;
    foreach (restart_status_candidates() as $path) {
        $value = read_json_file($path); if ($value === null) continue;
        $mtime = @filemtime($path); if ($mtime === false) $mtime = 0;
        if ($best === null || $mtime >= $bestMtime) { $best = $value; $best['_statusPath'] = $path; $best['_statusMtime'] = $mtime; $bestMtime = $mtime; }
    }
    return $best;
}
function choose_restart_request_path(?string $requestId = null, bool $preferQueue = false): string {
    if ($preferQueue && $requestId !== null) {
        $queued = choose_restart_queue_path($requestId);
        if ($queued !== null) return $queued;
    }
    foreach (restart_request_candidates() as $path) {
        $dir = dirname($path);
        if (is_dir($dir) && is_writable($dir)) return $path;
    }
    throw new RuntimeException('No restart inbox is writable by recovery.php. Repair/install watcher v7 so it creates a private web-owned restart-hotpocket.queue.');
}
function path_write_diagnostic(string $path): array {
    $exists = file_exists($path); $dir = is_dir($path) ? $path : dirname($path);
    $owner = $exists ? @fileowner($path) : (@is_dir($dir) ? @fileowner($dir) : false);
    $group = $exists ? @filegroup($path) : (@is_dir($dir) ? @filegroup($dir) : false);
    $perms = $exists ? @fileperms($path) : (@is_dir($dir) ? @fileperms($dir) : false);
    return [
        'path' => $path,
        'exists' => $exists,
        'directory' => $dir,
        'directoryExists' => is_dir($dir),
        'writable' => is_writable($path) || (is_dir($dir) && is_writable($dir)),
        'ownerUid' => $owner === false ? null : $owner,
        'groupGid' => $group === false ? null : $group,
        'mode' => $perms === false ? null : substr(sprintf('%o', $perms), -4),
    ];
}
function restart_writer_diagnostics(): array {
    $uid = function_exists('posix_geteuid') ? @posix_geteuid() : null;
    $gid = function_exists('posix_getegid') ? @posix_getegid() : null;
    return [
        'phpEffectiveUid' => is_int($uid) ? $uid : null,
        'phpEffectiveGid' => is_int($gid) ? $gid : null,
        'queues' => array_map('path_write_diagnostic', restart_queue_dir_candidates()),
        'mailboxes' => array_map('path_write_diagnostic', restart_request_candidates()),
    ];
}

function fixed_watcher_install(): array {
    $sudo = '/usr/bin/sudo'; $installer = '/usr/local/sbin/everadmin-restart-watcher-setup';
    if (!is_file($sudo) || !is_executable($sudo)) return ['attempted'=>false,'ok'=>false,'error'=>'sudo is unavailable'];
    if (!is_file($installer) || !is_executable($installer)) return ['attempted'=>false,'ok'=>false,'error'=>'EverAdmin watcher installer is unavailable at /usr/local/sbin/everadmin-restart-watcher-setup'];
    if (!function_exists('proc_open')) return ['attempted'=>false,'ok'=>false,'error'=>'PHP proc_open is disabled; watcher cannot be bootstrapped automatically'];
    $spec=[1=>['pipe','w'],2=>['pipe','w']];
    $proc=@proc_open([$sudo,'-n',$installer,'install'],$spec,$pipes,null,null,['bypass_shell'=>true]);
    if (!is_resource($proc)) return ['attempted'=>true,'ok'=>false,'error'=>'Could not start fixed watcher installer'];
    $stdout=stream_get_contents($pipes[1]); fclose($pipes[1]); $stderr=stream_get_contents($pipes[2]); fclose($pipes[2]);
    $code=proc_close($proc); $output=trim(($stdout?:'') . (($stderr?:'')!==''?"
".$stderr:''));
    return ['attempted'=>true,'ok'=>$code===0,'returnCode'=>$code,'output'=>substr($output,-12000),'error'=>$code===0?null:('Watcher installer exited with code '.$code)];
}
function ensure_watcher_running(bool $allowInstall): array {
    $status = read_watcher_status();
    $isFresh = static function(?array $value): bool {
        if ($value === null) return false;
        $mtime = (int)($value['_statusMtime']??0); if ($mtime <= 0) return true;
        return (time() - $mtime) <= 30;
    };
    if ($isFresh($status)) return ['ready'=>true,'status'=>$status,'install'=>null];
    $install = null;
    if ($allowInstall) {
        $install = fixed_watcher_install();
        if (($install['ok']??false) === true) {
            $deadline = microtime(true) + 4.0;
            do { usleep(200000); $status = read_watcher_status(); if ($isFresh($status)) break; } while (microtime(true) < $deadline);
        }
    }
    return ['ready'=>$isFresh($status),'status'=>$status,'install'=>$install];
}
function recovery_log(string $name): array {
    $map = [
        'hp' => '/contract/log/hp.log',
        'contract-stdout' => '/contract/log/contract/rw.stdout.log',
        'contract-stderr' => '/contract/log/contract/rw.stderr.log',
    ];
    $key = strtolower(trim($name)); if (!isset($map[$key])) $key = 'hp';
    return ['name'=>$key] + tail_file($map[$key]);
}
function hp_config_summary(): array {
    $path = '/contract/cfg/hp.cfg'; $cfg = read_json_file($path);
    if ($cfg === null) return ['available' => false, 'path' => $path];
    $contract = is_array($cfg['contract'] ?? null) ? $cfg['contract'] : [];
    $mesh = is_array($cfg['mesh'] ?? null) ? $cfg['mesh'] : [];
    $node = is_array($cfg['node'] ?? null) ? $cfg['node'] : $cfg;
    $discovery = is_array($mesh['peer_discovery'] ?? null) ? $mesh['peer_discovery'] : [];
    return ['available'=>true,'path'=>$path,'contractId'=>valid_guid($contract['id'] ?? null),'localNodePublicKey'=>clean_public_key($node['public_key'] ?? ($node['publicKey'] ?? null)),'unl'=>array_values(array_filter(array_map('clean_public_key', is_array($contract['unl'] ?? null) ? $contract['unl'] : []))),'knownPeers'=>array_values(array_filter(array_map('strval', is_array($mesh['known_peers'] ?? null) ? $mesh['known_peers'] : []))),'peerDiscoveryEnabled'=>($discovery['enabled'] ?? true) !== false];
}
function use_nonce_once(string $nonce, int $timestamp): bool {
    $scope = hash('sha256', (string) realpath(__DIR__));
    $file = sys_get_temp_dir() . '/everadmin-recovery-nonces-' . substr($scope, 0, 20) . '.json';
    $fh = fopen($file, 'c+'); if ($fh === false) return false;
    try {
        if (!flock($fh, LOCK_EX)) return false;
        $raw = stream_get_contents($fh); $data = json_decode($raw ?: '{}', true); if (!is_array($data)) $data = [];
        $cutoff = now_ms() - 10 * 60 * 1000;
        foreach ($data as $key => $usedAt) if ((int) $usedAt < $cutoff) unset($data[$key]);
        if (array_key_exists($nonce, $data)) return false;
        $data[$nonce] = $timestamp; rewind($fh); ftruncate($fh, 0); fwrite($fh, json_encode($data)); fflush($fh); return true;
    } finally { flock($fh, LOCK_UN); fclose($fh); }
}

function challenge_file(): string {
    $scope = hash('sha256', (string) realpath(__DIR__));
    return sys_get_temp_dir() . '/everadmin-recovery-challenges-' . substr($scope, 0, 20) . '.json';
}
function mutate_challenges(callable $fn): mixed {
    $file = challenge_file(); $fh = fopen($file, 'c+'); if ($fh === false) throw new RuntimeException('Recovery challenge store is unavailable.');
    @chmod($file, 0600);
    try {
        if (!flock($fh, LOCK_EX)) throw new RuntimeException('Could not lock recovery challenge store.');
        rewind($fh); $raw = stream_get_contents($fh); $all = json_decode($raw ?: '{}', true); if (!is_array($all)) $all = [];
        $cutoff = now_ms() - max(CHALLENGE_TTL_MS, RECOVERY_TOKEN_TTL_MS) - 60000;
        foreach ($all as $id => $rec) if (!is_array($rec) || (int)($rec['createdAt'] ?? 0) < $cutoff) unset($all[$id]);
        $result = $fn($all);
        rewind($fh); ftruncate($fh, 0); fwrite($fh, json_encode($all, JSON_UNESCAPED_SLASHES)); fflush($fh);
        return $result;
    } finally { flock($fh, LOCK_UN); fclose($fh); }
}
function get_challenge(string $challenge): ?array {
    return mutate_challenges(function(array &$all) use ($challenge) { return isset($all[$challenge]) && is_array($all[$challenge]) ? $all[$challenge] : null; });
}
function recovery_request_url(string $challenge): string {
    $forwarded = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')));
    $scheme = in_array($forwarded, ['http','https'], true) ? $forwarded : ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http');
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '' || preg_match('/^[a-zA-Z0-9.\-:\[\]]+$/', $host) !== 1) throw new RuntimeException('Recovery listener host is unavailable.');
    $path = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/recovery.php'), PHP_URL_PATH) ?: '/recovery.php';
    return $scheme . '://' . $host . $path . '?challenge=' . rawurlencode($challenge);
}

function b64url_decode_str(string $value): string|false {
    $s = strtr(trim($value), '-_', '+/'); $s .= str_repeat('=', (4 - strlen($s) % 4) % 4); return base64_decode($s, true);
}
function base32_decode_bytes(string $value): string|false {
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $clean=strtoupper(preg_replace('/\s+/', '', rtrim($value, '=')) ?? '');
    if ($clean === '' || preg_match('/^[A-Z2-7]+$/', $clean) !== 1) return false;
    $bits=''; foreach (str_split($clean) as $ch) { $idx=strpos($alphabet,$ch); if ($idx===false) return false; $bits.=str_pad(decbin($idx),5,'0',STR_PAD_LEFT); }
    $out=''; for($i=0;$i+8<=strlen($bits);$i+=8)$out.=chr(bindec(substr($bits,$i,8))); return $out;
}
function otp24_from_hmac(string $mac): string {
    $base=100000000; $limbs=[0,0,0];
    foreach (unpack('C*',$mac) as $byte) { $carry=(int)$byte; for($i=0;$i<3;$i++){ $v=$limbs[$i]*256+$carry; $limbs[$i]=$v%$base; $carry=intdiv($v,$base); } }
    return str_pad((string)$limbs[2],8,'0',STR_PAD_LEFT).str_pad((string)$limbs[1],8,'0',STR_PAD_LEFT).str_pad((string)$limbs[0],8,'0',STR_PAD_LEFT);
}
function signer_otp_code(string $secret, int $timeMs): ?string {
    $key=base32_decode_bytes($secret); if ($key===false) return null; $counter=intdiv($timeMs,1000*TOTP_STEP_SECONDS);
    $hi=intdiv($counter, 4294967296); $lo=$counter % 4294967296; $buf=pack('N2',$hi,$lo); $mac=hash_hmac('sha256',$buf,$key,true); return otp24_from_hmac($mac);
}
function signer_otp_candidates(string $secret, int $timeMs): array {
    $out=[]; for($i=-SIGNER_OTP_WINDOW_STEPS;$i<=SIGNER_OTP_WINDOW_STEPS;$i++){ $c=signer_otp_code($secret,$timeMs+$i*TOTP_STEP_SECONDS*1000); if($c!==null)$out[$c]=true; } return array_keys($out);
}
function normalize_private_and_public(string $value): array {
    if (!function_exists('sodium_crypto_sign_seed_keypair')) throw new RuntimeException('PHP sodium support is required for EV Signer recovery.');
    $raw=strtolower(trim($value));
    if (str_starts_with($raw,'ed') && (strlen($raw)===66 || strlen($raw)===130)) $raw=substr($raw,2);
    if (preg_match('/^[0-9a-f]+$/',$raw)!==1 || !in_array(strlen($raw),[64,128],true)) throw new RuntimeException('Signer private key must be a 64-hex seed or 128-hex HotPocket private key.');
    $seed=hex2bin(substr($raw,0,64)); if($seed===false) throw new RuntimeException('Invalid signer private key.');
    $kp=sodium_crypto_sign_seed_keypair($seed); $pub=sodium_crypto_sign_publickey($kp); $secret=sodium_crypto_sign_secretkey($kp);
    if(strlen($raw)===128 && !hash_equals(substr($raw,64),bin2hex($pub))) throw new RuntimeException('Signer private key seed/public-key half mismatch.');
    return ['privateKey'=>'ed'.bin2hex($secret),'publicKey'=>'ed'.bin2hex($pub)];
}
function parse_signer_envelope(string $input): array {
    $raw=trim($input); if(!str_starts_with($raw,SIGNER_ENVELOPE_PREFIX)) throw new RuntimeException('Invalid EV Signer envelope prefix.');
    $decoded=b64url_decode_str(substr($raw,strlen(SIGNER_ENVELOPE_PREFIX))); if($decoded===false) throw new RuntimeException('Invalid EV Signer envelope encoding.');
    $e=json_decode($decoded,true); if(!is_array($e)||($e['v']??null)!==1||($e['type']??'')!=='otp-encrypted-admin-private-key'||($e['alg']??'')!=='aes-256-gcm'||($e['kdf']??'')!=='pbkdf2-sha256') throw new RuntimeException('Unsupported EV Signer envelope.');
    foreach(['salt','iv','authTag','ciphertext','iterations'] as $f) if(empty($e[$f])) throw new RuntimeException('EV Signer envelope missing '.$f.'.');
    return $e;
}
function decrypt_signer_envelope(string $secret,string $input,int $timeMs): string {
    $e=parse_signer_envelope($input); $salt=base64_decode((string)$e['salt'],true); $iv=base64_decode((string)$e['iv'],true); $tag=base64_decode((string)$e['authTag'],true); $cipher=base64_decode((string)$e['ciphertext'],true); $iterations=(int)$e['iterations'];
    if($salt===false||$iv===false||$tag===false||$cipher===false||strlen($salt)<8||strlen($iv)!==12||strlen($tag)!==16||$cipher===''||$iterations<100000||$iterations>2000000) throw new RuntimeException('Invalid EV Signer envelope fields.');
    foreach(signer_otp_candidates($secret,$timeMs) as $code){ $key=hash_pbkdf2('sha256','otp-admin-envelope-v1:'.$code,$salt,$iterations,32,true); $plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag); if($plain!==false&&trim($plain)!=='')return trim($plain); }
    throw new RuntimeException('Envelope did not match the current signer OTP window.');
}
function verify_head_admin_signer(array $state,string $envelope,int $timeMs): array {
    $users=is_array($state['users']??null)?$state['users']:[]; $last=null;
    foreach($users as $id=>$user){
        if(!is_array($user)||($user['active']??true)===false||($user['role']??'')!=='head-admin'||($user['method']??'')!=='everstoring'||empty($user['publicKey'])||empty($user['totpSecret']))continue;
        try { $plain=decrypt_signer_envelope((string)$user['totpSecret'],$envelope,$timeMs); if(str_starts_with($plain,'{')){ $j=json_decode($plain,true); if(is_array($j)&&!empty($j['adminPrivateKey']))$plain=(string)$j['adminPrivateKey']; } $keys=normalize_private_and_public($plain); $pub=clean_public_key($user['publicKey']); if($pub!==null&&hash_equals($pub,$keys['publicKey']))return ['userId'=>(string)($user['id']??$id),'user'=>$user,'publicKey'=>$keys['publicKey']]; }
        catch(Throwable $e){$last=$e;}
    }
    throw new RuntimeException($last?->getMessage() ?: 'EV Signer proof did not match an active OTP-enabled head admin.');
}
function current_head_admin(array $state,string $userId): ?array {
    $users=is_array($state['users']??null)?$state['users']:[]; $u=is_array($users[$userId]??null)?$users[$userId]:null;
    return ($u!==null&&($u['active']??true)!==false&&($u['role']??'')==='head-admin')?$u:null;
}
function auth_from_recovery_token(array $state,string $token,int $now): ?array {
    if(!preg_match('/^[0-9a-f]{64}$/',$token))return null; $hash=hash('sha256',$token);
    return mutate_challenges(function(array &$all) use($state,$hash,$now){ foreach($all as $rec){ if(!is_array($rec)||($rec['status']??'')!=='authorized'||(int)($rec['tokenExpiresAt']??0)<=$now||empty($rec['tokenHash']))continue; if(hash_equals((string)$rec['tokenHash'],$hash)){ $uid=(string)($rec['userId']??''); $u=current_head_admin($state,$uid); if($u!==null)return ['userId'=>$uid,'user'=>$u,'authMethod'=>'ev-signer','devicePublicKey'=>null]; } } return null; });
}

// EV Signer generic HTTPS request: GET is intentionally limited to a random challenge id.
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $challenge=strtolower(trim((string)($_GET['challenge']??'')));
    if(preg_match('/^[0-9a-f]{64}$/',$challenge)!==1)respond(400,['ok'=>false,'error'=>'Invalid recovery signer challenge.']);
    $rec=get_challenge($challenge); $now=now_ms();
    if($rec===null||(int)($rec['expiresAt']??0)<=$now)respond(404,['ok'=>false,'error'=>'Recovery signer challenge expired or was not found.']);
    respond(200,['ok'=>true,'requestId'=>$challenge,'appName'=>'EverAdmin Control Plane','actionName'=>'Authorize head-admin recovery','description'=>'Approve a short-lived head-admin recovery session for this EverAdmin node. No HotPocket consensus is required.','expiresAt'=>$rec['expiresAt']]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(405, ['ok'=>false,'error'=>'GET or POST required.']);
$raw=file_get_contents('php://input',false,null,0,MAX_BODY_BYTES+1); if($raw===false||strlen($raw)>MAX_BODY_BYTES)respond(413,['ok'=>false,'error'=>'Recovery request is too large.']);
$req=json_decode($raw,true); if(!is_array($req))$req=[];
$now=now_ms();
$authPath=__DIR__.'/admin-auth.json'; $state=read_json_file($authPath); if($state===null)respond(503,['ok'=>false,'error'=>'EverAdmin authentication state is unavailable.']);

// EV Signer posts its normal evadmin:v1 envelope to the challenge URL.
$queryChallenge=strtolower(trim((string)($_GET['challenge']??'')));
$headerEnvelope=trim((string)($_SERVER['HTTP_X_ADMIN_KEY_ENVELOPE']??''));
$bodyEnvelope=trim((string)($req['adminEnvelope']??''));
if($queryChallenge!=='' && ($headerEnvelope!=='' || $bodyEnvelope!=='')){
    if(preg_match('/^[0-9a-f]{64}$/',$queryChallenge)!==1)respond(400,['ok'=>false,'error'=>'Invalid recovery signer challenge.']);
    $rec=get_challenge($queryChallenge); if($rec===null||(int)($rec['expiresAt']??0)<=$now)respond(404,['ok'=>false,'error'=>'Recovery signer challenge expired or was not found.']);
    if(($rec['status']??'pending')==='authorized')respond(200,['ok'=>true,'authorized'=>true,'message'=>'This recovery challenge is already authorized.']);
    try { $verified=verify_head_admin_signer($state,$headerEnvelope!==''?$headerEnvelope:$bodyEnvelope,$now); $token=bin2hex(random_bytes(32)); mutate_challenges(function(array &$all) use($queryChallenge,$verified,$token,$now){ if(!isset($all[$queryChallenge])||!is_array($all[$queryChallenge]))throw new RuntimeException('Recovery challenge disappeared.'); $all[$queryChallenge]['status']='authorized'; $all[$queryChallenge]['authorizedAt']=$now; $all[$queryChallenge]['userId']=$verified['userId']; $all[$queryChallenge]['signerPublicKey']=$verified['publicKey']; $all[$queryChallenge]['token']=$token; $all[$queryChallenge]['tokenHash']=hash('sha256',$token); $all[$queryChallenge]['tokenExpiresAt']=$now+RECOVERY_TOKEN_TTL_MS; return true; }); respond(200,['ok'=>true,'authorized'=>true,'userId'=>$verified['userId'],'message'=>'Head-admin recovery approved. Return to EverAdmin.']); }
    catch(Throwable $e){respond(403,['ok'=>false,'error'=>$e->getMessage()]);}
}

$action=strtolower(trim((string)($req['action']??'')));
if($action==='create-signer-challenge'){
    $pollHash=strtolower(trim((string)($req['pollHash']??''))); if(preg_match('/^[0-9a-f]{64}$/',$pollHash)!==1)respond(400,['ok'=>false,'error'=>'Invalid signer recovery poll proof.']);
    $challenge=bin2hex(random_bytes(32)); $expires=$now+CHALLENGE_TTL_MS;
    mutate_challenges(function(array &$all) use($challenge,$pollHash,$now,$expires){$all[$challenge]=['createdAt'=>$now,'expiresAt'=>$expires,'pollHash'=>$pollHash,'status'=>'pending'];return true;});
    respond(200,['ok'=>true,'challenge'=>$challenge,'signUrl'=>recovery_request_url($challenge),'expiresAt'=>$expires]);
}
if($action==='signer-status'){
    $challenge=strtolower(trim((string)($req['challenge']??''))); $pollSecret=strtolower(trim((string)($req['pollSecret']??'')));
    if(preg_match('/^[0-9a-f]{64}$/',$challenge)!==1||preg_match('/^[0-9a-f]{64}$/',$pollSecret)!==1)respond(400,['ok'=>false,'error'=>'Invalid signer recovery status request.']);
    $rec=get_challenge($challenge); if($rec===null||(int)($rec['expiresAt']??0)<=$now)respond(404,['ok'=>false,'error'=>'Recovery signer challenge expired or was not found.']);
    if(!hash_equals((string)($rec['pollHash']??''),hash('sha256',$pollSecret)))respond(403,['ok'=>false,'error'=>'Invalid recovery poll proof.']);
    if(($rec['status']??'pending')!=='authorized')respond(200,['ok'=>true,'authorized'=>false,'expiresAt'=>$rec['expiresAt']]);
    if((int)($rec['tokenExpiresAt']??0)<=$now||empty($rec['token']))respond(410,['ok'=>false,'error'=>'Recovery authorization token expired. Create a new signer challenge.']);
    respond(200,['ok'=>true,'authorized'=>true,'userId'=>$rec['userId']??null,'signerPublicKey'=>$rec['signerPublicKey']??null,'recoveryToken'=>$rec['token'],'tokenExpiresAt'=>$rec['tokenExpiresAt']]);
}

// ForumGuard v0.3.4 manager UI uses the contract's node-local ../custom.json path; legacy forum-manager recovery actions remain only for older cached dashboards.
$allowed=['status','log','restart','recover-self','recover-invite','repair-watcher','forum-manager-status','forum-manager-save','forum-manager-clear']; if(!in_array($action,$allowed,true))respond(400,['ok'=>false,'error'=>'Unsupported recovery action.']);
$payloadJson=(string)($req['payloadJson']??'{}'); if(strlen($payloadJson)>MAX_PAYLOAD_BYTES)respond(413,['ok'=>false,'error'=>'Recovery payload is too large.']); $payload=json_decode($payloadJson,true); if(!is_array($payload))respond(400,['ok'=>false,'error'=>'Recovery payload must be a JSON object.']);

$auth=null; $recoveryToken=strtolower(trim((string)($req['recoveryToken']??'')));
if($recoveryToken!=='')$auth=auth_from_recovery_token($state,$recoveryToken,$now);
if($auth===null){
    $devicePublicKey=clean_public_key($req['devicePublicKey']??null); $timestamp=(int)($req['timestamp']??0); $nonce=strtolower(trim((string)($req['nonce']??''))); $signatureHex=strtolower(trim((string)($req['signature']??'')));
    if($devicePublicKey===null||preg_match('/^[0-9a-f]{32,128}$/',$nonce)!==1||preg_match('/^[0-9a-f]{128}$/',$signatureHex)!==1)respond(403,['ok'=>false,'error'=>'No valid recovery proof. Use an authorized browser/device key or approve recovery with EV Signer.']);
    if($timestamp<=0||abs($now-$timestamp)>MAX_CLOCK_SKEW_MS)respond(401,['ok'=>false,'error'=>'Recovery request timestamp is outside the allowed window.']);
    $devices=is_array($state['authorizedDevices']??null)?$state['authorizedDevices']:[]; $device=is_array($devices[$devicePublicKey]??null)?$devices[$devicePublicKey]:null;
    if($device===null||(int)($device['expiresAt']??0)<=$now)respond(403,['ok'=>false,'error'=>'This browser is not currently authorized for recovery. Import its old device private key or authorize recovery with EV Signer.']);
    $userId=trim((string)($device['userId']??'')); $user=current_head_admin($state,$userId); if($user===null)respond(403,['ok'=>false,'error'=>'Recovery is restricted to head admins.']);
    if(!function_exists('sodium_crypto_sign_verify_detached'))respond(503,['ok'=>false,'error'=>'PHP sodium support is required for signed recovery requests.']);
    $payloadHash=hash('sha256',$payloadJson); $message=RECOVERY_PROTOCOL.'|'.$action.'|'.$devicePublicKey.'|'.$timestamp.'|'.$nonce.'|'.$payloadHash; $signature=hex2bin($signatureHex); $publicRaw=hex2bin(substr($devicePublicKey,2));
    if($signature===false||$publicRaw===false||!sodium_crypto_sign_verify_detached($signature,$message,$publicRaw))respond(403,['ok'=>false,'error'=>'Invalid recovery signature.']);
    if(!use_nonce_once($nonce,$timestamp))respond(409,['ok'=>false,'error'=>'Recovery request nonce was already used or could not be recorded.']);
    $auth=['userId'=>$userId,'user'=>$user,'authMethod'=>'device-key','devicePublicKey'=>$devicePublicKey];
}
$userId=(string)$auth['userId'];

$forumManagerFile=forum_manager_existing_file();
if($action==='forum-manager-status'){
    $fm=$forumManagerFile!==null?(read_json_file($forumManagerFile)??[]):[];
    respond(200,['ok'=>true,'forumManager'=>[
        'forumManager'=>(($fm['forumManager']??false)===true),
        'priority'=>(int)($fm['priority']??100),
        'forumUrl'=>(string)($fm['forumUrl']??''),
        'username'=>(string)($fm['username']??''),
        'passwordSet'=>trim((string)($fm['password']??''))!=='',
        'requestTimeoutMs'=>(int)($fm['requestTimeoutMs']??5000),
        'adminPath'=>(string)($fm['adminPath']??'adm/'),
        'banMinutes'=>(int)($fm['banMinutes']??0),
    ],'storage'=>['path'=>forum_manager_storage_label($forumManagerFile),'consensusState'=>false,'nodeLocal'=>true,'writableCandidate'=>forum_manager_storage_label(forum_manager_writable_file())]]);
}
if($action==='forum-manager-clear'){
    $cleared=[];
    foreach(forum_manager_file_candidates() as $candidate){
        if(is_file($candidate)&&!is_link($candidate)&&@unlink($candidate))$cleared[]=forum_manager_storage_label($candidate);
    }
    respond(200,['ok'=>true,'cleared'=>true,'clearedPaths'=>$cleared,'storage'=>['consensusState'=>false,'nodeLocal'=>true]]);
}
if($action==='forum-manager-save'){
    $old=$forumManagerFile!==null?(read_json_file($forumManagerFile)??[]):[];
    $enabled=(($payload['forumManager']??false)===true);
    $priority=(int)($payload['priority']??100); if($priority<1||$priority>1000000)respond(400,['ok'=>false,'error'=>'Forum manager priority must be between 1 and 1000000.']);
    $forumUrl=trim((string)($payload['forumUrl']??'')); if($forumUrl!=='' && filter_var($forumUrl,FILTER_VALIDATE_URL)===false)respond(400,['ok'=>false,'error'=>'Forum URL is invalid.']);
    if($forumUrl!=='' && !preg_match('#^https?://#i',$forumUrl))respond(400,['ok'=>false,'error'=>'Forum URL must use http:// or https://.']);
    $username=trim((string)($payload['username']??'')); if(strlen($username)>255)respond(400,['ok'=>false,'error'=>'Forum username is too long.']);
    $password=array_key_exists('password',$payload)?(string)$payload['password']:(string)($old['password']??''); if($password==='')$password=(string)($old['password']??''); if(strlen($password)>4096)respond(400,['ok'=>false,'error'=>'Forum password is too long.']);
    $requestTimeoutMs=(int)($payload['requestTimeoutMs']??5000); $requestTimeoutMs=max(1000,min(20000,$requestTimeoutMs));
    try{$adminPath=normalize_forum_admin_path($payload['adminPath']??'adm/');}catch(Throwable $e){respond(400,['ok'=>false,'error'=>$e->getMessage()]);}
    $banMinutes=(int)($payload['banMinutes']??0); $banMinutes=max(0,min(525600,$banMinutes));
    if($enabled && ($forumUrl===''||$username===''||$password===''))respond(400,['ok'=>false,'error'=>'Enabled Forum Manager requires forum URL, username and password.']);
    $target=forum_manager_writable_file();
    if($target===null)respond(500,['ok'=>false,'error'=>'No node-local Forum Manager storage location passed a real write probe.','storageCandidates'=>array_map('forum_manager_storage_label',forum_manager_file_candidates()),'storageDiagnostics'=>forum_manager_storage_diagnostics()]);
    try{
        atomic_json_write($target,['schema'=>2,'forumManager'=>$enabled,'priority'=>$priority,'forumUrl'=>$forumUrl,'username'=>$username,'password'=>$password,'requestTimeoutMs'=>$requestTimeoutMs,'adminPath'=>$adminPath,'banMinutes'=>$banMinutes,'updatedAt'=>$now,'updatedBy'=>$userId]);
        @chmod($target,0600);
    }catch(Throwable $e){
        respond(500,['ok'=>false,'error'=>'Could not save node-local Forum Manager settings: '.$e->getMessage(),'storage'=>['path'=>forum_manager_storage_label($target),'consensusState'=>false,'nodeLocal'=>true],'storageDiagnostics'=>forum_manager_storage_diagnostics()]);
    }
    respond(200,['ok'=>true,'forumManager'=>['forumManager'=>$enabled,'priority'=>$priority,'forumUrl'=>$forumUrl,'username'=>$username,'passwordSet'=>$password!=='','requestTimeoutMs'=>$requestTimeoutMs,'adminPath'=>$adminPath,'banMinutes'=>$banMinutes],'storage'=>['path'=>forum_manager_storage_label($target),'consensusState'=>false,'nodeLocal'=>true]]);
}

$watcherProbe=ensure_watcher_running(false); $watcherStatus=$watcherProbe['status']; $capabilities=is_array($watcherStatus['capabilities']??null)?$watcherStatus['capabilities']:[]; $recoveryCapable=in_array('recover-hotpocket',$capabilities,true)||(int)($watcherStatus['protocolVersion']??0)>=2;
if($action==='status')respond(200,['ok'=>true,'headAdmin'=>true,'userId'=>$userId,'authMethod'=>$auth['authMethod'],'devicePublicKey'=>$auth['devicePublicKey'],'watcher'=>$watcherStatus,'watcherReady'=>$watcherProbe['ready'],'recoveryWatcherReady'=>$recoveryCapable,'queuedRequestsSupported'=>in_array('queued-requests',$capabilities,true),'queueDirs'=>restart_queue_dir_candidates(),'writerDiagnostics'=>restart_writer_diagnostics(),'requestCandidates'=>restart_request_candidates(),'statusCandidates'=>restart_status_candidates(),'lastRequestWrite'=>read_latest_json_candidates(restart_audit_candidates('last-request')),'lastConsumed'=>read_latest_json_candidates(restart_audit_candidates('last-consumed')),'lastResult'=>read_latest_json_candidates(restart_audit_candidates('last-result')),'hpConfig'=>hp_config_summary()]);
if($action==='log'){ $requested=(string)($payload['log']??'hp'); $log=recovery_log($requested); $fallbackOut=($log['name']==='hp'&&!$log['available'])?tail_file('/var/log/supervisor/hotpocket.out.log'):null; $fallbackErr=($log['name']==='hp'&&!$log['available'])?tail_file('/var/log/supervisor/hotpocket.err.log'):null; respond(200,['ok'=>true,'headAdmin'=>true,'authMethod'=>$auth['authMethod'],'log'=>$log,'fallbackStdout'=>$fallbackOut,'fallbackStderr'=>$fallbackErr]); }
if($action==='repair-watcher'){ $probe=ensure_watcher_running(true); if(!$probe['ready'])respond(503,['ok'=>false,'error'=>'The restart listener could not be started.','watcher'=>$probe['status'],'installer'=>$probe['install']]); respond(200,['ok'=>true,'message'=>'Restart listener is running.','watcher'=>$probe['status'],'installer'=>$probe['install']]); }
$baseRequest=['schemaVersion'=>2,'requestedAt'=>$now,'requestedBy'=>$userId,'devicePublicKey'=>$auth['devicePublicKey'],'requestId'=>bin2hex(random_bytes(16)),'source'=>'everadmin-recovery.php','recoveryAuthMethod'=>$auth['authMethod']];
try{
    if($action==='restart'){
        $probe=ensure_watcher_running(true); if(!$probe['ready'])respond(503,['ok'=>false,'error'=>'Restart listener is not running and automatic bootstrap failed. Install/repair everadmin-restart-watcher-setup on the node.','installer'=>$probe['install'],'watcher'=>$probe['status']]);
        $probeCaps=is_array($probe['status']['capabilities']??null)?$probe['status']['capabilities']:[]; $supportsQueue=in_array('queued-requests',$probeCaps,true);
        $request=$baseRequest+['action'=>'restart-hotpocket','reason'=>'head-admin recovery restart']; $requestPath=choose_restart_request_path((string)$request['requestId'],$supportsQueue);
        $writeReceipt=write_restart_request($requestPath,$request); $consumed=wait_for_consumed((string)$request['requestId']);
        respond(202,['ok'=>true,'queued'=>true,'action'=>'restart-hotpocket','requestPath'=>$requestPath,'queueMode'=>$supportsQueue?'per-request':'legacy-mailbox','writeReceipt'=>$writeReceipt,'consumed'=>$consumed,'watcher'=>$probe['status'],'message'=>$consumed?'Restart request was written to seed and consumed by the root watcher.':'Restart request was written to seed. Waiting for the root watcher to consume it.']);
    }
    if(!$recoveryCapable){ $probe=ensure_watcher_running(true); $watcherStatus=$probe['status']; $capabilities=is_array($watcherStatus['capabilities']??null)?$watcherStatus['capabilities']:[]; $recoveryCapable=in_array('recover-hotpocket',$capabilities,true)||(int)($watcherStatus['protocolVersion']??0)>=2; }
    if(!$recoveryCapable)respond(409,['ok'=>false,'error'=>'The installed EverAdmin restart watcher does not advertise recovery protocol v2+. Install the supplied watcher upgrade before changing hp.cfg from recovery mode.','watcher'=>$watcherStatus]);
    $supportsQueue=in_array('queued-requests',$capabilities,true);
    if($action==='recover-self'){$request=$baseRequest+['action'=>'recover-hotpocket','recovery'=>['mode'=>'self-unl'],'reason'=>'head-admin sole-UNL recovery'];$requestPath=choose_restart_request_path((string)$request['requestId'],$supportsQueue);$writeReceipt=write_restart_request($requestPath,$request);$consumed=wait_for_consumed((string)$request['requestId']);respond(202,['ok'=>true,'queued'=>true,'action'=>'recover-hotpocket','mode'=>'self-unl','requestPath'=>$requestPath,'queueMode'=>$supportsQueue?'per-request':'legacy-mailbox','writeReceipt'=>$writeReceipt,'consumed'=>$consumed,'message'=>'Sole-UNL recovery was written to node-local seed storage.']);}
    $contractId=valid_guid($payload['contractId']??null); $validatorPublicKey=clean_public_key($payload['validatorPublicKey']??($payload['trustedValidatorPublicKey']??null)); $bootstrapPeer=valid_peer($payload['bootstrapPeer']??null);
    if($contractId===null||$validatorPublicKey===null||$bootstrapPeer===null)respond(400,['ok'=>false,'error'=>'Invite recovery requires a valid contractId, validatorPublicKey and bootstrapPeer.']);
    $request=$baseRequest+['action'=>'recover-hotpocket','recovery'=>['mode'=>'invite','contractId'=>$contractId,'trustedValidatorPublicKey'=>$validatorPublicKey,'bootstrapPeer'=>$bootstrapPeer],'reason'=>'head-admin invite recovery']; $requestPath=choose_restart_request_path((string)$request['requestId'],$supportsQueue);
    $writeReceipt=write_restart_request($requestPath,$request);$consumed=wait_for_consumed((string)$request['requestId']);
    respond(202,['ok'=>true,'queued'=>true,'action'=>'recover-hotpocket','mode'=>'invite','requestPath'=>$requestPath,'queueMode'=>$supportsQueue?'per-request':'legacy-mailbox','writeReceipt'=>$writeReceipt,'consumed'=>$consumed,'message'=>'Invite recovery was written to node-local seed storage.']);
}catch(Throwable $e){respond(503,['ok'=>false,'error'=>$e->getMessage()]);}

EverAdmin ZIP library — beta / experimental shelf

Drop .zip files here or add them from Admin panel -> Updates -> ZIP library switcher.
The shelf accepts any .zip without classifying it first. Choose Stage as contract to validate/use it as a contract bundle, or Load as EverAdmin runtime to pass it into the runtime upgrader.
Library ZIPs are not deleted when used.

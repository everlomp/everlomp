'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const { URL, URLSearchParams } = require('url');
const crypto = require('crypto');

const WORKER_VERSION = '0.5.6';
function safe(v, n=4096){ return String(v ?? '').trim().slice(0,n); }
function sleep(ms){ return new Promise(resolve=>setTimeout(resolve,Math.max(0,Number(ms)||0))); }
function readJson(f){ return JSON.parse(fs.readFileSync(f,'utf8')); }
function writeJsonAtomic(f,v){ fs.mkdirSync(path.dirname(f),{recursive:true}); const t=f+'.tmp-'+process.pid+'-'+Date.now(); fs.writeFileSync(t,JSON.stringify(v,null,2)+'\n'); fs.renameSync(t,f); }
function decodeHtml(s){ return String(s||'')
  .replace(/&amp;/gi,'&').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/&lt;/gi,'<').replace(/&gt;/gi,'>')
  .replace(/&#x([0-9a-f]+);/gi,(_,h)=>{try{return String.fromCodePoint(parseInt(h,16))}catch{return _}})
  .replace(/&#(\d+);/g,(_,d)=>{try{return String.fromCodePoint(parseInt(d,10))}catch{return _}}); }
function parseAttrs(s){ const out={}; const re=/([:\w-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g; let m; while((m=re.exec(s||''))) out[m[1].toLowerCase()]=decodeHtml(m[2]??m[3]??m[4]??''); return out; }
function parseForms(html){
  const out=[]; const re=/<form\b([^>]*)>([\s\S]*?)<\/form>/gi; let m;
  while((m=re.exec(html||''))){
    const attrs=parseAttrs(m[1]); const body=m[2]; const fields={};
    const ir=/<input\b([^>]*)>/gi; let im;
    while((im=ir.exec(body))){
      const a=parseAttrs(im[1]),type=(a.type||'text').toLowerCase();
      if(!a.name || ['submit','button','image','reset','file'].includes(type)) continue;
      if(['checkbox','radio'].includes(type) && !('checked' in a)) continue;
      fields[a.name]=a.value??'';
    }
    const tr=/<textarea\b([^>]*)>([\s\S]*?)<\/textarea>/gi; let tm;
    while((tm=tr.exec(body))){ const a=parseAttrs(tm[1]); if(a.name) fields[a.name]=decodeHtml(tm[2]||''); }
    const sr=/<select\b([^>]*)>([\s\S]*?)<\/select>/gi; let sm;
    while((sm=sr.exec(body))){
      const a=parseAttrs(sm[1]); if(!a.name)continue;
      const options=[]; const or=/<option\b([^>]*)>([\s\S]*?)<\/option>/gi; let om;
      while((om=or.exec(sm[2]||''))){ const oa=parseAttrs(om[1]); options.push({attrs:oa,text:decodeHtml(String(om[2]||'').replace(/<[^>]+>/g,''))}); }
      const chosen=options.find(x=>Object.prototype.hasOwnProperty.call(x.attrs,'selected'))||options[0];
      if(chosen)fields[a.name]=chosen.attrs.value!==undefined?chosen.attrs.value:chosen.text;
    }
    out.push({attrs,body,fields,parsedAtMs:Date.now()});
  }
  return out;
}
function findForm(html,pred){ return parseForms(html).find(pred)||null; }
function pickForm(html, pred){ const forms=parseForms(html); return forms.find(pred)||forms[0]||null; }
function hasError(html){ const raw=String(html||''),t=raw.toLowerCase(); return /class=["'][^"']*\berrorbox\b/i.test(raw)||/not authorised|not authorized|no auth operation|form invalid|login failed|incorrect password|you cannot|cannot remove|cannot ban|permission denied/.test(t); }
function hasAcpSuccess(html){ return /class=["'][^"']*\bsuccessbox\b/i.test(String(html||'')); }
function phpbbBoxText(html, className){
  const raw=String(html||'');
  const re=new RegExp(`<div\\b[^>]*class=[\"'][^\"']*\\b${className}\\b[^\"']*[\"'][^>]*>([\\s\\S]*?)<\\/div>`, 'i');
  const m=raw.match(re); return m?safe(textOnly(m[1],1200),700):'';
}
function phpbbErrorText(html){ return phpbbBoxText(html,'errorbox')||''; }
function phpbbFailure(prefix,response){
  const r=response||{}, detail=phpbbErrorText(r.html), title=pageTitle(r.html);
  const bits=[prefix]; if(Number(r.status)>=400)bits.push(`HTTP ${r.status}`); if(detail)bits.push(detail); else if(title)bits.push(`page: ${title}`);
  return new Error(bits.filter(Boolean).join(' — '));
}
function looksLikeMissingUser(html){
  const t=textOnly(html,6000).toLowerCase();
  return /requested user does not exist|user does not exist|no user|no_user|unknown user/.test(t);
}
function confirmationForm(html){ return findForm(html,f=>(f.attrs.id||'').toLowerCase()==='confirm'||/name=["']confirm["']/i.test(f.body||'')); }
function submitControlValue(form,name){
  const wanted=String(name||'').toLowerCase(), body=String(form?.body||'');
  let m; const ir=/<input\b([^>]*)>/gi;
  while((m=ir.exec(body))){
    const a=parseAttrs(m[1]); if((a.name||'').toLowerCase()!==wanted)continue;
    const type=(a.type||'submit').toLowerCase(); if(!['submit','button','image'].includes(type)||Object.prototype.hasOwnProperty.call(a,'disabled'))continue;
    if(a.value!==undefined)return a.value;
  }
  const br=/<button\b([^>]*)>([\s\S]*?)<\/button>/gi;
  while((m=br.exec(body))){
    const a=parseAttrs(m[1]); if((a.name||'').toLowerCase()!==wanted)continue;
    const type=(a.type||'submit').toLowerCase(); if(type!=='submit'||Object.prototype.hasOwnProperty.call(a,'disabled'))continue;
    if(a.value!==undefined)return a.value;
  }
  return '';
}
async function submitPhpbbConfirmation(c,response,overrides={}){
  const f=confirmationForm(response&&response.html); if(!f)return {response,confirmed:false};
  // phpBB confirm_box() requires the POSTed `confirm` value to equal the
  // board's localized YES string exactly. Do not guess "1" or "Yes": custom
  // languages/styles may render a different submit value. Read the actual
  // successful submit control from the confirmation page and replay it along
  // with phpBB's hidden confirm_uid/sess/sid fields and confirm_key action URL.
  const confirmValue=submitControlValue(f,'confirm');
  if(!confirmValue) throw new Error('phpBB confirmation form did not expose a usable confirm submit value.');
  const r=await c.submitForm(f,response.url,{...overrides,confirm:confirmValue});
  return {response:r,confirmed:true,confirmControl:'page-value'};
}
function hasLoginForm(html){ return /name=["']username["']/i.test(html||'') && /name=["']password["']/i.test(html||''); }
function pageTitle(html){ const m=String(html||'').match(/<title[^>]*>([\s\S]*?)<\/title>/i); return safe(decodeHtml((m&&m[1]||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ')),180); }
function textOnly(html,n=16000){ return safe(decodeHtml(String(html||'').replace(/<script\b[\s\S]*?<\/script>/gi,' ').replace(/<style\b[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ')),n); }
function loginChallenge(html){
  const raw=String(html||''); const t=textOnly(raw,20000).toLowerCase();
  if(/g-recaptcha|recaptcha|hcaptcha|cf-turnstile|name=["']confirm_code["']|id=["'][^"']*captcha|class=["'][^"']*captcha/i.test(raw)) return 'captcha';
  if(/two[- ]factor|\b2fa\b|one[- ]time|\botp\b|webauthn|authenticator code|verification code/i.test(t+' '+raw)) return 'extra_auth';
  return '';
}
function loginMessage(html){
  const text=textOnly(html,22000);
  const patterns=[
    /The submitted form was invalid[^.]*\.?/i,
    /You have specified an incorrect (?:username|password)[^.]*\.?/i,
    /The specified username is currently inactive[^.]*\.?/i,
    /You exceeded the maximum allowed number of login attempts[^.]*\.?/i,
    /too many login attempts[^.]*\.?/i,
    /maximum number of login attempts[^.]*\.?/i,
    /incorrect password[^.]*\.?/i,
    /login failed[^.]*\.?/i
  ];
  for(const re of patterns){ const m=text.match(re); if(m) return safe(m[0],300); }
  return '';
}
function sanitizeDetail(value, depth=0){
  if(depth>3 || value===undefined) return null;
  if(value===null || typeof value==='boolean' || typeof value==='number') return value;
  if(typeof value==='string') return safe(value,500);
  if(Array.isArray(value)) return value.slice(0,20).map(v=>sanitizeDetail(v,depth+1));
  if(typeof value!=='object') return safe(value,200);
  const out={};
  for(const [k,v] of Object.entries(value)){
    if(/password|passwd|cookie|sid|session|token|secret|authorization|csrf|form|html|header|body|credential/i.test(k)) continue;
    const clean=sanitizeDetail(v,depth+1); if(clean!==undefined) out[safe(k,80)]=clean;
  }
  return out;
}
class Client{
  constructor(base, timeout){
    this.base=new URL(base);
    if(!this.base.pathname.endsWith('/')) this.base.pathname += '/';
    this.timeout=timeout||5000;
    this.cookies=[];
    this.cookieSeq=0;
    this.lastRedirects=[];
    this.httpAgent=new http.Agent({keepAlive:true,maxSockets:1});
    this.httpsAgent=new https.Agent({keepAlive:true,maxSockets:1});
  }
  domainMatches(host,domain){
    host=String(host||'').toLowerCase(); domain=String(domain||'').toLowerCase().replace(/^\./,'');
    return host===domain || host.endsWith('.'+domain);
  }
  defaultCookiePath(pathname){
    const p=String(pathname||'/');
    if(!p.startsWith('/')||p==='/') return '/';
    const i=p.lastIndexOf('/');
    return i<=0?'/':p.slice(0,i);
  }
  pathMatches(requestPath,cookiePath){
    const rp=requestPath||'/'; const cp=cookiePath||'/';
    if(rp===cp)return true;
    if(!rp.startsWith(cp))return false;
    return cp.endsWith('/') || rp.charAt(cp.length)==='/';
  }
  purgeExpired(){ const now=Date.now(); this.cookies=this.cookies.filter(c=>!c.expiresAt||c.expiresAt>now); }
  cookieHeader(target){
    const u=target instanceof URL?target:new URL(target,this.base); this.purgeExpired();
    return this.cookies.filter(c=>{
      if(c.secure&&u.protocol!=='https:')return false;
      if(c.hostOnly){if(u.hostname.toLowerCase()!==c.domain)return false;}else if(!this.domainMatches(u.hostname,c.domain))return false;
      return this.pathMatches(u.pathname||'/',c.path);
    }).sort((a,b)=>b.path.length-a.path.length||a.seq-b.seq).map(c=>`${c.name}=${c.value}`).join('; ');
  }
  clearSession(){ this.cookies=[]; this.lastRedirects=[]; }
  storeCookies(headers,responseUrl){
    const u=responseUrl instanceof URL?responseUrl:new URL(responseUrl,this.base);
    let vals=headers['set-cookie']||[]; if(!Array.isArray(vals)) vals=[vals];
    for(const line of vals){
      if(!line)continue;
      const parts=String(line).split(';'); const first=parts.shift()||''; const i=first.indexOf('='); if(i<=0)continue;
      const name=first.slice(0,i).trim(); const value=first.slice(i+1).trim(); if(!name)continue;
      const attrs={};
      for(const raw of parts){ const j=raw.indexOf('='); const k=(j>=0?raw.slice(0,j):raw).trim().toLowerCase(); const v=(j>=0?raw.slice(j+1):'').trim(); if(k)attrs[k]=v; }
      let domain=u.hostname.toLowerCase(),hostOnly=true;
      if(attrs.domain){ const requested=attrs.domain.toLowerCase().replace(/^\./,''); if(!this.domainMatches(u.hostname,requested)) continue; domain=requested;hostOnly=false; }
      let cookiePath=attrs.path&&attrs.path.startsWith('/')?attrs.path:this.defaultCookiePath(u.pathname);
      let expiresAt=0;
      if(attrs['max-age']!==undefined){ const n=Number(attrs['max-age']); if(Number.isFinite(n)) expiresAt=Date.now()+n*1000; }
      else if(attrs.expires){ const t=Date.parse(attrs.expires); if(Number.isFinite(t))expiresAt=t; }
      const key=c=>c.name===name&&c.domain===domain&&c.path===cookiePath;
      const old=this.cookies.findIndex(key);
      const remove=value===''||(expiresAt&&expiresAt<=Date.now());
      if(remove){ if(old>=0)this.cookies.splice(old,1); continue; }
      const item={name,value,domain,path:cookiePath,hostOnly,secure:Object.prototype.hasOwnProperty.call(attrs,'secure'),expiresAt,seq:old>=0?this.cookies[old].seq:++this.cookieSeq};
      if(old>=0)this.cookies[old]=item;else this.cookies.push(item);
    }
    this.purgeExpired();
  }
  matchingCookies(target){ const u=target instanceof URL?target:new URL(target,this.base); this.purgeExpired(); return this.cookies.filter(c=>{if(c.secure&&u.protocol!=='https:')return false;if(c.hostOnly?u.hostname.toLowerCase()!==c.domain:!this.domainMatches(u.hostname,c.domain))return false;return this.pathMatches(u.pathname||'/',c.path);}); }
  guestSid(target){ const rows=this.matchingCookies(target); const c=rows.find(x=>/(?:^|_)sid$/i.test(x.name)); return c?c.value:''; }
  hasAuthenticatedUserCookie(target=this.base){ for(const c of this.matchingCookies(target)){ if(/(?:^|_)u$/i.test(c.name)){ let d=c.value; try{d=decodeURIComponent(d)}catch{} if(/^\d+$/.test(d)&&Number(d)>1)return true; } } return false; }
  async req(method, target, body=null, headers={}, redirects=0){
    const u=new URL(target,this.base); const lib=u.protocol==='https:'?https:http; const data=body==null?null:Buffer.from(body);
    const opts={method,hostname:u.hostname,port:u.port||undefined,path:u.pathname+u.search,agent:u.protocol==='https:'?this.httpsAgent:this.httpAgent,headers:{'User-Agent':`ForumGuard-Manager/${WORKER_VERSION}`,'Accept':'text/html,application/xhtml+xml,*/*','Accept-Language':'en-US,en;q=0.8','Cache-Control':'no-cache','Pragma':'no-cache','Connection':'keep-alive',...headers}};
    const cookie=this.cookieHeader(u); if(cookie)opts.headers.Cookie=cookie;
    if(data){ opts.headers['Content-Length']=data.length; if(!opts.headers['Content-Type']) opts.headers['Content-Type']='application/x-www-form-urlencoded; charset=UTF-8'; }
    const res=await new Promise((resolve,reject)=>{ const r=lib.request(opts,resolve); r.setTimeout(this.timeout,()=>r.destroy(new Error('HTTP timeout'))); r.on('error',reject); if(data)r.write(data); r.end(); });
    this.storeCookies(res.headers,u); let bufs=[]; for await(const ch of res) bufs.push(ch); const text=Buffer.concat(bufs).toString('utf8');
    if(res.statusCode>=300&&res.statusCode<400&&res.headers.location&&redirects<8){ const next=new URL(res.headers.location,u).toString(); this.lastRedirects.push({status:res.statusCode,from:u.pathname,to:new URL(next).pathname}); const preserve=(res.statusCode===307||res.statusCode===308); return this.req(preserve?method:'GET',next,preserve?body:null,preserve?headers:{},redirects+1); }
    return {status:res.statusCode||0,url:u.toString(),html:text,headers:res.headers};
  }
  async submitForm(form, sourceUrl, overrides={}){
    if(!form) throw new Error('Expected phpBB form was not found.');
    const source=new URL(sourceUrl,this.base);
    const actionUrl=new URL(decodeHtml(form.attrs.action||source.toString()),source);
    const params=new URLSearchParams();
    for(const [k,v] of Object.entries(form.fields||{})) params.set(k,String(v));
    for(const [k,v] of Object.entries(overrides)) { if(v===undefined||v===null) continue; params.set(k,String(v)); }

    // phpBB's check_form_key() deliberately rejects a form submitted in the
    // exact same server second in which creation_time was generated (diff=0).
    // A human naturally takes longer than that; a local worker often does not.
    // Enforce a small minimum age for every phpBB token-bearing form, not only
    // login, because delete/ban/ACP forms use the same form-key machinery.
    const fields=form.fields||{};
    if(Object.prototype.hasOwnProperty.call(fields,'creation_time') && Object.prototype.hasOwnProperty.call(fields,'form_token')){
      const parsedAt=Number(form.parsedAtMs||Date.now());
      const minSubmitAt=parsedAt+1150;
      const waitMs=Math.max(0,minSubmitAt-Date.now());
      if(waitMs>0) await sleep(waitMs);
    }

    return this.req('POST',actionUrl.toString(),params.toString(),{'Referer':source.toString(),'Origin':actionUrl.origin});
  }
}
function shortFingerprint(v){ return v?crypto.createHash('sha256').update(String(v)).digest('hex').slice(0,10):''; }
function sidFromForm(form,sourceUrl){
  const fields=form?.fields||{}; if(fields.sid)return String(fields.sid);
  try{ const source=new URL(sourceUrl); const action=new URL(decodeHtml(form?.attrs?.action||source.toString()),source); return action.searchParams.get('sid')||source.searchParams.get('sid')||''; }catch{return '';}
}
function authSignals(c, html){
  const decoded=decodeHtml(String(html||''));
  const logoutLink=/ucp\.php\?mode=logout/i.test(decoded) || /mode=logout/i.test(decoded);
  const userCookie=c.hasAuthenticatedUserCookie();
  const loginForm=hasLoginForm(decoded);
  const ucpMarker=/id=["']cp-main["']|class=["'][^"']*ucp-main|user control panel/i.test(decoded);
  return {authenticated:Boolean(userCookie||logoutLink||(ucpMarker&&!loginForm)),userCookie,logoutLink,ucpMarker,loginForm};
}
function loginFormScore(form){
  if(!form) return -1;
  const body=String(form.body||'');
  if(!/name=["']username["']/i.test(body) || !/name=["']password["']/i.test(body)) return -1;
  const fields=form.fields||{};
  let score=10;
  if(Object.prototype.hasOwnProperty.call(fields,'creation_time')) score+=40;
  if(Object.prototype.hasOwnProperty.call(fields,'form_token')) score+=40;
  if(Object.prototype.hasOwnProperty.call(fields,'sid')) score+=10;
  if(/(?:^|[?&])mode=login(?:&|$)/i.test(decodeHtml(form.attrs.action||''))) score+=15;
  if((form.attrs.id||'').toLowerCase()==='login') score+=5;
  return score;
}
function pickPhpbbLoginForm(html){
  const forms=parseForms(html).map((form,index)=>({form,index,score:loginFormScore(form)})).filter(x=>x.score>=0).sort((a,b)=>b.score-a.score||a.index-b.index);
  return {form:forms[0]?.form||null,candidates:forms.length,score:forms[0]?.score??-1};
}
function csrfShape(form){
  const fields=form?.fields||{};
  return {
    loginFormCandidates: 0,
    csrfFieldCount: Number(Object.prototype.hasOwnProperty.call(fields,'creation_time')) + Number(Object.prototype.hasOwnProperty.call(fields,'form_token')),
    guestSessionFieldPresent: Object.prototype.hasOwnProperty.call(fields,'sid'),
  };
}
async function loginAttempt(c,cfg,attempt){
  const nonce=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
  // Prime a browser-like guest session first. phpBB can bind guest form keys to
  // the session id, and a direct first-request POST path is more fragile behind
  // proxies/cookie fallbacks than a normal browser sequence.
  await c.req('GET',`index.php?fg_session_probe=${encodeURIComponent(nonce)}`);
  const g=await c.req('GET',`ucp.php?mode=login&fg=${encodeURIComponent(nonce)}`);
  if(g.status>=400) throw new Error(`phpBB login page returned HTTP ${g.status}.`);
  const preChallenge=loginChallenge(g.html);
  if(preChallenge==='captcha') throw new Error('phpBB is requiring a CAPTCHA/anti-spambot check before login. Credentials were not rejected; clear/wait for the login-attempt limit or complete the forum challenge manually.');
  if(preChallenge==='extra_auth') throw new Error('phpBB is requiring an extra authentication step (2FA/OTP/WebAuthn) before login. The saved password may be correct, but this worker does not yet have that second factor.');
  const picked=pickPhpbbLoginForm(g.html); const f=picked.form;
  if(!f) throw new Error('phpBB login form was not found on the configured forum URL.');
  const fields=f.fields||{};
  const csrfCount=Number(Object.prototype.hasOwnProperty.call(fields,'creation_time')) + Number(Object.prototype.hasOwnProperty.call(fields,'form_token'));
  if(csrfCount<2) throw new Error(`phpBB login form was found but its session-bound form key was incomplete (${csrfCount}/2 CSRF fields). ForumGuard refused to submit credentials.`);
  const cookieSid=c.guestSid(g.url), formSid=sidFromForm(f,g.url);
  const continuity=(!cookieSid||!formSid||cookieSid===formSid);
  // If phpBB supplied an explicit SID fallback in the form/action, preserve it
  // in the POST body as well. This is harmless when cookies are valid and is
  // necessary on boards that intentionally fall back to URL/session SIDs.
  const overrides={username:cfg.username,password:cfg.password,login:'Login',autologin:'on'};
  if(formSid&&!Object.prototype.hasOwnProperty.call(fields,'sid'))overrides.sid=formSid;
  const r=await c.submitForm(f,g.url,overrides);

  let verify=await c.req('GET','ucp.php?i=ucp_main&mode=front');
  let signals=authSignals(c,verify.html);
  if(!signals.authenticated){ const index=await c.req('GET','index.php'); const indexSignals=authSignals(c,index.html); if(indexSignals.authenticated){verify=index;signals=indexSignals;} }
  if(!signals.authenticated){
    const combined=String(r.html||'')+' '+String(verify.html||''); const challenge=loginChallenge(combined);
    if(challenge==='captcha') throw new Error('phpBB requires CAPTCHA/anti-spambot verification after this login attempt. This often happens after the forum login-attempt threshold is reached; the saved password is not proven wrong.');
    if(challenge==='extra_auth') throw new Error('phpBB requires an extra authentication step (2FA/OTP/WebAuthn). The saved password is not proven wrong.');
    const msg=loginMessage(combined);
    if(/submitted form was invalid/i.test(msg)){
      const e=new Error(`phpBB rejected login form/session validation on attempt ${attempt}. Credentials were not checked.`); e.code='PHPBB_FORM_INVALID';
      e.safeDetail={attempt,candidateCount:picked.candidates,keyFieldCount:csrfCount,guestFieldPresent:Object.prototype.hasOwnProperty.call(fields,'sid'),cookieCount:c.matchingCookies(g.url).length,transport:formSid?(cookieSid?'cookie+sid-fallback':'sid-fallback'):(cookieSid?'cookie':'none'),guestContinuity:continuity,cookieGuestFingerprint:shortFingerprint(cookieSid),formGuestFingerprint:shortFingerprint(formSid)};
      throw e;
    }
    if(msg) throw new Error(`phpBB did not authenticate the manager: ${msg}`);
    throw new Error('phpBB accepted the login request but the follow-up session still appears to be a guest. The saved password is not proven wrong; this points to phpBB session/cookie/auth-flow handling.');
  }
  return {loginOk:true,httpStatus:verify.status,pageTitle:pageTitle(verify.html),verification:'authenticated follow-up request',authenticatedUserCookie:signals.userCookie,logoutLinkSeen:signals.logoutLink,candidateCount:picked.candidates,keyFieldCount:csrfCount,freshGuestRetry:attempt>1,cookieCount:c.matchingCookies(verify.url).length,transport:formSid?(cookieSid?'cookie+sid-fallback':'sid-fallback'):(cookieSid?'cookie':'none'),guestContinuity:continuity,phpbbFormMinimumAgeMs:1150};
}
async function login(c,cfg){
  let firstError=null;
  try{return await loginAttempt(c,cfg,1);}catch(e){if(e&&e.code==='PHPBB_FORM_INVALID')firstError=e;else throw e;}
  c.clearSession();
  try{const result=await loginAttempt(c,cfg,2);result.retryRecovered=true;return result;}catch(e){
    if(e&&e.code==='PHPBB_FORM_INVALID'){
      const a=firstError?.safeDetail||{},b=e.safeDetail||{};
      throw new Error(`phpBB rejected two fresh session-bound login forms before checking credentials. Browser-compatible cookie handling was used; attempt transports were ${a.transport||'unknown'} then ${b.transport||'unknown'}, with guest-session continuity ${a.guestContinuity===false?'MISMATCH':'ok/unknown'} then ${b.guestContinuity===false?'MISMATCH':'ok/unknown'}. Credentials are still not proven wrong.`);
    }
    throw e;
  }
}
async function checkModeratorAccess(c){ const r=await c.req('GET','mcp.php?i=main&mode=front'); if(r.status>=400) throw new Error(`Moderator Control Panel returned HTTP ${r.status}.`); if(hasError(r.html)||hasLoginForm(r.html)) throw new Error('phpBB refused Moderator Control Panel access. Check moderator permissions.'); if(!/mcp|moderator control panel|moderator/i.test((pageTitle(r.html)+' '+r.html.slice(0,12000)).toLowerCase())) throw new Error('Moderator Control Panel access could not be verified from the returned page.'); return {moderatorAccess:true,httpStatus:r.status,pageTitle:pageTitle(r.html)}; }
async function deletePost(c, action){ const p=safe(action.postId,100); if(!p) throw new Error('Post ID is missing.'); const g=await c.req('GET',`posting.php?mode=delete&p=${encodeURIComponent(p)}`); if(g.status===404||/NO_POST|does not exist|requested topic does not exist/i.test(g.html)) return {postDeleted:true,alreadyGone:true}; if(hasError(g.html)) throw new Error('phpBB refused post deletion (permission or form error).'); const f=pickForm(g.html,x=>/confirm/i.test(x.body)||/posting\.php/i.test(x.attrs.action||'')); const r=await c.submitForm(f,`posting.php?mode=delete&p=${encodeURIComponent(p)}`,{confirm:'Yes',delete_permanent:'1',delete_reason:`ForumGuard action ${action.actionId||''}`}); if(hasError(r.html)) throw new Error('phpBB refused post deletion confirmation.'); return {postDeleted:true,httpStatus:r.status}; }
async function banUser(c, cfg, action){
  const u=safe(action.userId,100), name=safe(action.username,255); const q=u?`mcp.php?i=ban&mode=user&u=${encodeURIComponent(u)}`:'mcp.php?i=ban&mode=user';
  const g=await c.req('GET',q); if(g.status>=400||hasError(g.html)||hasLoginForm(g.html)) throw phpbbFailure('phpBB refused access to the ban page.',g);
  const f=findForm(g.html,x=>(x.attrs.id||'').toLowerCase()==='mcp_ban'||/name=["']bansubmit["']/i.test(x.body||'')); if(!f)throw new Error('phpBB Moderator Control Panel ban form was not found.');
  const minutes=Number.isFinite(Number(action.banMinutes))?Math.max(0,Math.trunc(Number(action.banMinutes))):Math.max(0,Math.trunc(Number(cfg.banMinutes||0)));
  const banTarget=name||safe(f.fields?.ban,255); if(!banTarget)throw new Error('phpBB ban form did not provide a username and the moderation case has no username.');
  let r=await c.submitForm(f,g.url,{ban:banTarget,banlength:String(minutes),banreason:`ForumGuard spam score ${action.score}/100`,bangivereason:'Automated ForumGuard moderation',banexclude:'0',bansubmit:'Submit'});
  if(r.status>=400||hasError(r.html)||hasLoginForm(r.html)) throw phpbbFailure('phpBB refused user ban.',r);
  const confirmation=await submitPhpbbConfirmation(c,r); r=confirmation.response;
  if(r.status>=400||hasError(r.html)||hasLoginForm(r.html)) throw phpbbFailure('phpBB refused user ban confirmation.',r);
  if(!confirmation.confirmed && findForm(r.html,x=>(x.attrs.id||'').toLowerCase()==='mcp_ban')) throw new Error('phpBB returned to the ban form without presenting a confirmation or success page.');
  return {userBanned:true,banMinutes:minutes,httpStatus:r.status,confirmationHandled:confirmation.confirmed};
}
function extractSid(html,url){ const both=String(html||'')+' '+String(url||''); const m=both.match(/[?&]sid=([a-f0-9]{16,64})/i); return m?m[1]:''; }
function acpLoginForm(html){
  const forms=parseForms(html);
  for(const f of forms){
    const names=Object.keys(f.fields||{});
    const passwordField=names.find(k=>/^password(?:_[a-f0-9]{32})?$/i.test(k)) || '';
    if(passwordField && (/name=["']username["']/i.test(f.body)||Object.prototype.hasOwnProperty.call(f.fields||{},'username'))) return {form:f,passwordField};
  }
  return null;
}
async function adminLogin(c,cfg){
  const admin=safe(cfg.adminPath||'adm/',80).replace(/^\/+|\/+$/g,'');
  const adminIndex=`${admin}/index.php`;

  // phpBB's ACP entry point defines NEED_SID=true. Its own functional test
  // enters ACP with the currently authenticated forum SID, then performs the
  // administrator password confirmation. Do the same here. Opening adm/index
  // without that SID can bind the ACP re-auth form to a different/guest
  // session on boards that strictly enforce SID continuity.
  let forumSid=c.guestSid(adminIndex)||c.guestSid(c.base)||'';
  if(!forumSid){
    const probe=await c.req('GET','index.php');
    forumSid=c.guestSid(adminIndex)||extractSid(probe.html,probe.url)||'';
  }
  if(!forumSid) throw new Error('Could not recover the authenticated phpBB forum session id before ACP re-authentication.');

  let g=await c.req('GET',`${adminIndex}?sid=${encodeURIComponent(forumSid)}`);
  if(g.status>=400) throw new Error(`phpBB ACP returned HTTP ${g.status}. Check ACP path.`);

  const preAuthSid=extractSid(g.html,g.url)||forumSid;
  const acp=acpLoginForm(g.html);
  if(acp){
    const overrides={username:cfg.username,login:'Login'};
    overrides[acp.passwordField]=cfg.password;
    const r=await c.submitForm(acp.form,g.url,overrides);
    const again=acpLoginForm(r.html);
    if(hasError(r.html)||again) throw new Error('phpBB ACP re-authentication failed. The normal forum login succeeded, but ACP rejected its re-authentication form.');
    g=r;
  }

  // Admin re-authentication deliberately replaces the normal session with a
  // new session_admin=1 session. Adopt the SID issued by that response. The
  // original forum SID is valid only when no ACP re-auth was needed.
  let sid=c.guestSid(adminIndex)||extractSid(g.html,g.url)||'';
  if(!sid && !acp) sid=preAuthSid;
  if(!sid) throw new Error('Could not recover phpBB ACP session id after re-authentication.');

  // The POST's redirect is already the first proof that the administrator
  // credentials were accepted. Verify the newly issued SID once, matching the
  // sequence used by phpBB's functional tests, before any destructive action.
  let verify=await c.req('GET',`${adminIndex}?sid=${encodeURIComponent(sid)}`);
  if(verify.status>=400) throw new Error(`phpBB ACP verification returned HTTP ${verify.status}.`);
  let verifyLogin=acpLoginForm(verify.html);

  // Some setups rotate the SID one more time during redirect/cookie handling.
  // If that happened, retry only with the newest cookie SID, never the old
  // pre-auth forum SID.
  const newestCookieSid=c.guestSid(adminIndex)||'';
  if(verifyLogin && newestCookieSid && newestCookieSid!==sid){
    sid=newestCookieSid;
    verify=await c.req('GET',`${adminIndex}?sid=${encodeURIComponent(sid)}`);
    verifyLogin=acpLoginForm(verify.html);
  }
  if(hasError(verify.html)||verifyLogin||hasLoginForm(verify.html)){
    throw new Error(`phpBB ACP session verification failed after re-authentication. The forum login is valid, but the ACP session did not remain authenticated (forum SID ${shortFingerprint(forumSid)}, ACP SID ${shortFingerprint(sid)}).`);
  }

  sid=c.guestSid(adminIndex)||extractSid(verify.html,verify.url)||sid;
  return {sid,admin,httpStatus:verify.status,pageTitle:pageTitle(verify.html),acpReauthenticated:Boolean(acp),sidRotated:Boolean(acp&&preAuthSid&&sid&&preAuthSid!==sid),acpEntryUsedForumSid:true};
}
async function checkAcpAccess(c,cfg){ const auth=await adminLogin(c,cfg); const r=await c.req('GET',`${auth.admin}/index.php?sid=${encodeURIComponent(auth.sid)}`); if(r.status>=400) throw new Error(`phpBB ACP returned HTTP ${r.status}.`); if(hasError(r.html)||hasLoginForm(r.html)) throw new Error('phpBB refused ACP access. Check administrator permissions.'); return {acpAccess:true,httpStatus:r.status,pageTitle:pageTitle(r.html),adminPath:`${auth.admin}/`}; }
function acpUserQuery(auth, action, moduleId='users'){
  const u=safe(action.userId,100), name=safe(action.username,255), module=safe(moduleId,40)||'users';
  if(/^\d+$/.test(u)) return {query:`${auth.admin}/index.php?i=${encodeURIComponent(module)}&mode=overview&u=${encodeURIComponent(u)}&sid=${encodeURIComponent(auth.sid)}`,requestedBy:'user-id',module};
  if(name) return {query:`${auth.admin}/index.php?i=${encodeURIComponent(module)}&mode=overview&username=${encodeURIComponent(name)}&sid=${encodeURIComponent(auth.sid)}`,requestedBy:'username',module};
  throw new Error('phpBB user ID or username is required for ACP user management.');
}
function resolvedAcpUserId(form, fallback='', sourceUrl=''){
  const direct=safe(form?.fields?.u,100); if(/^\d+$/.test(direct))return direct;
  for(const candidate of [form?.attrs?.action,sourceUrl]){
    if(!candidate)continue;
    try{ const url=new URL(decodeHtml(candidate),sourceUrl||'http://localhost/'); const q=safe(url.searchParams.get('u'),100); if(/^\d+$/.test(q))return q; }catch{}
  }
  const raw=safe(fallback,100); return /^\d+$/.test(raw)?raw:'';
}
function acpUserForm(html, kind){
  const id=kind==='ban'?'user_quick_tools':'user_delete';
  const exact=findForm(html,f=>(f.attrs.id||'').toLowerCase()===id); if(exact)return exact;
  if(kind==='ban') return findForm(html,f=>/name=["']action["']/i.test(f.body||'')&&/ban_reason|quicktools/i.test(f.body||''));

  // phpBB uses one acp_users form key for the user-management request and then
  // renders that same S_FORM_TOKEN in several forms on the overview page. Some
  // ACP styles/extensions hide or rename the dedicated #user_delete form even
  // though the backend still accepts update=1, delete=1, delete_type=remove.
  // Prefer the delete form, but fall back to another token-bearing form from
  // the *same managed-user overview* so phpBB remains the authority on whether
  // the target may actually be deleted (founder/self/permission checks, etc.).
  const forms=parseForms(html);
  const tokenBearing=f=>{
    const fields=f.fields||{};
    return Object.prototype.hasOwnProperty.call(fields,'creation_time') &&
      Object.prototype.hasOwnProperty.call(fields,'form_token');
  };
  const preferred=['user_overview','user_quick_tools','mode_select'];
  for(const wanted of preferred){
    const f=forms.find(x=>(x.attrs.id||'').toLowerCase()===wanted && tokenBearing(x));
    if(f)return f;
  }
  return forms.find(f=>tokenBearing(f) && /name=["'](?:user|action|mode)["']/i.test(f.body||'')) || null;
}
function acpFormSummary(html){
  return parseForms(html).slice(0,10).map(f=>{
    const id=safe(f.attrs?.id||'(no-id)',40), fields=f.fields||{};
    const token=Object.prototype.hasOwnProperty.call(fields,'form_token')&&Object.prototype.hasOwnProperty.call(fields,'creation_time');
    return `${id}${token?'+token':''}`;
  }).join(', ');
}
async function loadAcpUserPage(c,auth,action,kind){
  let lastProblem='';
  for(const moduleId of ['users','acp_users']){
    const target=acpUserQuery(auth,action,moduleId), g=await c.req('GET',target.query);
    if(g.status>=400){lastProblem=`${moduleId} returned HTTP ${g.status}`;continue;}
    if(hasError(g.html)){const why=phpbbErrorText(g.html);lastProblem=`${moduleId} returned an ACP error page${why?`: ${safe(why,260)}`:''}`;continue;}
    const form=acpUserForm(g.html,kind); if(form){
      const formId=(form.attrs.id||'').toLowerCase();
      return {target,g,form,formFallback:kind==='purge'&&formId!=='user_delete',formId:formId||undefined};
    }
    const summary=acpFormSummary(g.html);
    lastProblem=`${moduleId} did not expose a usable ${kind==='ban'?'user quick-tools':'user-management token'} form${summary?` (forms: ${summary})`:''}`;
  }
  throw new Error(`phpBB ACP user management could not be opened (${lastProblem||'expected form not found'}).`);
}
async function banUserViaAcp(c,cfg,action){
  // phpBB ACP overview can resolve either ?u=<id> or ?username=<name>.
  // The quick-tool `action=banuser` is a permanent user ban and validates the
  // same acp_users form key already present in the overview form.
  const requestedMinutes=Math.max(0,Math.trunc(Number(action.banMinutes||cfg.banMinutes||0)));
  if(requestedMinutes>0) throw new Error('Timed bans use the Moderator Control Panel path; ACP quick-tool ban is permanent.');
  const auth=await adminLogin(c,cfg), loaded=await loadAcpUserPage(c,auth,action,'ban'), {target,g,form:f}=loaded;
  const resolvedUserId=resolvedAcpUserId(f,action.userId,g.url);
  const overrides={update:'Submit',action:'banuser',ban_reason:`ForumGuard spam score ${action.score}/100`,ban_give_reason:'Automated ForumGuard moderation'};
  if(resolvedUserId)overrides.u=resolvedUserId;
  const r=await c.submitForm(f,g.url,overrides);
  const body=decodeHtml(String(r.html||''));
  if(hasError(body)) throw new Error('phpBB ACP refused the user ban request.');
  const already=/ban already entered|already banned/i.test(body), success=/ban successful|successfully banned|back to previous page/i.test(body);
  if(!hasAcpSuccess(body)&&!success&&!already) throw new Error('phpBB ACP ban request returned without a verifiable success notice.');
  return {userBanned:true,banMinutes:0,banMethod:'acp-user-quicktool',resolvedUserId:resolvedUserId||undefined,resolvedBy:target.requestedBy,alreadyBanned:already,httpStatus:r.status};
}
async function banUserRobust(c,cfg,action){
  // phpBB's MCP ban flow natively supports both timed bans and permanent bans
  // (banlength=0). Keep all user bans on one well-defined, moderator-native path
  // instead of making permanent bans depend on ACP re-authentication.
  const minutes=Math.max(0,Math.trunc(Number(action.banMinutes??cfg.banMinutes??0)));
  const result=await banUser(c,cfg,{...action,banMinutes:minutes});
  return {...result,banMethod:minutes>0?'mcp-timed-ban':'mcp-permanent-ban'};
}
async function verifyUserGone(c,userId){
  if(!/^\d+$/.test(String(userId||'')))return {userDeletionVerified:false,verification:'No numeric user ID available for follow-up verification'};
  const r=await c.req('GET',`memberlist.php?mode=viewprofile&u=${encodeURIComponent(userId)}`);
  const body=decodeHtml(String(r.html||''));
  const gone=r.status===404||/requested user does not exist|no user|user does not exist/i.test(body);
  return {userDeletionVerified:gone,verification:gone?'phpBB profile no longer resolves':'phpBB profile still resolved after purge',verificationHttpStatus:r.status};
}
async function purgeUser(c,cfg,action){
  const hintedUserId=/^\d+$/.test(String(action.userId||''))?String(action.userId):'';
  if(hintedUserId){
    const before=await verifyUserGone(c,hintedUserId);
    if(before.userDeletionVerified===true){
      return {userDeleted:true,postsDeleted:true,alreadyGone:true,resolvedUserId:hintedUserId,httpStatus:before.verificationHttpStatus,confirmationHandled:false,...before};
    }
  }

  let loaded,auth;
  try{
    auth=await adminLogin(c,cfg);
    loaded=await loadAcpUserPage(c,auth,action,'purge');
  }catch(err){
    // A retry after a partially-successful destructive run must not become an
    // endless failover loop merely because the ACP target no longer exists.
    if(hintedUserId){
      const afterLookupFailure=await verifyUserGone(c,hintedUserId);
      if(afterLookupFailure.userDeletionVerified===true){
        return {userDeleted:true,postsDeleted:true,alreadyGone:true,resolvedUserId:hintedUserId,confirmationHandled:false,recoveredFrom:safe(err&&err.message||err,500),...afterLookupFailure};
      }
    }
    throw err;
  }

  const {target,g,form:f}=loaded;
  const resolvedUserId=resolvedAcpUserId(f,action.userId,g.url);
  const overrides={update:'Submit',delete:'1',delete_type:'remove'};if(resolvedUserId)overrides.u=resolvedUserId;
  let r=await c.submitForm(f,g.url,overrides);
  if(r.status>=400||hasError(r.html)||hasLoginForm(r.html)){
    const verify=await verifyUserGone(c,resolvedUserId||hintedUserId);
    if(verify.userDeletionVerified===true)return {userDeleted:true,postsDeleted:true,alreadyGone:true,resolvedUserId:resolvedUserId||hintedUserId,resolvedBy:target.requestedBy,confirmationHandled:false,...verify};
    throw phpbbFailure('phpBB refused purge request.',r);
  }

  const confirmation=await submitPhpbbConfirmation(c,r);
  if(confirmation.confirmed){
    r=confirmation.response;
    if(r.status>=400||hasError(r.html)||hasLoginForm(r.html)){
      const verify=await verifyUserGone(c,resolvedUserId||hintedUserId);
      if(verify.userDeletionVerified===true)return {userDeleted:true,postsDeleted:true,resolvedUserId:resolvedUserId||hintedUserId,resolvedBy:target.requestedBy,httpStatus:r.status,confirmationHandled:true,...verify};
      throw phpbbFailure('phpBB refused purge confirmation.',r);
    }
  }

  const body=decodeHtml(String(r.html||''));
  const success=/user deleted|deleted successfully|back to previous page/i.test(body);
  const verify=await verifyUserGone(c,resolvedUserId||hintedUserId);
  if(!confirmation.confirmed&&!hasAcpSuccess(body)&&!success&&verify.userDeletionVerified!==true){
    throw phpbbFailure('phpBB did not present a deletion confirmation or a verifiable deleted-user result.',r);
  }
  if(!hasAcpSuccess(body)&&!success&&verify.userDeletionVerified!==true){
    throw phpbbFailure('phpBB purge request returned without a verifiable user-deleted result. The account may still exist.',r);
  }
  return {userDeleted:true,postsDeleted:true,resolvedUserId:resolvedUserId||hintedUserId||undefined,resolvedBy:target.requestedBy,httpStatus:r.status,confirmationHandled:confirmation.confirmed,acpFormId:loaded.formId,acpFormFallback:Boolean(loaded.formFallback),...verify};
}


let ACTION_FILE='', RESULT_FILE='', CONFIG_FILE='', STATUS_FILE='';
let actionHint={actionId:'',assignmentSeq:0,executor:''};
let resultWritten=false;
function inferHint(){ try{ const a=readJson(ACTION_FILE); actionHint={actionId:safe(a.actionId,64),assignmentSeq:Number(a.assignmentSeq||0),executor:safe(a.executor,160)}; return a; }catch(e){ const m=path.basename(ACTION_FILE||'').match(/^([a-f0-9]{16,64})-(\d+)\.json$/i); if(m){actionHint.actionId=m[1];actionHint.assignmentSeq=Number(m[2]||0);} throw e; } }
function writeStatus(stage, extra={}){ if(!STATUS_FILE)return; try{ writeJsonAtomic(STATUS_FILE,{schema:2,workerVersion:WORKER_VERSION,stage:safe(stage,80),actionId:actionHint.actionId,assignmentSeq:actionHint.assignmentSeq,executor:actionHint.executor,pid:process.pid,updatedAt:Date.now(),...sanitizeDetail(extra)}); }catch{} }
function writeFailure(error, failedStep='worker_bootstrap', detail={}){ if(resultWritten||!RESULT_FILE)return; const result={schema:3,workerVersion:WORKER_VERSION,actionId:actionHint.actionId,assignmentSeq:actionHint.assignmentSeq,executor:actionHint.executor,startedAt:Date.now(),finishedAt:Date.now(),ok:false,error:safe(error&&error.message||error,1000),failedStep:safe(failedStep,100),detail:sanitizeDetail(detail),steps:[]}; try{writeJsonAtomic(RESULT_FILE,result);resultWritten=true;writeStatus('worker_failed',{failedStep:result.failedStep,error:result.error});}catch{writeStatus('fatal_result_write_failed',{failedStep:result.failedStep,error:result.error});} }
process.on('uncaughtException',e=>{writeFailure(e,'uncaught_exception');process.exitCode=1;});
process.on('unhandledRejection',e=>{writeFailure(e,'unhandled_rejection');process.exitCode=1;});

async function runForumManagerAction(action,cfg,onProgress){
  const startedAt=Date.now();
  const hint={actionId:safe(action&&action.actionId,64),assignmentSeq:Number(action&&action.assignmentSeq||0),executor:safe(action&&action.executor,160)};
  const result={schema:3,workerVersion:WORKER_VERSION,actionId:hint.actionId,assignmentSeq:hint.assignmentSeq,executor:hint.executor,startedAt,ok:false,steps:[]};
  const detail={}; let failedStep='';
  const progress=(stage,extra={})=>{try{if(typeof onProgress==='function')onProgress({schema:2,workerVersion:WORKER_VERSION,stage:safe(stage,80),actionId:hint.actionId,assignmentSeq:hint.assignmentSeq,executor:hint.executor,updatedAt:Date.now(),...sanitizeDetail(extra)});}catch{}};
  const runStep=async(name,fn)=>{const stepStarted=Date.now();progress('step_started',{step:name,startedAt:stepStarted});try{const raw=await fn();const clean=sanitizeDetail(raw);const finishedAt=Date.now();result.steps.push({name,ok:true,startedAt:stepStarted,finishedAt,detail:clean});if(clean&&typeof clean==='object'&&!Array.isArray(clean))Object.assign(detail,clean);progress('step_ok',{step:name,finishedAt,detail:clean});return raw;}catch(e){const finishedAt=Date.now();failedStep=name;const error=safe(e&&e.message||e,1000);result.steps.push({name,ok:false,startedAt:stepStarted,finishedAt,error});progress('step_failed',{step:name,finishedAt,error});throw e;}};
  progress('worker_started',{startedAt,actionType:safe(action&&action.type,80),executionMode:'inline'});
  try{
    await runStep('preflight_config',async()=>{if(!cfg||cfg.forumManager!==true)throw new Error('This node is not enabled as Forum Manager.');if(!safe(cfg.forumUrl)||!safe(cfg.username)||!safe(cfg.password))throw new Error('Forum Manager URL/username/password is incomplete.');return {managerEnabled:true,forumHost:(()=>{try{return new URL(cfg.forumUrl).host}catch{return ''}})(),adminPath:safe(cfg.adminPath||'adm/',80)};});
    const c=new Client(cfg.forumUrl,Math.max(1000,Math.min(20000,Number(cfg.requestTimeoutMs)||5000)));
    await runStep('phpbb_login',()=>login(c,cfg));
    if(action.type==='test_forum_manager'){
      await runStep('moderator_access',()=>checkModeratorAccess(c));
      await runStep('acp_access',()=>checkAcpAccess(c,cfg));
    } else if(action.type==='delete_post'){
      await runStep('delete_post',()=>deletePost(c,action));
    } else if(action.type==='delete_post_and_ban_user'){
      await runStep('delete_post',()=>deletePost(c,action));
      await runStep('ban_user',()=>banUserRobust(c,cfg,action));
    } else if(action.type==='purge_user'){
      await runStep('purge_user_and_posts',()=>purgeUser(c,cfg,action));
    } else throw new Error(`Unsupported moderation action: ${action.type}`);
    Object.assign(result,{ok:true,detail:sanitizeDetail(detail),finishedAt:Date.now()});
  }catch(e){Object.assign(result,{ok:false,error:safe(e&&e.message||e,1000),failedStep:failedStep||'preflight',detail:sanitizeDetail(detail),finishedAt:Date.now()});}
  progress(result.ok?'result_ready':'worker_failed',{ok:result.ok,failedStep:result.failedStep||'',error:result.error||'',finishedAt:result.finishedAt});
  return result;
}

async function main(){
  [ACTION_FILE,RESULT_FILE,CONFIG_FILE,STATUS_FILE]=process.argv.slice(2);
  if(!ACTION_FILE||!RESULT_FILE||!CONFIG_FILE) throw new Error('Usage: worker action.json result.json custom.json [status.json]');
  const action=inferHint();
  writeStatus('worker_started',{startedAt:Date.now(),actionType:safe(action.type,80)});
  let custom;
  try{custom=readJson(CONFIG_FILE);}catch(e){writeFailure(new Error(`Could not read node-local Forum Manager Custom Data: ${safe(e.message,500)}`),'read_manager_config');return;}
  const cfg=(custom&&custom.forumguard_manager&&typeof custom.forumguard_manager==='object')?custom.forumguard_manager:custom;
  const result=await runForumManagerAction(action,cfg,(d)=>writeStatus(d.stage,d));
  try{writeJsonAtomic(RESULT_FILE,result);resultWritten=true;writeStatus(result.ok?'result_written':'worker_failed',{ok:result.ok,failedStep:result.failedStep||'',error:result.error||'',finishedAt:result.finishedAt});}
  catch(e){writeStatus('fatal_result_write_failed',{error:safe(e.message||e,1000)});throw e;}
}
if(require.main===module){main().catch(e=>{writeFailure(e,'worker_bootstrap');process.exitCode=1;});}
module.exports={runForumManagerAction,sanitizeDetail};


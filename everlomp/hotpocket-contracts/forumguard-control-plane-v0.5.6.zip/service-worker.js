const CACHE='forumguard-v0.5.6';
const ASSETS=['./evernode-logo.svg','./hotpocket-js-client.min.js','./bson.bundle.min.js','./sodium.js','./qrcode.js'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).catch(()=>{}))});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>/^(?:everadmin|forumguard)-v/i.test(k)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.origin===self.location.origin&&(u.pathname.startsWith('/signer/')||u.pathname==='/signer'||u.pathname.startsWith('/setup/')||u.pathname==='/setup'))return;
  // HTML is deliberately network-only so an old admin panel cannot survive a contract switch.
  if(e.request.mode==='navigate'||u.pathname.endsWith('/evernode.html')||u.pathname.endsWith('/forumguard.html')||u.pathname.endsWith('/index.html')){e.respondWith(fetch(e.request,{cache:'no-store'}));return;}
  e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
});

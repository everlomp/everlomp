# Encryption-aware installer security model

This package automatically checks Everlomp's current key mode when installation begins.

## When encryption is enabled

Everlomp must report `mode=enabled` and a valid Docker Swarm secret at `/run/secrets/key`.

The package does **not** read, print, copy, log, or persist the master key. Recoverable credentials are passed to `/usr/local/sbin/everlomp-secret`, which stores them as AES-256-GCM ciphertext. The persistent secret filename ends in `.enc`.

The master key remains Docker/Evernode-managed at `/run/secrets/key`. A recoverable credential is decrypted only when a privileged runtime component actually needs the original value.

## When encryption is disabled

Everlomp must report `mode=disabled`. The same `/usr/local/sbin/everlomp-secret` interface is used, but recoverable credentials are stored as root-only plaintext because there is no encryption key protecting them.

The installed page displays a prominent warning when this mode was detected.

## Passwords that do not need to be recovered

Human login passwords should normally be **hashed, not encrypted**. This example hashes the example admin password using PHP `password_hash()` and persists only the resulting password hash. The original password is discarded.

## Passwords that must be recovered

Database passwords, API tokens, SMTP credentials, SFTP/WebDAV/S3 credentials, repository passwords, and private keys often have to be recovered by a service later. These should use Everlomp's recoverable-secret interface instead of password hashing.

## What this demonstration stores

- Example human login password: password hash only.
- Example recoverable service password with encryption enabled: AES-256-GCM ciphertext only on persistent storage.
- Example recoverable service password with encryption disabled: root-only plaintext on persistent storage.
- `/run/secrets/key`: never copied into the package's persistent data.

This package is an educational external-installer example. Its `install.sh` runs as root, like every Everlomp schema-1 external installer.


### Schema-1 script permissions

Everlomp intentionally imports only `install.sh` as executable. Supporting scripts such as `secret-demo.sh` are stored as mode `0644`, so `install.sh` invokes them explicitly with `/bin/bash`.

#!/bin/bash
set -Eeuo pipefail

# Everlomp encryption-aware secret wrapper used by this dummy app.
#
# IMPORTANT:
#   This app does NOT read /run/secrets/key directly.
#   The privileged Everlomp helper does that for us.
#
# Write path when encryption is enabled:
#
#   dummy app
#      |
#      | plaintext on stdin (only for this operation)
#      v
#   /usr/local/sbin/everlomp-secret write PATH
#      |
#      | reads /run/secrets/key internally
#      | AES-256-GCM encrypts
#      v
#   PATH.enc   (persistent ciphertext)
#
# Read path later, e.g. after a service restart:
#
#   PATH.enc
#      |
#      v
#   /usr/local/sbin/everlomp-secret read PATH
#      |
#      | reads /run/secrets/key internally
#      | AES-256-GCM decrypts
#      v
#   plaintext on stdout (consume immediately; do not log it)
#
# If Everlomp encryption is disabled, the exact same helper API stores PATH
# as root-only plaintext instead. The caller does not implement crypto itself.

KEY_HELPER=/usr/local/sbin/everlomp-key
SECRET_HELPER=/usr/local/sbin/everlomp-secret

status_json() {
    "$KEY_HELPER" status
}

show_mode() {
    local status mode valid
    status="$(status_json)"
    mode="$(jq -r '.mode // "undecided"' <<<"$status")"
    valid="$(jq -r '.key_valid // false' <<<"$status")"

    case "$mode" in
        enabled)
            if [ "$valid" = true ]; then
                printf '%s\n' 'encrypted'
            else
                printf '%s\n' 'enabled-but-key-unavailable'
                return 2
            fi
            ;;
        disabled)
            printf '%s\n' 'plaintext'
            ;;
        *)
            printf '%s\n' "$mode"
            return 3
            ;;
    esac
}

write_secret() {
    local path="$1"
    # Plaintext arrives on stdin and is passed directly to Everlomp's helper.
    # The dummy app never opens /run/secrets/key itself.
    "$SECRET_HELPER" write "$path"
}

read_secret() {
    local path="$1"
    # The helper decrypts with /run/secrets/key when encryption is enabled.
    # Callers should capture/use this value immediately and never log it.
    "$SECRET_HELPER" read "$path"
}

case "${1:-}" in
    mode)
        show_mode
        ;;
    write)
        [ "$#" -eq 2 ] || { echo "usage: $0 write PATH" >&2; exit 64; }
        write_secret "$2"
        ;;
    read)
        [ "$#" -eq 2 ] || { echo "usage: $0 read PATH" >&2; exit 64; }
        read_secret "$2"
        ;;
    *)
        cat >&2 <<USAGE
usage:
  $0 mode
  printf '%s' 'secret' | $0 write /persistent/base/path
  value="$($0 read /persistent/base/path)"
USAGE
        exit 64
        ;;
esac

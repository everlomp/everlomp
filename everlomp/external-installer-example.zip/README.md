# Everlomp encryption-aware external installer example

This is a **single** schema-1 Upload Installer ZIP that adapts automatically to the Everlomp installation's security mode.

It demonstrates the two credential classes an external installer should distinguish:

1. **Human authentication passwords** -> hash them and discard plaintext.
2. **Recoverable service credentials** -> store them through `everlomp-secret`.

## Automatic mode detection

The installer asks Everlomp for current key status:

```bash
/usr/local/sbin/everlomp-key status
```

Expected states:

- `mode=enabled` + `key_valid=true`: encrypted mode.
- `mode=disabled`: non-encrypted mode.
- `pending` / `undecided`: installation stops and asks the user to finish Everlomp key setup first.
- `enabled` + invalid key: installation stops rather than silently falling back to plaintext.

That last rule is important: **an encrypted installation must fail closed if its master key is unavailable.**


## The explicit dummy-app secret code

This package now includes `secret-demo.sh`, and `install.sh` actually calls it. The important relationship is visible directly in the package:

```text
dummy app / secret-demo.sh
        |
        v
/usr/local/sbin/everlomp-secret
        |
        | internally reads /run/secrets/key when encryption is enabled
        v
AES-256-GCM
        |
        v
service-password.enc
```

The dummy app intentionally does **not** run `cat /run/secrets/key`. That keeps cryptographic key handling centralized in Everlomp. `secret-demo.sh` exposes three operations:

```bash
./secret-demo.sh mode
printf '%s' "$SERVICE_PASSWORD" | ./secret-demo.sh write "$SECRET_PATH"
SERVICE_PASSWORD="$(./secret-demo.sh read "$SECRET_PATH")"
```

The `read` example is what a privileged service startup would use after a restart. Never print or log the returned plaintext.

## One API for recoverable secrets

Do not implement separate encrypted/plaintext branches throughout your installer. Use the same Everlomp helper:

```bash
printf '%s' "$SERVICE_PASSWORD" \
  | /usr/local/sbin/everlomp-secret write "$SECRET_PATH"
```

Everlomp decides how the secret is persisted:

### Encryption enabled

```text
/run/secrets/key
        |
        v
AES-256-GCM
        |
        v
$SECRET_PATH.enc
```

### Encryption disabled

```text
$SECRET_PATH
(root-only plaintext)
```

To consume it later from a **privileged** runtime component:

```bash
/usr/local/sbin/everlomp-secret read "$SECRET_PATH"
```

Do not print the result, put it in logs, or expose it through a web response. If a daemon requires a file, materialize it into a dedicated `/run/...` runtime path with restrictive permissions and remove/recreate it as appropriate.

## Hash-only password example

The example human password is hashed with PHP:

```bash
HASH="$(printf '%s' "$ADMIN_PASSWORD" | php -r '$p=stream_get_contents(STDIN); echo password_hash($p, PASSWORD_DEFAULT);')"
```

Only the hash is persisted. The plaintext password is never recoverable from the package state.

## Package output

This demo installs a small security-information page at `/`. It intentionally never displays the submitted passwords or the master key. It shows:

- which encryption mode was detected;
- where the hash-only credential was persisted;
- where the recoverable credential was persisted;
- whether the persistent recoverable credential is encrypted or plaintext;
- the file permissions used;
- the security flow for both modes.

## Persistent demo state

```text
/var/www/.everlomp-external-security-demo/
  admin-password.hash
  security.json
  secrets/
    service-password.enc    # encryption enabled
    service-password        # encryption disabled
```

The demo page itself is `/var/www/html/index.php`.

## Important

The package never attempts to `chmod`, delete, overwrite, or copy `/run/secrets/key`. Secret-file permissions should be configured by the Evernode/Docker Swarm service definition (ideally root-only, mode `0400`).


### Schema-1 script permissions

Everlomp intentionally imports only `install.sh` as executable. Supporting scripts such as `secret-demo.sh` are stored as mode `0644`, so `install.sh` invokes them explicitly with `/bin/bash`.

## Demo state permissions

The demo intentionally separates readable security metadata from credential material:

- `/var/www/.everlomp-external-security-demo/` — `root:root 0755` so the web UI can traverse to `security.json`.
- `security.json` — `root:root 0644`; contains mode/path metadata only, never passwords or the master key.
- `admin-password.hash` — `root:root 0600`.
- `secrets/` — `root:root 0700`.
- `secrets/service-password.enc` (encrypted mode) or `service-password` (non-encrypted mode) — `root:root 0600`.

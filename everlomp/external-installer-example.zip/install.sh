#!/bin/bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SECRET_DEMO="$SCRIPT_DIR/secret-demo.sh"

PAYLOAD="$(cat)"
SITE_TITLE="$(jq -r '.fields.site_title // "Everlomp Security Demo"' <<<"$PAYLOAD")"
ADMIN_PASSWORD="$(jq -r '.fields.admin_password // ""' <<<"$PAYLOAD")"
SERVICE_PASSWORD="$(jq -r '.fields.service_password // ""' <<<"$PAYLOAD")"
ACK="$(jq -r '.fields.acknowledge_security_model // false' <<<"$PAYLOAD")"

if [ -z "$ADMIN_PASSWORD" ] || [ -z "$SERVICE_PASSWORD" ]; then
    echo 'Both demonstration password fields are required.' >&2
    exit 20
fi
if [ "$ACK" != "true" ]; then
    echo 'Security-model acknowledgement is required.' >&2
    exit 21
fi

KEY_HELPER=/usr/local/sbin/everlomp-key
SECRET_HELPER=/usr/local/sbin/everlomp-secret
PHP_BIN=/usr/local/lsws/lsphp85/bin/php
if [ ! -x "$KEY_HELPER" ] || [ ! -x "$SECRET_HELPER" ] || [ ! -f "$SECRET_DEMO" ]; then
    echo 'This package requires Everlomp key/secret helpers and secret-demo.sh.' >&2
    exit 22
fi
if [ ! -x "$PHP_BIN" ]; then
    PHP_BIN="$(command -v php 2>/dev/null || true)"
fi
if [ -z "$PHP_BIN" ] || [ ! -x "$PHP_BIN" ]; then
    echo 'This package requires the OpenLiteSpeed PHP runtime.' >&2
    exit 26
fi

STATUS="$($KEY_HELPER status)"
MODE="$(jq -r '.mode // "undecided"' <<<"$STATUS")"
KEY_VALID="$(jq -r '.key_valid // false' <<<"$STATUS")"
KEY_ERROR="$(jq -r '.key_error // ""' <<<"$STATUS")"

case "$MODE" in
    enabled)
        if [ "$KEY_VALID" != "true" ]; then
            echo "Everlomp encryption is enabled, but the master key is unavailable: ${KEY_ERROR:-unknown key error}" >&2
            echo 'Refusing to fall back to plaintext.' >&2
            exit 23
        fi
        STORAGE_MODE=encrypted
        ;;
    disabled)
        STORAGE_MODE=plaintext
        ;;
    pending|undecided|*)
        echo "Everlomp encryption choice is not finalized (mode: $MODE). Finish key setup before installing this package." >&2
        exit 24
        ;;
esac

STATE_DIR=/var/www/.everlomp-external-security-demo
SECRET_DIR=/home/everlomp/secrets/external-security-demo
SECRET_BASE="$SECRET_DIR/service-password"

# Non-secret demo metadata stays under /var/www so the demo page can read it.
mkdir -p "$STATE_DIR"
chown root:root "$STATE_DIR"
chmod 0755 "$STATE_DIR"

# Everlomp requires persistent recoverable secrets to live under
# /home/everlomp/secrets. Keep this app's credentials in its own root-only
# subdirectory there; everlomp-secret will create either SECRET_BASE.enc
# (encrypted mode) or SECRET_BASE (plaintext compatibility mode).
install -d -o root -g root -m 0700 "$SECRET_DIR"

# Human-authentication password: hash only. The original plaintext is not needed later.
ADMIN_HASH="$(printf '%s' "$ADMIN_PASSWORD" | "$PHP_BIN" -r '$p=stream_get_contents(STDIN); $h=password_hash($p, PASSWORD_DEFAULT); if ($h === false) { exit(1); } echo $h;')"
printf '%s\n' "$ADMIN_HASH" > "$STATE_DIR/admin-password.hash"
chown root:root "$STATE_DIR/admin-password.hash"
chmod 0600 "$STATE_DIR/admin-password.hash"
unset ADMIN_PASSWORD ADMIN_HASH

# Recoverable credential: the same helper call works in encrypted and disabled modes.
printf '%s' "$SERVICE_PASSWORD" | /bin/bash "$SECRET_DEMO" write "$SECRET_BASE"
unset SERVICE_PASSWORD

if [ "$STORAGE_MODE" = encrypted ]; then
    PERSISTED_SECRET="${SECRET_BASE}.enc"
    SECRET_DESCRIPTION='AES-256-GCM ciphertext. The master key remains in /run/secrets/key and is not copied here.'
else
    PERSISTED_SECRET="$SECRET_BASE"
    SECRET_DESCRIPTION='Root-only plaintext because Everlomp encryption is disabled.'
fi

if [ ! -f "$PERSISTED_SECRET" ]; then
    echo "Expected persisted secret was not created: $PERSISTED_SECRET" >&2
    exit 25
fi

SECRET_MODE="$(stat -c '%a' "$PERSISTED_SECRET")"
HASH_MODE="$(stat -c '%a' "$STATE_DIR/admin-password.hash")"

# Persist only non-secret metadata for the demonstration page.
python3 - "$STATE_DIR/security.json" "$SITE_TITLE" "$MODE" "$STORAGE_MODE" "$PERSISTED_SECRET" "$SECRET_DESCRIPTION" "$SECRET_MODE" "$HASH_MODE" <<'PY'
import json, os, sys
out, title, key_mode, storage_mode, secret_path, secret_description, secret_mode, hash_mode = sys.argv[1:]
data = {
    "site_title": title,
    "key_mode": key_mode,
    "storage_mode": storage_mode,
    "hash_path": "/var/www/.everlomp-external-security-demo/admin-password.hash",
    "hash_mode": hash_mode,
    "recoverable_secret_path": secret_path,
    "recoverable_secret_mode": secret_mode,
    "recoverable_secret_description": secret_description,
    "master_key_path": "/run/secrets/key",
    "master_key_copied": False,
    "algorithm": "AES-256-GCM" if storage_mode == "encrypted" else None,
}
tmp = out + '.tmp'
with open(tmp, 'w', encoding='utf-8') as f:
    json.dump(data, f, indent=2)
    f.write('\n')
os.chmod(tmp, 0o644)
os.replace(tmp, out)
PY
chown root:root "$STATE_DIR/security.json"
chmod 0644 "$STATE_DIR/security.json"

# Primary app: preserve install.php until Everlomp cleanup, replace bootstrap/index content.
find /var/www/html -mindepth 1 -maxdepth 1 ! -name install.php -exec rm -rf -- {} +

cat > /var/www/html/index.php <<'PHP'
<?php
declare(strict_types=1);
$infoFile = '/var/www/.everlomp-external-security-demo/security.json';
$info = [];
if (is_readable($infoFile)) {
    $decoded = json_decode((string) file_get_contents($infoFile), true);
    if (is_array($decoded)) $info = $decoded;
}
function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
$encrypted = ($info['storage_mode'] ?? '') === 'encrypted';
$title = (string) ($info['site_title'] ?? 'Everlomp Security Demo');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($title) ?></title>
<style>
:root{color-scheme:dark}body{margin:0;background:#0c111b;color:#e9eef8;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.wrap{max-width:980px;margin:0 auto;padding:52px 22px 80px}.hero,.card{background:#121a28;border:1px solid #26344a;border-radius:18px;padding:24px;margin-bottom:18px}.hero h1{margin:0 0 8px;font-size:34px}.hero p{color:#adbbcf;line-height:1.55}.badge{display:inline-block;border-radius:999px;padding:7px 11px;font-weight:700;background:<?= $encrypted ? '#153a2a' : '#4a2c12' ?>;color:<?= $encrypted ? '#8ef0bb' : '#ffd398' ?>}.flow{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap;background:#0a0f18;border:1px solid #233149;border-radius:12px;padding:16px;line-height:1.6;overflow:auto}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:12px;border-bottom:1px solid #26344a;vertical-align:top}th{color:#9fb0c7}code{background:#0a0f18;border:1px solid #26344a;padding:2px 6px;border-radius:6px}.warn{border-color:#725125;background:#241d13}.good{border-color:#295f45;background:#10231a}h2{margin-top:0}.muted{color:#9eacc0}.no-secret{font-weight:700;color:#8ef0bb}</style>
</head>
<body><main class="wrap">
<section class="hero">
<span class="badge"><?= $encrypted ? 'Encryption enabled' : 'Encryption disabled' ?></span>
<h1><?= h($title) ?></h1>
<p>This application was installed by a single encryption-aware Everlomp Upload Installer. It detected the current Everlomp security mode automatically and chose the matching persistent-secret behavior.</p>
</section>

<section class="card <?= $encrypted ? 'good' : 'warn' ?>">
<h2>Detected security mode</h2>
<?php if ($encrypted): ?>
<p><strong>Recoverable secrets are encrypted at rest.</strong> The installer used Everlomp's secret helper, which protects the service password with AES-256-GCM using the Docker Swarm master key at <code>/run/secrets/key</code>.</p>
<?php else: ?>
<p><strong>No Everlomp encryption key is active.</strong> Recoverable secrets must remain recoverable, so the service password is stored as root-only plaintext. Human login passwords can still be safely hashed.</p>
<?php endif; ?>
</section>

<section class="card">
<h2>How the two password types are stored</h2>
<table>
<tr><th>Credential</th><th>Persistent representation</th><th>Why</th></tr>
<tr><td>Human login password</td><td>Password hash only<br><code><?= h((string)($info['hash_path'] ?? '')) ?></code><br>mode <?= h((string)($info['hash_mode'] ?? '')) ?></td><td>The application only needs to verify future passwords. It never needs the original plaintext back.</td></tr>
<tr><td>Recoverable service password</td><td><?= $encrypted ? 'AES-256-GCM ciphertext' : 'Root-only plaintext' ?><br><code><?= h((string)($info['recoverable_secret_path'] ?? '')) ?></code><br>mode <?= h((string)($info['recoverable_secret_mode'] ?? '')) ?></td><td>A service/API/database credential must be recoverable later, so it cannot be replaced with a one-way hash.</td></tr>
</table>
</section>

<section class="card">
<h2><?= $encrypted ? 'Encrypted flow' : 'Non-encrypted flow' ?></h2>
<?php if ($encrypted): ?>
<div class="flow">/run/secrets/key  (Docker Swarm, master key)
        |
        v
Everlomp secret helper
        |
        +-- AES-256-GCM encrypt --> service-password.enc  (persistent ciphertext)
        |
        +-- decrypt only when a privileged runtime component needs the credential

Human login password --> password_hash() --> admin-password.hash
                       plaintext discarded</div>
<?php else: ?>
<div class="flow">No active Everlomp encryption key
        |
        +-- recoverable service credential --> root-only plaintext persistent file
        |
        +-- human login password --> password_hash() --> hash-only persistent file
                                      plaintext discarded</div>
<?php endif; ?>
</section>

<section class="card">
<h2>Master-key handling</h2>
<p class="no-secret">This page does not know or display the master key or either submitted password.</p>
<p>The installer never copies <code>/run/secrets/key</code> into its own state. It asks Everlomp's root-only helper to store recoverable secrets. The key should ideally be mounted by Docker Swarm as <code>root:root 0400</code>.</p>
</section>

<section class="card">
<h2>Rule of thumb for installer authors</h2>
<div class="flow">Need the original credential again later?

NO  -> hash it -> persist only the hash

YES -> everlomp-secret write PATH
       encrypted mode -> PATH.enc (AES-256-GCM)
       disabled mode  -> PATH (root-only plaintext)</div>
<p class="muted">Examples of recoverable credentials: database passwords, SMTP passwords, S3/SFTP/WebDAV credentials, API tokens, repository passwords, and private keys.</p>
</section>
</main></body></html>
PHP

chown root:root /var/www/html/index.php
chmod 0644 /var/www/html/index.php

printf 'Encryption-aware example installed in %s mode.\n' "$STORAGE_MODE"

<?php

namespace LLAR\Core\Integrations;

use LLAR\Core\Config;
use LLAR\Core\LimitLoginAttempts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class BaseIntegration implements IntegrationInterface {

	/**
	 * @var LimitLoginAttempts
	 */
	protected $llar_instance;

	/**
	 * @param LimitLoginAttempts $llar_instance
	 */
	public function __construct( LimitLoginAttempts $llar_instance ) {
		$this->llar_instance = $llar_instance;
	}

	/**
	 * Static method to check if plugin is active (can be called without instance)
	 * Should be overridden in child classes
	 *
	 * @return bool
	 */
	public static function is_plugin_active() {
		return false;
	}

	/**
	 * Default implementation - not a login page
	 *
	 * @return bool
	 */
	public function is_login_page() {
		return false;
	}

	/**
	 * Default implementation - no credentials
	 *
	 * @return array|null
	 */
	public function get_login_credentials() {
		return null;
	}

	/**
	 * Default implementation - derive identifier from credentials.
	 *
	 * @return string
	 */
	public function get_login_identifier() {
		$credentials = $this->get_login_credentials();
		if ( is_array( $credentials ) && ! empty( $credentials['username'] ) ) {
			return (string) $credentials['username'];
		}

		return '';
	}

	/**
	 * Default implementation - do nothing
	 *
	 * @param string $message
	 * @return void
	 */
	public function display_error( $message ) {
		// Default implementation
	}

	/**
	 * Helper method to get error message from LLAR
	 *
	 * @return string
	 */
	protected function get_error_message() {
		return $this->llar_instance->error_msg( $this->get_login_identifier() );
	}

	/**
	 * Helper method to check if login is allowed
	 *
	 * @return bool
	 */
	protected function is_login_allowed() {
		return $this->llar_instance->is_limit_login_ok( $this->get_login_identifier() );
	}

	/**
	 * Default implementation - not a registration page
	 *
	 * @return bool
	 */
	public function is_registration_page() {
		return false;
	}

	/**
	 * Default implementation - no registration data
	 *
	 * @return array|null
	 */
	public function get_registration_data() {
		return null;
	}

	/**
	 * Default implementation - do nothing
	 *
	 * @param string $message
	 * @return void
	 */
	public function display_registration_error( $message ) {
		// Default implementation
	}

	/**
	 * Helper method to check if registration is limited
	 *
	 * @return bool
	 */
	protected function is_registration_limited() {
		// Check if registration limiting is enabled in cloud app
		if ( ! $this->llar_instance::$cloud_app ) {
			return false;
		}

		$app_config         = Config::get( 'app_config' );
		$limit_registration = isset( $app_config['settings']['limit_registration']['value'] )
			? $app_config['settings']['limit_registration']['value']
			: '';

		return 'on' === $limit_registration;
	}

	/**
	 * Protected method to check registration via API
	 * This method ensures only integration classes can call the API
	 *
	 * @param string $user_data User data to check
	 * @return array API response
	 */
	protected function check_registration_api( $user_data ) {
		return $this->llar_instance->check_registration_api( $user_data, $this );
	}
}
